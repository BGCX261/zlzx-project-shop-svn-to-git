// JavaScript Document
//������
$(function(){
	$(".sub_nav").hide();
	$(".nav > ul > li > a").hover(function(){
		$(this).next(".sub_nav").show();
		$(this).parent().addClass("currentPage1");
	},function(){
		var over = true;
		$(".sub_nav").hover(function(){
			$(this).show();
			$(this).siblings("a").parent().addClass("currentPage1");
			over = false;
			return over;
		},function(){
			$(this).hide();
			$(this).siblings("a").parent().removeClass("currentPage1");
			over = true;
			return over;
		});
		if(over == true){
			$(this).next(".sub_nav").hide();
			$(this).parent().removeClass("currentPage1");
		}
	});
});

$(function(){
	$("#changeCon > div").hide();
	$("#changeCon > div").eq(0).show();
	$("#changeTag > li").each(function(i){
		$(this).click(function(){
			$("#changeTag > li").removeClass("onthis");
			$(this).addClass("onthis");
			$("#changeCon > div").hide();
			$("#changeCon > div").eq(i).show();
		});
	});
});

$(function(){
	$(".changeCon > ul").hide();
	$(".changeCon > ul").eq(0).show();
	$(".changeTag > span").each(function(i){
		$(this).hover(function(){
			$(".changeTag > span").removeClass("onthis");
			$(this).addClass("onthis");
			$(".changeCon > ul").hide();
			$(".changeCon > ul").eq(i).show();
		});
	});
});


$(function(){
	$(".js_change1").hide();
	$(".js_change1").eq(0).show();
	$(".js_toggle1 > li").each(function(i){
		$(this).click(function(){
			$(this).addClass("curr").siblings().removeClass("curr");  
			$(".js_change1").hide();
			$(".js_change1").eq(i).show();
		});
	});
	
});


$(function(){
	$(".js_change2").hide();
	$(".js_change2").eq(0).show();
	$(".js_toggle2 > li").each(function(i){
		$(this).click(function(){
			$(this).addClass("curr").siblings().removeClass("curr");  
			$(".js_change2").hide();
			$(".js_change2").eq(i).show();
		});
	});
	
});



//һ���л�ǩ
$(function(){
	$(".js_styset").hide();
	$(".closebtn").click(function(){
		$(".js_styset").hide();
	});
	
	$(".uploadbtn").click(function(){
		$(this).parents(".logostate").hide();
		$(".uploadcontainer").show();
	});
	$(".cancelupload").click(function(){
		$(".uploadcontainer").hide();
		$(".logostate").show();
		
	});
	
});

//���õ��� ������� ����   �л�
$(function(){
	$(".custom_menu > li").each(function(i){
		$(this).click(function(){
			$(".styleset").hide();
			$(".styleset").eq(i).show();	
		});
	});
});


//���õ��� ��ҳ ������Ŀ    �л�
	$(function(){
	    var $div_li =$("div.tab_menu ul li");
	    $div_li.click(function(){
			$(this).addClass("selected")         
				   .siblings().removeClass("selected");  
            var index =  $div_li.index(this); 
			$("div.tab_box > div")   	
					.eq(index).show()   
					.siblings().hide();
		})
	})
