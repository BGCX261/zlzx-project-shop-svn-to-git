﻿
var PageName = '产品创建';
var PageId = '4423234e00d04e6d896bdc41bfd4c20e'
var PageUrl = '产品创建.html'
document.title = '产品创建';
var PageNotes = 
{
"pageName":"产品创建",
"showNotesNames":"False"}
var $OnLoadVariable = '';

var $NewVariable1 = '';

var $CSUM;

var hasQuery = false;
var query = window.location.hash.substring(1);
if (query.length > 0) hasQuery = true;
var vars = query.split("&");
for (var i = 0; i < vars.length; i++) {
    var pair = vars[i].split("=");
    if (pair[0].length > 0) eval("$" + pair[0] + " = decodeURIComponent(pair[1]);");
} 

if (hasQuery && $CSUM != 1) {
alert('Prototype Warning: The variable values were too long to pass to this page.\nIf you are using IE, using Firefox will support more data.');
}

function GetQuerystring() {
    return '#OnLoadVariable=' + encodeURIComponent($OnLoadVariable) + '&NewVariable1=' + encodeURIComponent($NewVariable1) + '&CSUM=1';
}

function PopulateVariables(value) {
    var d = new Date();
  value = value.replace(/\[\[OnLoadVariable\]\]/g, $OnLoadVariable);
  value = value.replace(/\[\[NewVariable1\]\]/g, $NewVariable1);
  value = value.replace(/\[\[PageName\]\]/g, PageName);
  value = value.replace(/\[\[GenDay\]\]/g, '9');
  value = value.replace(/\[\[GenMonth\]\]/g, '8');
  value = value.replace(/\[\[GenMonthName\]\]/g, '八月');
  value = value.replace(/\[\[GenDayOfWeek\]\]/g, '星期四');
  value = value.replace(/\[\[GenYear\]\]/g, '2012');
  value = value.replace(/\[\[Day\]\]/g, d.getDate());
  value = value.replace(/\[\[Month\]\]/g, d.getMonth() + 1);
  value = value.replace(/\[\[MonthName\]\]/g, GetMonthString(d.getMonth()));
  value = value.replace(/\[\[DayOfWeek\]\]/g, GetDayString(d.getDay()));
  value = value.replace(/\[\[Year\]\]/g, d.getFullYear());
  return value;
}

function OnLoad(e) {

}

var u370 = document.getElementById('u370');
gv_vAlignTable['u370'] = 'top';
var u68 = document.getElementById('u68');
gv_vAlignTable['u68'] = 'center';
var u62 = document.getElementById('u62');
gv_vAlignTable['u62'] = 'center';
var u646 = document.getElementById('u646');

var u167 = document.getElementById('u167');
gv_vAlignTable['u167'] = 'center';
var u299 = document.getElementById('u299');
gv_vAlignTable['u299'] = 'top';
var u619 = document.getElementById('u619');

var u17 = document.getElementById('u17');
gv_vAlignTable['u17'] = 'center';
var u190 = document.getElementById('u190');
gv_vAlignTable['u190'] = 'center';
var u438 = document.getElementById('u438');
gv_vAlignTable['u438'] = 'top';
var u199 = document.getElementById('u199');

u199.style.cursor = 'pointer';
if (bIE) u199.attachEvent("onclick", Clicku199);
else u199.addEventListener("click", Clicku199, true);
function Clicku199(e)
{
windowEvent = e;


if (true) {

	SetPanelState('u157', 'pd0u157','none','',500,'none','',500);

}

}
gv_vAlignTable['u199'] = 'top';
var u400 = document.getElementById('u400');
gv_vAlignTable['u400'] = 'top';
var u84 = document.getElementById('u84');
gv_vAlignTable['u84'] = 'center';
var u468 = document.getElementById('u468');
gv_vAlignTable['u468'] = 'top';
var u194 = document.getElementById('u194');

u194.style.cursor = 'pointer';
if (bIE) u194.attachEvent("onclick", Clicku194);
else u194.addEventListener("click", Clicku194, true);
function Clicku194(e)
{
windowEvent = e;


if (true) {

	SetPanelState('u157', 'pd0u157','none','',500,'none','',500);

}

}

var u514 = document.getElementById('u514');

var u492 = document.getElementById('u492');

var u333 = document.getElementById('u333');
gv_vAlignTable['u333'] = 'top';
var u569 = document.getElementById('u569');

var u631 = document.getElementById('u631');
gv_vAlignTable['u631'] = 'top';
var u152 = document.getElementById('u152');

var u450 = document.getElementById('u450');
gv_vAlignTable['u450'] = 'top';
var u587 = document.getElementById('u587');
gv_vAlignTable['u587'] = 'top';
var u231 = document.getElementById('u231');

var u347 = document.getElementById('u347');
gv_vAlignTable['u347'] = 'top';
var u78 = document.getElementById('u78');
gv_vAlignTable['u78'] = 'top';
var u645 = document.getElementById('u645');

var u159 = document.getElementById('u159');
gv_vAlignTable['u159'] = 'center';
var u298 = document.getElementById('u298');

var u464 = document.getElementById('u464');
gv_vAlignTable['u464'] = 'top';
var u139 = document.getElementById('u139');

u139.style.cursor = 'pointer';
if (bIE) u139.attachEvent("onclick", Clicku139);
else u139.addEventListener("click", Clicku139, true);
function Clicku139(e)
{
windowEvent = e;


if (true) {

	SetPanelState('u141', 'pd3u141','none','',500,'none','',500);

}

}

var u201 = document.getElementById('u201');

var u95 = document.getElementById('u95');
gv_vAlignTable['u95'] = 'center';
var u1 = document.getElementById('u1');
gv_vAlignTable['u1'] = 'center';
var u215 = document.getElementById('u215');
gv_vAlignTable['u215'] = 'center';
var u193 = document.getElementById('u193');

var u11 = document.getElementById('u11');
gv_vAlignTable['u11'] = 'center';
var u126 = document.getElementById('u126');

var u413 = document.getElementById('u413');

var u391 = document.getElementById('u391');

var u568 = document.getElementById('u568');
gv_vAlignTable['u568'] = 'top';
var u630 = document.getElementById('u630');

var u151 = document.getElementById('u151');
gv_vAlignTable['u151'] = 'center';
var u71 = document.getElementById('u71');

var u586 = document.getElementById('u586');

var u63 = document.getElementById('u63');
gv_vAlignTable['u63'] = 'top';
var u346 = document.getElementById('u346');

var u72 = document.getElementById('u72');
gv_vAlignTable['u72'] = 'center';
var u644 = document.getElementById('u644');
gv_vAlignTable['u644'] = 'top';
var u319 = document.getElementById('u319');
gv_vAlignTable['u319'] = 'top';
var u158 = document.getElementById('u158');

var u463 = document.getElementById('u463');

var u138 = document.getElementById('u138');
gv_vAlignTable['u138'] = 'center';
var u93 = document.getElementById('u93');
gv_vAlignTable['u93'] = 'center';
var u624 = document.getElementById('u624');
gv_vAlignTable['u624'] = 'top';
var u54 = document.getElementById('u54');
gv_vAlignTable['u54'] = 'top';
var u477 = document.getElementById('u477');
gv_vAlignTable['u477'] = 'top';
var u181 = document.getElementById('u181');
gv_vAlignTable['u181'] = 'center';
var u214 = document.getElementById('u214');

u214.style.cursor = 'pointer';
if (bIE) u214.attachEvent("onclick", Clicku214);
else u214.addEventListener("click", Clicku214, true);
function Clicku214(e)
{
windowEvent = e;


if (true) {

	SetPanelState('u157', 'pd1u157','none','',500,'none','',500);

}

}

var u192 = document.getElementById('u192');
gv_vAlignTable['u192'] = 'center';
var u67 = document.getElementById('u67');

var u412 = document.getElementById('u412');
gv_vAlignTable['u412'] = 'top';
var u390 = document.getElementById('u390');
gv_vAlignTable['u390'] = 'top';
var u150 = document.getElementById('u150');

var u287 = document.getElementById('u287');
gv_vAlignTable['u287'] = 'top';
var u607 = document.getElementById('u607');
gv_vAlignTable['u607'] = 'top';
var u585 = document.getElementById('u585');
gv_vAlignTable['u585'] = 'top';
var u144 = document.getElementById('u144');

var u479 = document.getElementById('u479');
gv_vAlignTable['u479'] = 'top';
var u327 = document.getElementById('u327');
gv_vAlignTable['u327'] = 'top';
var u643 = document.getElementById('u643');

var u318 = document.getElementById('u318');

var u462 = document.getElementById('u462');
gv_vAlignTable['u462'] = 'top';
var u476 = document.getElementById('u476');
gv_vAlignTable['u476'] = 'top';
var u135 = document.getElementById('u135');

u135.style.cursor = 'pointer';
if (bIE) u135.attachEvent("onclick", Clicku135);
else u135.addEventListener("click", Clicku135, true);
function Clicku135(e)
{
windowEvent = e;


if (true) {

	SetPanelState('u141', 'pd5u141','none','',500,'none','',500);

}

}

var u449 = document.getElementById('u449');

var u85 = document.getElementById('u85');

var u411 = document.getElementById('u411');

var u330 = document.getElementById('u330');

var u176 = document.getElementById('u176');

var u286 = document.getElementById('u286');

var u606 = document.getElementById('u606');

var u584 = document.getElementById('u584');

var u58 = document.getElementById('u58');
gv_vAlignTable['u58'] = 'center';
var u425 = document.getElementById('u425');

var u344 = document.getElementById('u344');

var u375 = document.getElementById('u375');

var u642 = document.getElementById('u642');

var u163 = document.getElementById('u163');
gv_vAlignTable['u163'] = 'center';
var u461 = document.getElementById('u461');

var u32 = document.getElementById('u32');

var u280 = document.getElementById('u280');
gv_vAlignTable['u280'] = 'top';
var u177 = document.getElementById('u177');
gv_vAlignTable['u177'] = 'center';
var u180 = document.getElementById('u180');

var u475 = document.getElementById('u475');

var u203 = document.getElementById('u203');

var u529 = document.getElementById('u529');
gv_vAlignTable['u529'] = 'top';
var u448 = document.getElementById('u448');
gv_vAlignTable['u448'] = 'top';
var u112 = document.getElementById('u112');

var u60 = document.getElementById('u60');
gv_vAlignTable['u60'] = 'center';
var u410 = document.getElementById('u410');
gv_vAlignTable['u410'] = 'top';
var u186 = document.getElementById('u186');
gv_vAlignTable['u186'] = 'center';
var u70 = document.getElementById('u70');
gv_vAlignTable['u70'] = 'center';
var u307 = document.getElementById('u307');
gv_vAlignTable['u307'] = 'top';
var u285 = document.getElementById('u285');

var u605 = document.getElementById('u605');

var u18 = document.getElementById('u18');

u18.style.cursor = 'pointer';
if (bIE) u18.attachEvent("onclick", Clicku18);
else u18.addEventListener("click", Clicku18, true);
function Clicku18(e)
{
windowEvent = e;


if (true) {

	SetPanelState('u23', 'pd1u23','none','',500,'none','',500);

}

}

var u50 = document.getElementById('u50');

var u424 = document.getElementById('u424');
gv_vAlignTable['u424'] = 'top';
var u343 = document.getElementById('u343');
gv_vAlignTable['u343'] = 'top';
var u579 = document.getElementById('u579');

var u47 = document.getElementById('u47');

var u162 = document.getElementById('u162');

var u541 = document.getElementById('u541');
gv_vAlignTable['u541'] = 'top';
var u460 = document.getElementById('u460');
gv_vAlignTable['u460'] = 'top';
var u597 = document.getElementById('u597');

var u207 = document.getElementById('u207');

var u357 = document.getElementById('u357');

var u79 = document.getElementById('u79');
gv_vAlignTable['u79'] = 'top';
var u521 = document.getElementById('u521');
gv_vAlignTable['u521'] = 'top';
var u55 = document.getElementById('u55');
gv_vAlignTable['u55'] = 'top';
var u474 = document.getElementById('u474');

var u149 = document.getElementById('u149');
gv_vAlignTable['u149'] = 'top';
var u528 = document.getElementById('u528');

var u111 = document.getElementById('u111');
gv_vAlignTable['u111'] = 'center';
var u332 = document.getElementById('u332');

var u527 = document.getElementById('u527');
gv_vAlignTable['u527'] = 'top';
var u123 = document.getElementById('u123');
gv_vAlignTable['u123'] = 'center';
var u306 = document.getElementById('u306');

var u284 = document.getElementById('u284');

var u604 = document.getElementById('u604');

var u12 = document.getElementById('u12');

x = 0;
y = 0;
InsertAfterBegin(document.getElementById('u12ann'), "<div id='u12Note' class='annnoteimage' style='left:" + x + ";top:" + y + "'></div>");
$('#u12Note').click(function(e) { ToggleWorkflow(e, 'u12', 300, 150, false); return false; });
var u12Ann = 
{
"label":"?",
"Description":"当前窗口打开具体链接未定"};

u12.style.cursor = 'pointer';
if (bIE) u12.attachEvent("onclick", Clicku12);
else u12.addEventListener("click", Clicku12, true);
function Clicku12(e)
{
windowEvent = e;


if (true) {

	self.location.href="账号管理.html" + GetQuerystring();

}

}
gv_vAlignTable['u12'] = 'top';
var u423 = document.getElementById('u423');

var u342 = document.getElementById('u342');

var u578 = document.getElementById('u578');

var u161 = document.getElementById('u161');
gv_vAlignTable['u161'] = 'center';
var u540 = document.getElementById('u540');

var u596 = document.getElementById('u596');
gv_vAlignTable['u596'] = 'top';
var u437 = document.getElementById('u437');

var u356 = document.getElementById('u356');
gv_vAlignTable['u356'] = 'top';
var u388 = document.getElementById('u388');
gv_vAlignTable['u388'] = 'top';
var u554 = document.getElementById('u554');

var u473 = document.getElementById('u473');
gv_vAlignTable['u473'] = 'top';
var u148 = document.getElementById('u148');
gv_vAlignTable['u148'] = 'top';
var u57 = document.getElementById('u57');

var u110 = document.getElementById('u110');

var u611 = document.getElementById('u611');

var u305 = document.getElementById('u305');
gv_vAlignTable['u305'] = 'top';
var u283 = document.getElementById('u283');

var u603 = document.getElementById('u603');
gv_vAlignTable['u603'] = 'top';
var u124 = document.getElementById('u124');

u124.style.cursor = 'pointer';
if (bIE) u124.attachEvent("onclick", Clicku124);
else u124.addEventListener("click", Clicku124, true);
function Clicku124(e)
{
windowEvent = e;


if (true) {

	SetPanelState('u141', 'pd8u141','none','',500,'none','',500);

}

}

var u272 = document.getElementById('u272');
gv_vAlignTable['u272'] = 'center';
var u422 = document.getElementById('u422');
gv_vAlignTable['u422'] = 'top';
var u38 = document.getElementById('u38');
gv_vAlignTable['u38'] = 'top';
var u241 = document.getElementById('u241');
gv_vAlignTable['u241'] = 'top';
var u160 = document.getElementById('u160');

var u297 = document.getElementById('u297');
gv_vAlignTable['u297'] = 'top';
var u8 = document.getElementById('u8');

u8.style.cursor = 'pointer';
if (bIE) u8.attachEvent("onclick", Clicku8);
else u8.addEventListener("click", Clicku8, true);
function Clicku8(e)
{
windowEvent = e;


if (true) {

	self.location.href="#" + GetQuerystring();

}

}
gv_vAlignTable['u8'] = 'top';
var u595 = document.getElementById('u595');

var u436 = document.getElementById('u436');
gv_vAlignTable['u436'] = 'top';
var u355 = document.getElementById('u355');
gv_vAlignTable['u355'] = 'top';
var u66 = document.getElementById('u66');
gv_vAlignTable['u66'] = 'center';
var u409 = document.getElementById('u409');

var u309 = document.getElementById('u309');
gv_vAlignTable['u309'] = 'top';
var u553 = document.getElementById('u553');
gv_vAlignTable['u553'] = 'top';
var u472 = document.getElementById('u472');
gv_vAlignTable['u472'] = 'top';
var u106 = document.getElementById('u106');

u106.style.cursor = 'pointer';
if (bIE) u106.attachEvent("onclick", Clicku106);
else u106.addEventListener("click", Clicku106, true);
function Clicku106(e)
{
windowEvent = e;


if (true) {

	SetPanelState('u64', 'pd0u64','none','',500,'none','',500);

}

}
gv_vAlignTable['u106'] = 'top';
var u81 = document.getElementById('u81');
gv_vAlignTable['u81'] = 'top';
var u233 = document.getElementById('u233');

var u328 = document.getElementById('u328');

var u567 = document.getElementById('u567');
gv_vAlignTable['u567'] = 'top';
var u617 = document.getElementById('u617');

var u304 = document.getElementById('u304');

var u282 = document.getElementById('u282');

var u459 = document.getElementById('u459');

var u580 = document.getElementById('u580');
gv_vAlignTable['u580'] = 'top';
var u191 = document.getElementById('u191');

var u421 = document.getElementById('u421');

var u240 = document.getElementById('u240');

var u296 = document.getElementById('u296');

var u616 = document.getElementById('u616');
gv_vAlignTable['u616'] = 'top';
var u137 = document.getElementById('u137');

u137.style.cursor = 'pointer';
if (bIE) u137.attachEvent("onclick", Clicku137);
else u137.addEventListener("click", Clicku137, true);
function Clicku137(e)
{
windowEvent = e;


if (true) {

	SetPanelState('u141', 'pd4u141','none','',500,'none','',500);

}

}

var u435 = document.getElementById('u435');

var u33 = document.getElementById('u33');

var u408 = document.getElementById('u408');
gv_vAlignTable['u408'] = 'top';
var u173 = document.getElementById('u173');
gv_vAlignTable['u173'] = 'top';
var u552 = document.getElementById('u552');

var u471 = document.getElementById('u471');

var u290 = document.getElementById('u290');

var u99 = document.getElementById('u99');
gv_vAlignTable['u99'] = 'center';
var u566 = document.getElementById('u566');

var u303 = document.getElementById('u303');
gv_vAlignTable['u303'] = 'top';
var u539 = document.getElementById('u539');
gv_vAlignTable['u539'] = 'top';
var u601 = document.getElementById('u601');
gv_vAlignTable['u601'] = 'top';
var u122 = document.getElementById('u122');

u122.style.cursor = 'pointer';
if (bIE) u122.attachEvent("onclick", Clicku122);
else u122.addEventListener("click", Clicku122, true);
function Clicku122(e)
{
windowEvent = e;


if (true) {

	SetPanelState('u64', 'pd1u64','none','',500,'none','',500);

}

}

var u358 = document.getElementById('u358');

var u420 = document.getElementById('u420');
gv_vAlignTable['u420'] = 'top';
var u5 = document.getElementById('u5');

u5.style.cursor = 'pointer';
if (bIE) u5.attachEvent("onclick", Clicku5);
else u5.addEventListener("click", Clicku5, true);
function Clicku5(e)
{
windowEvent = e;


if (true) {

	self.location.href="#" + GetQuerystring();

}

}
gv_vAlignTable['u5'] = 'top';
var u268 = document.getElementById('u268');
gv_vAlignTable['u268'] = 'center';
var u381 = document.getElementById('u381');

var u317 = document.getElementById('u317');
gv_vAlignTable['u317'] = 'top';
var u295 = document.getElementById('u295');
gv_vAlignTable['u295'] = 'top';
var u615 = document.getElementById('u615');

var u593 = document.getElementById('u593');
gv_vAlignTable['u593'] = 'top';
var u512 = document.getElementById('u512');

var u434 = document.getElementById('u434');
gv_vAlignTable['u434'] = 'top';
var u109 = document.getElementById('u109');
gv_vAlignTable['u109'] = 'center';
var u69 = document.getElementById('u69');

var u253 = document.getElementById('u253');
gv_vAlignTable['u253'] = 'top';
var u172 = document.getElementById('u172');
gv_vAlignTable['u172'] = 'top';
var u551 = document.getElementById('u551');
gv_vAlignTable['u551'] = 'top';
var u470 = document.getElementById('u470');
gv_vAlignTable['u470'] = 'top';
var u25 = document.getElementById('u25');
gv_vAlignTable['u25'] = 'top';
var u359 = document.getElementById('u359');

var u465 = document.getElementById('u465');

var u267 = document.getElementById('u267');

var u399 = document.getElementById('u399');

var u565 = document.getElementById('u565');
gv_vAlignTable['u565'] = 'top';
var u229 = document.getElementById('u229');
gv_vAlignTable['u229'] = 'top';
var u302 = document.getElementById('u302');

var u538 = document.getElementById('u538');

var u45 = document.getElementById('u45');

var u121 = document.getElementById('u121');
gv_vAlignTable['u121'] = 'center';
var u500 = document.getElementById('u500');

var u490 = document.getElementById('u490');
gv_vAlignTable['u490'] = 'top';
var u316 = document.getElementById('u316');

var u294 = document.getElementById('u294');

var u614 = document.getElementById('u614');

var u592 = document.getElementById('u592');

var u433 = document.getElementById('u433');

var u108 = document.getElementById('u108');

var u252 = document.getElementById('u252');
gv_vAlignTable['u252'] = 'top';
var u171 = document.getElementById('u171');
gv_vAlignTable['u171'] = 'top';
var u550 = document.getElementById('u550');

var u98 = document.getElementById('u98');

var u21 = document.getElementById('u21');

u21.style.cursor = 'pointer';
if (bIE) u21.attachEvent("onclick", Clicku21);
else u21.addEventListener("click", Clicku21, true);
function Clicku21(e)
{
windowEvent = e;


if (true) {

	SetPanelState('u23', 'pd0u23','none','',500,'none','',500);

}

}

var u447 = document.getElementById('u447');

var u533 = document.getElementById('u533');
gv_vAlignTable['u533'] = 'top';
var u266 = document.getElementById('u266');
gv_vAlignTable['u266'] = 'center';
var u398 = document.getElementById('u398');
gv_vAlignTable['u398'] = 'top';
var u564 = document.getElementById('u564');

var u239 = document.getElementById('u239');

var u301 = document.getElementById('u301');
gv_vAlignTable['u301'] = 'top';
var u91 = document.getElementById('u91');

var u49 = document.getElementById('u49');
gv_vAlignTable['u49'] = 'center';
var u371 = document.getElementById('u371');

var u2 = document.getElementById('u2');

u2.style.cursor = 'pointer';
if (bIE) u2.attachEvent("onclick", Clicku2);
else u2.addEventListener("click", Clicku2, true);
function Clicku2(e)
{
windowEvent = e;


if (true) {

	self.location.href="#" + GetQuerystring();

}

}

var u76 = document.getElementById('u76');
gv_vAlignTable['u76'] = 'top';
var u113 = document.getElementById('u113');
gv_vAlignTable['u113'] = 'center';
var u169 = document.getElementById('u169');
gv_vAlignTable['u169'] = 'top';
var u315 = document.getElementById('u315');
gv_vAlignTable['u315'] = 'top';
var u293 = document.getElementById('u293');
gv_vAlignTable['u293'] = 'top';
var u638 = document.getElementById('u638');
gv_vAlignTable['u638'] = 'top';
var u134 = document.getElementById('u134');
gv_vAlignTable['u134'] = 'center';
var u513 = document.getElementById('u513');
gv_vAlignTable['u513'] = 'top';
var u432 = document.getElementById('u432');
gv_vAlignTable['u432'] = 'top';
var u251 = document.getElementById('u251');

var u170 = document.getElementById('u170');
gv_vAlignTable['u170'] = 'top';
var u627 = document.getElementById('u627');

var u224 = document.getElementById('u224');

var u446 = document.getElementById('u446');
gv_vAlignTable['u446'] = 'top';
var u373 = document.getElementById('u373');

var u419 = document.getElementById('u419');

var u82 = document.getElementById('u82');
gv_vAlignTable['u82'] = 'top';
var u581 = document.getElementById('u581');

var u238 = document.getElementById('u238');
gv_vAlignTable['u238'] = 'top';
var u200 = document.getElementById('u200');
gv_vAlignTable['u200'] = 'top';
var u279 = document.getElementById('u279');
gv_vAlignTable['u279'] = 'top';
var u577 = document.getElementById('u577');
gv_vAlignTable['u577'] = 'top';
var u35 = document.getElementById('u35');

var u314 = document.getElementById('u314');

var u292 = document.getElementById('u292');

var u225 = document.getElementById('u225');

var u133 = document.getElementById('u133');

u133.style.cursor = 'pointer';
if (bIE) u133.attachEvent("onclick", Clicku133);
else u133.addEventListener("click", Clicku133, true);
function Clicku133(e)
{
windowEvent = e;


if (true) {

	SetPanelState('u141', 'pd7u141','none','',500,'none','',500);

}

}

var u369 = document.getElementById('u369');

var u431 = document.getElementById('u431');

var u30 = document.getElementById('u30');

var u250 = document.getElementById('u250');
gv_vAlignTable['u250'] = 'top';
var u387 = document.getElementById('u387');

var u147 = document.getElementById('u147');
gv_vAlignTable['u147'] = 'top';
var u526 = document.getElementById('u526');

var u445 = document.getElementById('u445');

var u34 = document.getElementById('u34');

var u418 = document.getElementById('u418');
gv_vAlignTable['u418'] = 'top';
var u36 = document.getElementById('u36');

var u562 = document.getElementById('u562');

var u61 = document.getElementById('u61');

u61.style.cursor = 'pointer';
if (bIE) u61.attachEvent("onclick", Clicku61);
else u61.addEventListener("click", Clicku61, true);
function Clicku61(e)
{
windowEvent = e;


if (true) {

	SetPanelState('u64', 'pd1u64','none','',500,'none','',500);

}

}

var u164 = document.getElementById('u164');

var u576 = document.getElementById('u576');

var u80 = document.getElementById('u80');
gv_vAlignTable['u80'] = 'top';
var u549 = document.getElementById('u549');
gv_vAlignTable['u549'] = 'top';
var u213 = document.getElementById('u213');
gv_vAlignTable['u213'] = 'center';
var u132 = document.getElementById('u132');
gv_vAlignTable['u132'] = 'center';
var u368 = document.getElementById('u368');
gv_vAlignTable['u368'] = 'top';
var u430 = document.getElementById('u430');
gv_vAlignTable['u430'] = 'top';
var u386 = document.getElementById('u386');
gv_vAlignTable['u386'] = 'top';
var u146 = document.getElementById('u146');
gv_vAlignTable['u146'] = 'top';
var u525 = document.getElementById('u525');
gv_vAlignTable['u525'] = 'top';
var u444 = document.getElementById('u444');
gv_vAlignTable['u444'] = 'top';
var u125 = document.getElementById('u125');
gv_vAlignTable['u125'] = 'center';
var u263 = document.getElementById('u263');

var u24 = document.getElementById('u24');

var u561 = document.getElementById('u561');
gv_vAlignTable['u561'] = 'top';
var u166 = document.getElementById('u166');

var u632 = document.getElementById('u632');
gv_vAlignTable['u632'] = 'top';
var u277 = document.getElementById('u277');

var u575 = document.getElementById('u575');
gv_vAlignTable['u575'] = 'top';
var u629 = document.getElementById('u629');

var u548 = document.getElementById('u548');

var u212 = document.getElementById('u212');

u212.style.cursor = 'pointer';
if (bIE) u212.attachEvent("onclick", Clicku212);
else u212.addEventListener("click", Clicku212, true);
function Clicku212(e)
{
windowEvent = e;


if (true) {

	SetPanelState('u157', 'pd1u157','none','',500,'none','',500);

}

}

var u131 = document.getElementById('u131');

u131.style.cursor = 'pointer';
if (bIE) u131.attachEvent("onclick", Clicku131);
else u131.addEventListener("click", Clicku131, true);
function Clicku131(e)
{
windowEvent = e;


if (true) {

	SetPanelState('u141', 'pd6u141','none','',500,'none','',500);

}

}

var u510 = document.getElementById('u510');

var u573 = document.getElementById('u573');
gv_vAlignTable['u573'] = 'top';
var u407 = document.getElementById('u407');

var u385 = document.getElementById('u385');

var u226 = document.getElementById('u226');
gv_vAlignTable['u226'] = 'top';
var u145 = document.getElementById('u145');

var u524 = document.getElementById('u524');

var u443 = document.getElementById('u443');

var u100 = document.getElementById('u100');

var u262 = document.getElementById('u262');
gv_vAlignTable['u262'] = 'top';
var u641 = document.getElementById('u641');

var u560 = document.getElementById('u560');

var u457 = document.getElementById('u457');

var u489 = document.getElementById('u489');

var u65 = document.getElementById('u65');

var u574 = document.getElementById('u574');
gv_vAlignTable['u574'] = 'top';
var u249 = document.getElementById('u249');
gv_vAlignTable['u249'] = 'top';
var u628 = document.getElementById('u628');
gv_vAlignTable['u628'] = 'top';
var u20 = document.getElementById('u20');

var u130 = document.getElementById('u130');
gv_vAlignTable['u130'] = 'center';
var u345 = document.getElementById('u345');
gv_vAlignTable['u345'] = 'top';
var u39 = document.getElementById('u39');

var u406 = document.getElementById('u406');
gv_vAlignTable['u406'] = 'top';
var u384 = document.getElementById('u384');
gv_vAlignTable['u384'] = 'top';
var u22 = document.getElementById('u22');
gv_vAlignTable['u22'] = 'center';
var u364 = document.getElementById('u364');
gv_vAlignTable['u364'] = 'top';
var u523 = document.getElementById('u523');
gv_vAlignTable['u523'] = 'top';
var u442 = document.getElementById('u442');
gv_vAlignTable['u442'] = 'top';
var u261 = document.getElementById('u261');

var u640 = document.getElementById('u640');

var u175 = document.getElementById('u175');
gv_vAlignTable['u175'] = 'top';
var u43 = document.getElementById('u43');
gv_vAlignTable['u43'] = 'top';
var u537 = document.getElementById('u537');
gv_vAlignTable['u537'] = 'top';
var u456 = document.getElementById('u456');
gv_vAlignTable['u456'] = 'top';
var u488 = document.getElementById('u488');

var u178 = document.getElementById('u178');

var u16 = document.getElementById('u16');

var u289 = document.getElementById('u289');
gv_vAlignTable['u289'] = 'top';
var u210 = document.getElementById('u210');

u210.style.cursor = 'pointer';
if (bIE) u210.attachEvent("onclick", Clicku210);
else u210.addEventListener("click", Clicku210, true);
function Clicku210(e)
{
windowEvent = e;


if (true) {

	SetPanelState('u157', 'pd1u157','none','',500,'none','',500);

}

}

var u83 = document.getElementById('u83');

var u107 = document.getElementById('u107');
gv_vAlignTable['u107'] = 'top';
var u44 = document.getElementById('u44');

var u405 = document.getElementById('u405');

var u383 = document.getElementById('u383');

var u202 = document.getElementById('u202');
gv_vAlignTable['u202'] = 'center';
var u136 = document.getElementById('u136');
gv_vAlignTable['u136'] = 'center';
var u329 = document.getElementById('u329');
gv_vAlignTable['u329'] = 'top';
var u379 = document.getElementById('u379');

var u341 = document.getElementById('u341');
gv_vAlignTable['u341'] = 'top';
var u260 = document.getElementById('u260');
gv_vAlignTable['u260'] = 'top';
var u397 = document.getElementById('u397');

var u9 = document.getElementById('u9');

x = 0;
y = 0;
InsertAfterBegin(document.getElementById('u9ann'), "<div id='u9Note' class='annnoteimage' style='left:" + x + ";top:" + y + "'></div>");
$('#u9Note').click(function(e) { ToggleWorkflow(e, 'u9', 300, 150, false); return false; });
var u9Ann = 
{
"label":"?",
"Description":"当前窗口打开具体链接未定"};

u9.style.cursor = 'pointer';
if (bIE) u9.attachEvent("onclick", Clicku9);
else u9.addEventListener("click", Clicku9, true);
function Clicku9(e)
{
windowEvent = e;


if (true) {

	self.location.href="#" + GetQuerystring();

}

}
gv_vAlignTable['u9'] = 'top';
var u157 = document.getElementById('u157');

var u536 = document.getElementById('u536');

var u455 = document.getElementById('u455');

var u189 = document.getElementById('u189');

var u509 = document.getElementById('u509');

var u274 = document.getElementById('u274');
gv_vAlignTable['u274'] = 'center';
var u227 = document.getElementById('u227');

var u572 = document.getElementById('u572');
gv_vAlignTable['u572'] = 'top';
var u94 = document.getElementById('u94');

var u246 = document.getElementById('u246');

var u174 = document.getElementById('u174');
gv_vAlignTable['u174'] = 'top';
var u454 = document.getElementById('u454');
gv_vAlignTable['u454'] = 'top';
var u404 = document.getElementById('u404');
gv_vAlignTable['u404'] = 'top';
var u382 = document.getElementById('u382');
gv_vAlignTable['u382'] = 'top';
var u559 = document.getElementById('u559');
gv_vAlignTable['u559'] = 'top';
var u223 = document.getElementById('u223');
gv_vAlignTable['u223'] = 'top';
var u142 = document.getElementById('u142');

var u378 = document.getElementById('u378');
gv_vAlignTable['u378'] = 'top';
var u331 = document.getElementById('u331');
gv_vAlignTable['u331'] = 'top';
var u340 = document.getElementById('u340');

var u396 = document.getElementById('u396');
gv_vAlignTable['u396'] = 'top';
var u237 = document.getElementById('u237');

var u156 = document.getElementById('u156');
gv_vAlignTable['u156'] = 'top';
var u535 = document.getElementById('u535');
gv_vAlignTable['u535'] = 'top';
var u188 = document.getElementById('u188');
gv_vAlignTable['u188'] = 'center';
var u354 = document.getElementById('u354');
gv_vAlignTable['u354'] = 'top';
var u273 = document.getElementById('u273');

var u571 = document.getElementById('u571');
gv_vAlignTable['u571'] = 'top';
var u102 = document.getElementById('u102');

u102.style.cursor = 'pointer';
if (bIE) u102.attachEvent("onclick", Clicku102);
else u102.addEventListener("click", Clicku102, true);
function Clicku102(e)
{
windowEvent = e;


if (true) {

	SetPanelState('u64', 'pd0u64','none','',500,'none','',500);

}

}

var u275 = document.getElementById('u275');
gv_vAlignTable['u275'] = 'top';
var u53 = document.getElementById('u53');
gv_vAlignTable['u53'] = 'center';
var u105 = document.getElementById('u105');

u105.style.cursor = 'pointer';
if (bIE) u105.attachEvent("onclick", Clicku105);
else u105.addEventListener("click", Clicku105, true);
function Clicku105(e)
{
windowEvent = e;


if (true) {

	SetPanelState('u64', 'pd0u64','none','',500,'none','',500);

}

}
gv_vAlignTable['u105'] = 'top';
var u403 = document.getElementById('u403');

var u639 = document.getElementById('u639');

var u583 = document.getElementById('u583');
gv_vAlignTable['u583'] = 'top';
var u458 = document.getElementById('u458');
gv_vAlignTable['u458'] = 'top';
var u520 = document.getElementById('u520');

var u6 = document.getElementById('u6');

u6.style.cursor = 'pointer';
if (bIE) u6.attachEvent("onclick", Clicku6);
else u6.addEventListener("click", Clicku6, true);
function Clicku6(e)
{
windowEvent = e;


if (true) {

	self.location.href="采购首页.html" + GetQuerystring();

}

}
gv_vAlignTable['u6'] = 'top';
var u417 = document.getElementById('u417');

var u395 = document.getElementById('u395');

var u264 = document.getElementById('u264');
gv_vAlignTable['u264'] = 'center';
var u236 = document.getElementById('u236');

var u155 = document.getElementById('u155');
gv_vAlignTable['u155'] = 'center';
var u534 = document.getElementById('u534');

var u209 = document.getElementById('u209');

var u353 = document.getElementById('u353');
gv_vAlignTable['u353'] = 'top';
var u376 = document.getElementById('u376');
gv_vAlignTable['u376'] = 'top';
var u651 = document.getElementById('u651');
gv_vAlignTable['u651'] = 'center';
var u570 = document.getElementById('u570');

var u120 = document.getElementById('u120');

u120.style.cursor = 'pointer';
if (bIE) u120.attachEvent("onclick", Clicku120);
else u120.addEventListener("click", Clicku120, true);
function Clicku120(e)
{
windowEvent = e;


if (true) {

	SetPanelState('u64', 'pd1u64','none','',500,'none','',500);

}

}

var u269 = document.getElementById('u269');

var u19 = document.getElementById('u19');
gv_vAlignTable['u19'] = 'center';
var u367 = document.getElementById('u367');

var u499 = document.getElementById('u499');

var u104 = document.getElementById('u104');
gv_vAlignTable['u104'] = 'center';
var u402 = document.getElementById('u402');
gv_vAlignTable['u402'] = 'top';
var u380 = document.getElementById('u380');
gv_vAlignTable['u380'] = 'top';
var u86 = document.getElementById('u86');
gv_vAlignTable['u86'] = 'center';
var u221 = document.getElementById('u221');

var u600 = document.getElementById('u600');

var u228 = document.getElementById('u228');

var u119 = document.getElementById('u119');
gv_vAlignTable['u119'] = 'center';
var u232 = document.getElementById('u232');
gv_vAlignTable['u232'] = 'top';
var u427 = document.getElementById('u427');

var u416 = document.getElementById('u416');
gv_vAlignTable['u416'] = 'top';
var u394 = document.getElementById('u394');
gv_vAlignTable['u394'] = 'top';
var u51 = document.getElementById('u51');
gv_vAlignTable['u51'] = 'center';
var u235 = document.getElementById('u235');
gv_vAlignTable['u235'] = 'top';
var u13 = document.getElementById('u13');

x = 0;
y = 0;
InsertAfterBegin(document.getElementById('u13ann'), "<div id='u13Note' class='annnoteimage' style='left:" + x + ";top:" + y + "'></div>");
$('#u13Note').click(function(e) { ToggleWorkflow(e, 'u13', 300, 150, false); return false; });
var u13Ann = 
{
"label":"?",
"Description":"当前窗口打开具体链接未定"};

u13.style.cursor = 'pointer';
if (bIE) u13.attachEvent("onclick", Clicku13);
else u13.addEventListener("click", Clicku13, true);
function Clicku13(e)
{
windowEvent = e;


if (true) {

	self.location.href="#" + GetQuerystring();

}

}
gv_vAlignTable['u13'] = 'top';
var u208 = document.getElementById('u208');
gv_vAlignTable['u208'] = 'center';
var u46 = document.getElementById('u46');
gv_vAlignTable['u46'] = 'top';
var u352 = document.getElementById('u352');

var u271 = document.getElementById('u271');

var u650 = document.getElementById('u650');

u650.style.cursor = 'pointer';
if (bIE) u650.attachEvent("onclick", Clicku650);
else u650.addEventListener("click", Clicku650, true);
function Clicku650(e)
{
windowEvent = e;


if (true) {

	SetPanelState('u141', 'pd2u141','none','',500,'none','',500);

}

}

var u52 = document.getElementById('u52');

var u547 = document.getElementById('u547');
gv_vAlignTable['u547'] = 'top';
var u531 = document.getElementById('u531');
gv_vAlignTable['u531'] = 'top';
var u366 = document.getElementById('u366');
gv_vAlignTable['u366'] = 'top';
var u498 = document.getElementById('u498');

var u103 = document.getElementById('u103');

var u339 = document.getElementById('u339');
gv_vAlignTable['u339'] = 'top';
var u401 = document.getElementById('u401');

var u276 = document.getElementById('u276');
gv_vAlignTable['u276'] = 'top';
var u220 = document.getElementById('u220');
gv_vAlignTable['u220'] = 'top';
var u3 = document.getElementById('u3');
gv_vAlignTable['u3'] = 'center';
var u74 = document.getElementById('u74');
gv_vAlignTable['u74'] = 'center';
var u117 = document.getElementById('u117');

var u415 = document.getElementById('u415');

var u393 = document.getElementById('u393');

var u31 = document.getElementById('u31');

var u234 = document.getElementById('u234');

var u613 = document.getElementById('u613');

var u591 = document.getElementById('u591');

var u426 = document.getElementById('u426');
gv_vAlignTable['u426'] = 'top';
var u270 = document.getElementById('u270');
gv_vAlignTable['u270'] = 'center';
var u254 = document.getElementById('u254');
gv_vAlignTable['u254'] = 'top';
var u546 = document.getElementById('u546');

var u27 = document.getElementById('u27');

var u511 = document.getElementById('u511');

var u365 = document.getElementById('u365');

var u168 = document.getElementById('u168');

var u26 = document.getElementById('u26');

var u594 = document.getElementById('u594');

var u300 = document.getElementById('u300');

var u351 = document.getElementById('u351');

var u116 = document.getElementById('u116');

var u414 = document.getElementById('u414');
gv_vAlignTable['u414'] = 'top';
var u392 = document.getElementById('u392');
gv_vAlignTable['u392'] = 'top';
var u602 = document.getElementById('u602');

var u222 = document.getElementById('u222');

var u612 = document.getElementById('u612');
gv_vAlignTable['u612'] = 'top';
var u590 = document.getElementById('u590');
gv_vAlignTable['u590'] = 'top';
var u350 = document.getElementById('u350');
gv_vAlignTable['u350'] = 'top';
var u487 = document.getElementById('u487');
gv_vAlignTable['u487'] = 'top';
var u508 = document.getElementById('u508');

var u247 = document.getElementById('u247');
gv_vAlignTable['u247'] = 'top';
var u626 = document.getElementById('u626');

var u545 = document.getElementById('u545');
gv_vAlignTable['u545'] = 'top';
var u198 = document.getElementById('u198');

u198.style.cursor = 'pointer';
if (bIE) u198.attachEvent("onclick", Clicku198);
else u198.addEventListener("click", Clicku198, true);
function Clicku198(e)
{
windowEvent = e;


if (true) {

	SetPanelState('u157', 'pd0u157','none','',500,'none','',500);

}

}
gv_vAlignTable['u198'] = 'top';
var u518 = document.getElementById('u518');

var u29 = document.getElementById('u29');
gv_vAlignTable['u29'] = 'top';
var u101 = document.getElementById('u101');

u101.style.cursor = 'pointer';
if (bIE) u101.attachEvent("onclick", Clicku101);
else u101.addEventListener("click", Clicku101, true);
function Clicku101(e)
{
windowEvent = e;


if (true) {

	SetPanelState('u64', 'pd0u64','none','',500,'none','',500);

}

}

var u0 = document.getElementById('u0');

var u338 = document.getElementById('u338');

var u87 = document.getElementById('u87');

var u89 = document.getElementById('u89');

var u77 = document.getElementById('u77');
gv_vAlignTable['u77'] = 'top';
var u649 = document.getElementById('u649');
gv_vAlignTable['u649'] = 'center';
var u313 = document.getElementById('u313');
gv_vAlignTable['u313'] = 'top';
var u291 = document.getElementById('u291');
gv_vAlignTable['u291'] = 'top';
var u618 = document.getElementById('u618');
gv_vAlignTable['u618'] = 'top';
var u530 = document.getElementById('u530');

var u486 = document.getElementById('u486');

var u7 = document.getElementById('u7');

u7.style.cursor = 'pointer';
if (bIE) u7.attachEvent("onclick", Clicku7);
else u7.addEventListener("click", Clicku7, true);
function Clicku7(e)
{
windowEvent = e;


if (true) {

}

}
gv_vAlignTable['u7'] = 'top';
var u118 = document.getElementById('u118');

u118.style.cursor = 'pointer';
if (bIE) u118.attachEvent("onclick", Clicku118);
else u118.addEventListener("click", Clicku118, true);
function Clicku118(e)
{
windowEvent = e;


if (true) {

	SetPanelState('u64', 'pd1u64','none','',500,'none','',500);

}

}

var u281 = document.getElementById('u281');
gv_vAlignTable['u281'] = 'top';
var u625 = document.getElementById('u625');

var u544 = document.getElementById('u544');

var u219 = document.getElementById('u219');

var u363 = document.getElementById('u363');

var u56 = document.getElementById('u56');

var u211 = document.getElementById('u211');
gv_vAlignTable['u211'] = 'center';
var u265 = document.getElementById('u265');

var u377 = document.getElementById('u377');

var u372 = document.getElementById('u372');
gv_vAlignTable['u372'] = 'top';
var u114 = document.getElementById('u114');

var u48 = document.getElementById('u48');

var u648 = document.getElementById('u648');

u648.style.cursor = 'pointer';
if (bIE) u648.attachEvent("onclick", Clicku648);
else u648.addEventListener("click", Clicku648, true);
function Clicku648(e)
{
windowEvent = e;


if (true) {

	SetPanelState('u141', 'pd9u141','none','',500,'none','',500);

}

}

var u312 = document.getElementById('u312');

var u503 = document.getElementById('u503');

var u610 = document.getElementById('u610');
gv_vAlignTable['u610'] = 'top';
var u278 = document.getElementById('u278');
gv_vAlignTable['u278'] = 'top';
var u187 = document.getElementById('u187');

var u507 = document.getElementById('u507');
gv_vAlignTable['u507'] = 'top';
var u485 = document.getElementById('u485');

var u326 = document.getElementById('u326');

var u245 = document.getElementById('u245');

var u522 = document.getElementById('u522');

var u543 = document.getElementById('u543');
gv_vAlignTable['u543'] = 'top';
var u218 = document.getElementById('u218');

var u362 = document.getElementById('u362');
gv_vAlignTable['u362'] = 'top';
var u557 = document.getElementById('u557');
gv_vAlignTable['u557'] = 'top';
var u59 = document.getElementById('u59');

var u589 = document.getElementById('u589');

var u75 = document.getElementById('u75');

var u349 = document.getElementById('u349');
gv_vAlignTable['u349'] = 'top';
var u311 = document.getElementById('u311');
gv_vAlignTable['u311'] = 'top';
var u230 = document.getElementById('u230');

var u519 = document.getElementById('u519');
gv_vAlignTable['u519'] = 'top';
var u127 = document.getElementById('u127');

u127.style.cursor = 'pointer';
if (bIE) u127.attachEvent("onclick", Clicku127);
else u127.addEventListener("click", Clicku127, true);
function Clicku127(e)
{
windowEvent = e;


if (true) {

	SetPanelState('u141', 'pd0u141','none','',500,'none','',500);

}

}

var u506 = document.getElementById('u506');
gv_vAlignTable['u506'] = 'top';
var u484 = document.getElementById('u484');
gv_vAlignTable['u484'] = 'top';
var u325 = document.getElementById('u325');
gv_vAlignTable['u325'] = 'top';
var u244 = document.getElementById('u244');

var u623 = document.getElementById('u623');

var u542 = document.getElementById('u542');

var u361 = document.getElementById('u361');

var u248 = document.getElementById('u248');
gv_vAlignTable['u248'] = 'top';
var u637 = document.getElementById('u637');

var u556 = document.getElementById('u556');

var u588 = document.getElementById('u588');

var u429 = document.getElementById('u429');

var u348 = document.getElementById('u348');

var u97 = document.getElementById('u97');
gv_vAlignTable['u97'] = 'center';
var u73 = document.getElementById('u73');

var u310 = document.getElementById('u310');

var u143 = document.getElementById('u143');

var u179 = document.getElementById('u179');
gv_vAlignTable['u179'] = 'center';
var u185 = document.getElementById('u185');

var u505 = document.getElementById('u505');
gv_vAlignTable['u505'] = 'top';
var u483 = document.getElementById('u483');

var u40 = document.getElementById('u40');

var u324 = document.getElementById('u324');

var u243 = document.getElementById('u243');

var u622 = document.getElementById('u622');
gv_vAlignTable['u622'] = 'top';
var u441 = document.getElementById('u441');

var u360 = document.getElementById('u360');

var u497 = document.getElementById('u497');

var u532 = document.getElementById('u532');

var u257 = document.getElementById('u257');

var u636 = document.getElementById('u636');
gv_vAlignTable['u636'] = 'top';
var u555 = document.getElementById('u555');
gv_vAlignTable['u555'] = 'top';
var u478 = document.getElementById('u478');
gv_vAlignTable['u478'] = 'top';
var u609 = document.getElementById('u609');

var u374 = document.getElementById('u374');
gv_vAlignTable['u374'] = 'top';
var u428 = document.getElementById('u428');
gv_vAlignTable['u428'] = 'top';
var u37 = document.getElementById('u37');

var u165 = document.getElementById('u165');
gv_vAlignTable['u165'] = 'center';
var u115 = document.getElementById('u115');
gv_vAlignTable['u115'] = 'center';
var u206 = document.getElementById('u206');
gv_vAlignTable['u206'] = 'center';
var u184 = document.getElementById('u184');

var u504 = document.getElementById('u504');
gv_vAlignTable['u504'] = 'top';
var u482 = document.getElementById('u482');

var u323 = document.getElementById('u323');
gv_vAlignTable['u323'] = 'top';
var u242 = document.getElementById('u242');

var u621 = document.getElementById('u621');
gv_vAlignTable['u621'] = 'top';
var u440 = document.getElementById('u440');
gv_vAlignTable['u440'] = 'top';
var u496 = document.getElementById('u496');
gv_vAlignTable['u496'] = 'top';
var u64 = document.getElementById('u64');

var u337 = document.getElementById('u337');
gv_vAlignTable['u337'] = 'top';
var u256 = document.getElementById('u256');

var u635 = document.getElementById('u635');

var u288 = document.getElementById('u288');

var u608 = document.getElementById('u608');

var u129 = document.getElementById('u129');

u129.style.cursor = 'pointer';
if (bIE) u129.attachEvent("onclick", Clicku129);
else u129.addEventListener("click", Clicku129, true);
function Clicku129(e)
{
windowEvent = e;


if (true) {

	SetPanelState('u141', 'pd1u141','none','',500,'none','',500);

}

}

var u28 = document.getElementById('u28');
gv_vAlignTable['u28'] = 'top';
var u216 = document.getElementById('u216');

var u14 = document.getElementById('u14');

var u259 = document.getElementById('u259');

var u205 = document.getElementById('u205');

var u183 = document.getElementById('u183');
gv_vAlignTable['u183'] = 'center';
var u10 = document.getElementById('u10');

var u481 = document.getElementById('u481');

var u42 = document.getElementById('u42');
gv_vAlignTable['u42'] = 'top';
var u322 = document.getElementById('u322');

var u558 = document.getElementById('u558');

var u620 = document.getElementById('u620');

var u141 = document.getElementById('u141');

var u197 = document.getElementById('u197');
gv_vAlignTable['u197'] = 'center';
var u517 = document.getElementById('u517');
gv_vAlignTable['u517'] = 'top';
var u495 = document.getElementById('u495');
gv_vAlignTable['u495'] = 'top';
var u336 = document.getElementById('u336');

var u255 = document.getElementById('u255');
gv_vAlignTable['u255'] = 'top';
var u634 = document.getElementById('u634');
gv_vAlignTable['u634'] = 'top';
var u15 = document.getElementById('u15');
gv_vAlignTable['u15'] = 'top';
var u453 = document.getElementById('u453');

var u128 = document.getElementById('u128');
gv_vAlignTable['u128'] = 'center';
var u96 = document.getElementById('u96');

var u154 = document.getElementById('u154');

u154.style.cursor = 'pointer';
if (bIE) u154.attachEvent("onclick", Clicku154);
else u154.addEventListener("click", Clicku154, true);
function Clicku154(e)
{
windowEvent = e;


if (true) {

	SetPanelState('u157', 'pd1u157','none','',500,'none','',500);

}

}

var u92 = document.getElementById('u92');

var u467 = document.getElementById('u467');

var u599 = document.getElementById('u599');

var u204 = document.getElementById('u204');
gv_vAlignTable['u204'] = 'center';
var u182 = document.getElementById('u182');

var u502 = document.getElementById('u502');

var u480 = document.getElementById('u480');

var u321 = document.getElementById('u321');
gv_vAlignTable['u321'] = 'top';
var u140 = document.getElementById('u140');
gv_vAlignTable['u140'] = 'center';
var u196 = document.getElementById('u196');

var u516 = document.getElementById('u516');

var u494 = document.getElementById('u494');
gv_vAlignTable['u494'] = 'top';
var u335 = document.getElementById('u335');
gv_vAlignTable['u335'] = 'top';
var u389 = document.getElementById('u389');

var u633 = document.getElementById('u633');

var u308 = document.getElementById('u308');

var u452 = document.getElementById('u452');
gv_vAlignTable['u452'] = 'top';
var u23 = document.getElementById('u23');

var u88 = document.getElementById('u88');
gv_vAlignTable['u88'] = 'center';
var u647 = document.getElementById('u647');

var u90 = document.getElementById('u90');
gv_vAlignTable['u90'] = 'center';
var u466 = document.getElementById('u466');
gv_vAlignTable['u466'] = 'top';
var u598 = document.getElementById('u598');
gv_vAlignTable['u598'] = 'top';
var u491 = document.getElementById('u491');

var u439 = document.getElementById('u439');

var u501 = document.getElementById('u501');
gv_vAlignTable['u501'] = 'top';
var u258 = document.getElementById('u258');

var u320 = document.getElementById('u320');

var u4 = document.getElementById('u4');

u4.style.cursor = 'pointer';
if (bIE) u4.attachEvent("onclick", Clicku4);
else u4.addEventListener("click", Clicku4, true);
function Clicku4(e)
{
windowEvent = e;


if (true) {

	self.location.href="#" + GetQuerystring();

}

}
gv_vAlignTable['u4'] = 'top';
var u563 = document.getElementById('u563');
gv_vAlignTable['u563'] = 'top';
var u217 = document.getElementById('u217');
gv_vAlignTable['u217'] = 'top';
var u195 = document.getElementById('u195');

u195.style.cursor = 'pointer';
if (bIE) u195.attachEvent("onclick", Clicku195);
else u195.addEventListener("click", Clicku195, true);
function Clicku195(e)
{
windowEvent = e;


if (true) {

	SetPanelState('u157', 'pd0u157','none','',500,'none','',500);

}

}

var u515 = document.getElementById('u515');
gv_vAlignTable['u515'] = 'top';
var u493 = document.getElementById('u493');
gv_vAlignTable['u493'] = 'top';
var u41 = document.getElementById('u41');

var u334 = document.getElementById('u334');

var u469 = document.getElementById('u469');

var u582 = document.getElementById('u582');

var u153 = document.getElementById('u153');
gv_vAlignTable['u153'] = 'center';
var u451 = document.getElementById('u451');

if (window.OnLoad) OnLoad();
