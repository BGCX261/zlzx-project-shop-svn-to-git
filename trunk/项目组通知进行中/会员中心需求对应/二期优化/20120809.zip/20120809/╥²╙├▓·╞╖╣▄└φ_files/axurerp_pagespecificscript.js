﻿
var PageName = '引用产品管理';
var PageId = '74231fcf08cc428f9c17bde95c9d0dff'
var PageUrl = '引用产品管理.html'
document.title = '引用产品管理';
var PageNotes = 
{
"pageName":"引用产品管理",
"showNotesNames":"False"}
var $OnLoadVariable = '';

var $NewVariable1 = '';

var $CSUM;

var hasQuery = false;
var query = window.location.hash.substring(1);
if (query.length > 0) hasQuery = true;
var vars = query.split("&");
for (var i = 0; i < vars.length; i++) {
    var pair = vars[i].split("=");
    if (pair[0].length > 0) eval("$" + pair[0] + " = decodeURIComponent(pair[1]);");
} 

if (hasQuery && $CSUM != 1) {
alert('Prototype Warning: The variable values were too long to pass to this page.\nIf you are using IE, using Firefox will support more data.');
}

function GetQuerystring() {
    return '#OnLoadVariable=' + encodeURIComponent($OnLoadVariable) + '&NewVariable1=' + encodeURIComponent($NewVariable1) + '&CSUM=1';
}

function PopulateVariables(value) {
    var d = new Date();
  value = value.replace(/\[\[OnLoadVariable\]\]/g, $OnLoadVariable);
  value = value.replace(/\[\[NewVariable1\]\]/g, $NewVariable1);
  value = value.replace(/\[\[PageName\]\]/g, PageName);
  value = value.replace(/\[\[GenDay\]\]/g, '9');
  value = value.replace(/\[\[GenMonth\]\]/g, '8');
  value = value.replace(/\[\[GenMonthName\]\]/g, '八月');
  value = value.replace(/\[\[GenDayOfWeek\]\]/g, '星期四');
  value = value.replace(/\[\[GenYear\]\]/g, '2012');
  value = value.replace(/\[\[Day\]\]/g, d.getDate());
  value = value.replace(/\[\[Month\]\]/g, d.getMonth() + 1);
  value = value.replace(/\[\[MonthName\]\]/g, GetMonthString(d.getMonth()));
  value = value.replace(/\[\[DayOfWeek\]\]/g, GetDayString(d.getDay()));
  value = value.replace(/\[\[Year\]\]/g, d.getFullYear());
  return value;
}

function OnLoad(e) {

}

var u1183 = document.getElementById('u1183');
gv_vAlignTable['u1183'] = 'center';
var u1039 = document.getElementById('u1039');

var u1038 = document.getElementById('u1038');
gv_vAlignTable['u1038'] = 'top';
var u692 = document.getElementById('u692');
gv_vAlignTable['u692'] = 'top';
var u850 = document.getElementById('u850');
gv_vAlignTable['u850'] = 'top';
var u244 = document.getElementById('u244');
gv_vAlignTable['u244'] = 'top';
var u818 = document.getElementById('u818');
gv_vAlignTable['u818'] = 'top';
var u1189 = document.getElementById('u1189');
gv_vAlignTable['u1189'] = 'top';
var u617 = document.getElementById('u617');
gv_vAlignTable['u617'] = 'top';
var u297 = document.getElementById('u297');
gv_vAlignTable['u297'] = 'top';
var u673 = document.getElementById('u673');
gv_vAlignTable['u673'] = 'top';
var u394 = document.getElementById('u394');
gv_vAlignTable['u394'] = 'top';
var u968 = document.getElementById('u968');

var u905 = document.getElementById('u905');
gv_vAlignTable['u905'] = 'top';
var u961 = document.getElementById('u961');
gv_vAlignTable['u961'] = 'top';
var u355 = document.getElementById('u355');
gv_vAlignTable['u355'] = 'top';
var u215 = document.getElementById('u215');
gv_vAlignTable['u215'] = 'top';
var u329 = document.getElementById('u329');
gv_vAlignTable['u329'] = 'top';
var u408 = document.getElementById('u408');
gv_vAlignTable['u408'] = 'top';
var u1 = document.getElementById('u1');
gv_vAlignTable['u1'] = 'center';
var u107 = document.getElementById('u107');
gv_vAlignTable['u107'] = 'top';
var u401 = document.getElementById('u401');

var u163 = document.getElementById('u163');
gv_vAlignTable['u163'] = 'top';
var u832 = document.getElementById('u832');
gv_vAlignTable['u832'] = 'top';
var u536 = document.getElementById('u536');
gv_vAlignTable['u536'] = 'top';
var u51 = document.getElementById('u51');
gv_vAlignTable['u51'] = 'top';
var u282 = document.getElementById('u282');
gv_vAlignTable['u282'] = 'top';
var u519 = document.getElementById('u519');
gv_vAlignTable['u519'] = 'top';
var u686 = document.getElementById('u686');
gv_vAlignTable['u686'] = 'top';
var u824 = document.getElementById('u824');
gv_vAlignTable['u824'] = 'top';
var u274 = document.getElementById('u274');
gv_vAlignTable['u274'] = 'top';
var u267 = document.getElementById('u267');

var u345 = document.getElementById('u345');
gv_vAlignTable['u345'] = 'top';
var u716 = document.getElementById('u716');
gv_vAlignTable['u716'] = 'top';
var u804 = document.getElementById('u804');
gv_vAlignTable['u804'] = 'top';
var u647 = document.getElementById('u647');
gv_vAlignTable['u647'] = 'top';
var u421 = document.getElementById('u421');

var u320 = document.getElementById('u320');
gv_vAlignTable['u320'] = 'top';
var u32 = document.getElementById('u32');

u32.style.cursor = 'pointer';
if (bIE) u32.attachEvent("onclick", Clicku32);
else u32.addEventListener("click", Clicku32, true);
function Clicku32(e)
{
windowEvent = e;


if (true) {

	self.location.href="#" + GetQuerystring();

}

}
gv_vAlignTable['u32'] = 'top';
var u797 = document.getElementById('u797');
gv_vAlignTable['u797'] = 'top';
var u935 = document.getElementById('u935');
gv_vAlignTable['u935'] = 'top';
var u1395 = document.getElementById('u1395');

u1395.style.cursor = 'pointer';
if (bIE) u1395.attachEvent("onclick", u1395Click);
else u1395.addEventListener("click", u1395Click, true);
InsertAfterBegin(document.body, "<DIV class='intcases' id='u1395LinksClick'></DIV>")
var u1395LinksClick = document.getElementById('u1395LinksClick');
function u1395Click(e) 
{
windowEvent = e;


	ToggleLinks(e, 'u1395LinksClick');
}

InsertBeforeEnd(u1395LinksClick, "<div class='intcaselink' onmouseout='SuppressBubble(event)' onclick='u1395Clicku235cdaeb2062433ebeb5464114263fd6(event)'>Case 1 - 通用产品选择</div>");
function u1395Clicku235cdaeb2062433ebeb5464114263fd6(e)
{

	SetPanelState('u56', 'pd3u56','none','',500,'none','',500);

	ToggleLinks(e, 'u1395LinksClick');
}

InsertBeforeEnd(u1395LinksClick, "<div class='intcaselink' onmouseout='SuppressBubble(event)' onclick='u1395Clicku7128b765fd484dce9c4f0b2e460665f7(event)'>Case 1 - 企标产品选择</div>");
function u1395Clicku7128b765fd484dce9c4f0b2e460665f7(e)
{

	SetPanelState('u56', 'pd4u56','none','',500,'none','',500);

	ToggleLinks(e, 'u1395LinksClick');
}

var u1394 = document.getElementById('u1394');
gv_vAlignTable['u1394'] = 'center';
var u1393 = document.getElementById('u1393');

var u1392 = document.getElementById('u1392');
gv_vAlignTable['u1392'] = 'center';
var u438 = document.getElementById('u438');
gv_vAlignTable['u438'] = 'top';
var u1398 = document.getElementById('u1398');

x = 0;
y = 0;
InsertAfterBegin(document.getElementById('u1398ann'), "<div id='u1398Note' class='annnoteimage' style='left:" + x + ";top:" + y + "'></div>");
$('#u1398Note').click(function(e) { ToggleWorkflow(e, 'u1398', 300, 150, false); return false; });
var u1398Ann = 
{
"label":"?",
"Description":"两种状态，可引用企标产品 或 引用通用产品"};

u1398.style.cursor = 'pointer';
if (bIE) u1398.attachEvent("onclick", Clicku1398);
else u1398.addEventListener("click", Clicku1398, true);
function Clicku1398(e)
{
windowEvent = e;


if (true) {

	self.location.href="产品引用.html" + GetQuerystring();

}

}

var u222 = document.getElementById('u222');
gv_vAlignTable['u222'] = 'top';
var u137 = document.getElementById('u137');
gv_vAlignTable['u137'] = 'top';
var u431 = document.getElementById('u431');

var u588 = document.getElementById('u588');
gv_vAlignTable['u588'] = 'top';
var u566 = document.getElementById('u566');

var u54 = document.getElementById('u54');
gv_vAlignTable['u54'] = 'top';
var u287 = document.getElementById('u287');
gv_vAlignTable['u287'] = 'top';
var u581 = document.getElementById('u581');

u581.style.cursor = 'pointer';
if (bIE) u581.attachEvent("onclick", Clicku581);
else u581.addEventListener("click", Clicku581, true);
function Clicku581(e)
{
windowEvent = e;


if (true) {

	SetPanelState('u431', 'pd0u431','none','',500,'none','',500);

}

}

var u549 = document.getElementById('u549');
gv_vAlignTable['u549'] = 'top';
var u69 = document.getElementById('u69');
gv_vAlignTable['u69'] = 'top';
var u612 = document.getElementById('u612');
gv_vAlignTable['u612'] = 'top';
var u854 = document.getElementById('u854');

var u542 = document.getElementById('u542');
gv_vAlignTable['u542'] = 'top';
var u699 = document.getElementById('u699');
gv_vAlignTable['u699'] = 'top';
var u677 = document.getElementById('u677');
gv_vAlignTable['u677'] = 'top';
var u987 = document.getElementById('u987');
gv_vAlignTable['u987'] = 'top';
var u900 = document.getElementById('u900');
gv_vAlignTable['u900'] = 'top';
var u350 = document.getElementById('u350');
gv_vAlignTable['u350'] = 'top';
var u723 = document.getElementById('u723');
gv_vAlignTable['u723'] = 'top';
var u965 = document.getElementById('u965');
gv_vAlignTable['u965'] = 'top';
var u18 = document.getElementById('u18');

u18.style.cursor = 'pointer';
if (bIE) u18.attachEvent("onclick", Clicku18);
else u18.addEventListener("click", Clicku18, true);
function Clicku18(e)
{
windowEvent = e;


if (true) {

	self.location.href="#" + GetQuerystring();

}

}

var u980 = document.getElementById('u980');
gv_vAlignTable['u980'] = 'top';
var u948 = document.getElementById('u948');
gv_vAlignTable['u948'] = 'top';
var u189 = document.getElementById('u189');
gv_vAlignTable['u189'] = 'top';
var u405 = document.getElementById('u405');
gv_vAlignTable['u405'] = 'top';
var u167 = document.getElementById('u167');

var u283 = document.getElementById('u283');
gv_vAlignTable['u283'] = 'top';
var u182 = document.getElementById('u182');
gv_vAlignTable['u182'] = 'top';
var u440 = document.getElementById('u440');

var u57 = document.getElementById('u57');

var u213 = document.getElementById('u213');
gv_vAlignTable['u213'] = 'top';
var u143 = document.getElementById('u143');
gv_vAlignTable['u143'] = 'top';
var u579 = document.getElementById('u579');
gv_vAlignTable['u579'] = 'center';
var u201 = document.getElementById('u201');
gv_vAlignTable['u201'] = 'top';
var u516 = document.getElementById('u516');
gv_vAlignTable['u516'] = 'top';
var u572 = document.getElementById('u572');

var u1137 = document.getElementById('u1137');

var u1136 = document.getElementById('u1136');
gv_vAlignTable['u1136'] = 'top';
var u1135 = document.getElementById('u1135');
gv_vAlignTable['u1135'] = 'top';
var u1134 = document.getElementById('u1134');
gv_vAlignTable['u1134'] = 'top';
var u1133 = document.getElementById('u1133');
gv_vAlignTable['u1133'] = 'top';
var u1132 = document.getElementById('u1132');
gv_vAlignTable['u1132'] = 'top';
var u1131 = document.getElementById('u1131');
gv_vAlignTable['u1131'] = 'top';
var u1130 = document.getElementById('u1130');
gv_vAlignTable['u1130'] = 'top';
var u1209 = document.getElementById('u1209');
gv_vAlignTable['u1209'] = 'top';
var u1139 = document.getElementById('u1139');
gv_vAlignTable['u1139'] = 'top';
var u1138 = document.getElementById('u1138');
gv_vAlignTable['u1138'] = 'top';
var u860 = document.getElementById('u860');
gv_vAlignTable['u860'] = 'top';
var u753 = document.getElementById('u753');
gv_vAlignTable['u753'] = 'top';
var u627 = document.getElementById('u627');
gv_vAlignTable['u627'] = 'top';
var u501 = document.getElementById('u501');
gv_vAlignTable['u501'] = 'top';
var u828 = document.getElementById('u828');
gv_vAlignTable['u828'] = 'top';
var u288 = document.getElementById('u288');
gv_vAlignTable['u288'] = 'top';
var u978 = document.getElementById('u978');
gv_vAlignTable['u978'] = 'top';
var u435 = document.getElementById('u435');
gv_vAlignTable['u435'] = 'top';
var u971 = document.getElementById('u971');
gv_vAlignTable['u971'] = 'top';
var u418 = document.getElementById('u418');
gv_vAlignTable['u418'] = 'top';
var u585 = document.getElementById('u585');
gv_vAlignTable['u585'] = 'top';
var u117 = document.getElementById('u117');

var u173 = document.getElementById('u173');
gv_vAlignTable['u173'] = 'top';
var u546 = document.getElementById('u546');
gv_vAlignTable['u546'] = 'top';
var u52 = document.getElementById('u52');
gv_vAlignTable['u52'] = 'top';
var u1437 = document.getElementById('u1437');
gv_vAlignTable['u1437'] = 'top';
var u1436 = document.getElementById('u1436');
gv_vAlignTable['u1436'] = 'top';
var u1435 = document.getElementById('u1435');
gv_vAlignTable['u1435'] = 'top';
var u1434 = document.getElementById('u1434');
gv_vAlignTable['u1434'] = 'top';
var u1433 = document.getElementById('u1433');
gv_vAlignTable['u1433'] = 'top';
var u1432 = document.getElementById('u1432');
gv_vAlignTable['u1432'] = 'top';
var u1431 = document.getElementById('u1431');
gv_vAlignTable['u1431'] = 'top';
var u1430 = document.getElementById('u1430');
gv_vAlignTable['u1430'] = 'top';
var u461 = document.getElementById('u461');
gv_vAlignTable['u461'] = 'top';
var u354 = document.getElementById('u354');
gv_vAlignTable['u354'] = 'top';
var u1438 = document.getElementById('u1438');
gv_vAlignTable['u1438'] = 'top';
var u437 = document.getElementById('u437');

var u657 = document.getElementById('u657');
gv_vAlignTable['u657'] = 'top';
var u629 = document.getElementById('u629');
gv_vAlignTable['u629'] = 'top';
var u984 = document.getElementById('u984');
gv_vAlignTable['u984'] = 'top';
var u400 = document.getElementById('u400');

var u220 = document.getElementById('u220');
gv_vAlignTable['u220'] = 'top';
var u330 = document.getElementById('u330');

var u703 = document.getElementById('u703');
gv_vAlignTable['u703'] = 'top';
var u945 = document.getElementById('u945');
gv_vAlignTable['u945'] = 'top';
var u186 = document.getElementById('u186');
gv_vAlignTable['u186'] = 'top';
var u480 = document.getElementById('u480');
gv_vAlignTable['u480'] = 'top';
var u448 = document.getElementById('u448');
gv_vAlignTable['u448'] = 'top';
var u1150 = document.getElementById('u1150');
gv_vAlignTable['u1150'] = 'top';
var u511 = document.getElementById('u511');
gv_vAlignTable['u511'] = 'top';
var u147 = document.getElementById('u147');
gv_vAlignTable['u147'] = 'top';
var u1159 = document.getElementById('u1159');
gv_vAlignTable['u1159'] = 'top';
var u1158 = document.getElementById('u1158');
gv_vAlignTable['u1158'] = 'top';
var u598 = document.getElementById('u598');
gv_vAlignTable['u598'] = 'top';
var u576 = document.getElementById('u576');

var u55 = document.getElementById('u55');

var u1176 = document.getElementById('u1176');

var u1175 = document.getElementById('u1175');
gv_vAlignTable['u1175'] = 'center';
var u1174 = document.getElementById('u1174');

var u1173 = document.getElementById('u1173');
gv_vAlignTable['u1173'] = 'center';
var u1172 = document.getElementById('u1172');

var u1171 = document.getElementById('u1171');
gv_vAlignTable['u1171'] = 'center';
var u1170 = document.getElementById('u1170');

var u559 = document.getElementById('u559');
gv_vAlignTable['u559'] = 'center';
var u1179 = document.getElementById('u1179');
gv_vAlignTable['u1179'] = 'center';
var u1178 = document.getElementById('u1178');

var u622 = document.getElementById('u622');
gv_vAlignTable['u622'] = 'top';
var u864 = document.getElementById('u864');
gv_vAlignTable['u864'] = 'top';
var u910 = document.getElementById('u910');

var u304 = document.getElementById('u304');
gv_vAlignTable['u304'] = 'top';
var u360 = document.getElementById('u360');
gv_vAlignTable['u360'] = 'top';
var u733 = document.getElementById('u733');
gv_vAlignTable['u733'] = 'top';
var u975 = document.getElementById('u975');
gv_vAlignTable['u975'] = 'top';
var u19 = document.getElementById('u19');

u19.style.cursor = 'pointer';
if (bIE) u19.attachEvent("onclick", Clicku19);
else u19.addEventListener("click", Clicku19, true);
function Clicku19(e)
{
windowEvent = e;


if (true) {

}

}

var u112 = document.getElementById('u112');
gv_vAlignTable['u112'] = 'top';
var u478 = document.getElementById('u478');
gv_vAlignTable['u478'] = 'top';
var u199 = document.getElementById('u199');
gv_vAlignTable['u199'] = 'top';
var u541 = document.getElementById('u541');
gv_vAlignTable['u541'] = 'top';
var u415 = document.getElementById('u415');
gv_vAlignTable['u415'] = 'top';
var u177 = document.getElementById('u177');
gv_vAlignTable['u177'] = 'top';
var u471 = document.getElementById('u471');
gv_vAlignTable['u471'] = 'top';
var u192 = document.getElementById('u192');
gv_vAlignTable['u192'] = 'top';
var u169 = document.getElementById('u169');

var u223 = document.getElementById('u223');
gv_vAlignTable['u223'] = 'top';
var u217 = document.getElementById('u217');
gv_vAlignTable['u217'] = 'top';
var u1367 = document.getElementById('u1367');
gv_vAlignTable['u1367'] = 'top';
var u652 = document.getElementById('u652');
gv_vAlignTable['u652'] = 'top';
var u1237 = document.getElementById('u1237');
gv_vAlignTable['u1237'] = 'top';
var u1236 = document.getElementById('u1236');
gv_vAlignTable['u1236'] = 'top';
var u1235 = document.getElementById('u1235');
gv_vAlignTable['u1235'] = 'top';
var u1234 = document.getElementById('u1234');
gv_vAlignTable['u1234'] = 'top';
var u1233 = document.getElementById('u1233');
gv_vAlignTable['u1233'] = 'top';
var u1232 = document.getElementById('u1232');
gv_vAlignTable['u1232'] = 'top';
var u1231 = document.getElementById('u1231');
gv_vAlignTable['u1231'] = 'top';
var u1230 = document.getElementById('u1230');
gv_vAlignTable['u1230'] = 'top';
var u940 = document.getElementById('u940');

var u814 = document.getElementById('u814');
gv_vAlignTable['u814'] = 'top';
var u1238 = document.getElementById('u1238');
gv_vAlignTable['u1238'] = 'top';
var u870 = document.getElementById('u870');
gv_vAlignTable['u870'] = 'top';
var u7 = document.getElementById('u7');
gv_vAlignTable['u7'] = 'top';
var u707 = document.getElementById('u707');
gv_vAlignTable['u707'] = 'top';
var u763 = document.getElementById('u763');

var u484 = document.getElementById('u484');
gv_vAlignTable['u484'] = 'top';
var u445 = document.getElementById('u445');
gv_vAlignTable['u445'] = 'top';
var u595 = document.getElementById('u595');
gv_vAlignTable['u595'] = 'top';
var u253 = document.getElementById('u253');
gv_vAlignTable['u253'] = 'top';
var u127 = document.getElementById('u127');
gv_vAlignTable['u127'] = 'top';
var u626 = document.getElementById('u626');
gv_vAlignTable['u626'] = 'top';
var u60 = document.getElementById('u60');

var u556 = document.getElementById('u556');

var u883 = document.getElementById('u883');
gv_vAlignTable['u883'] = 'top';
var u801 = document.getElementById('u801');
gv_vAlignTable['u801'] = 'top';
var u609 = document.getElementById('u609');
gv_vAlignTable['u609'] = 'top';
var u1019 = document.getElementById('u1019');
gv_vAlignTable['u1019'] = 'top';
var u602 = document.getElementById('u602');
gv_vAlignTable['u602'] = 'top';
var u364 = document.getElementById('u364');
gv_vAlignTable['u364'] = 'top';
var u639 = document.getElementById('u639');
gv_vAlignTable['u639'] = 'top';
var u737 = document.getElementById('u737');
gv_vAlignTable['u737'] = 'top';
var u994 = document.getElementById('u994');
gv_vAlignTable['u994'] = 'top';
var u410 = document.getElementById('u410');
gv_vAlignTable['u410'] = 'top';
var u475 = document.getElementById('u475');

var u196 = document.getElementById('u196');
gv_vAlignTable['u196'] = 'top';
var u931 = document.getElementById('u931');
gv_vAlignTable['u931'] = 'top';
var u528 = document.getElementById('u528');
gv_vAlignTable['u528'] = 'top';
var u521 = document.getElementById('u521');
gv_vAlignTable['u521'] = 'top';
var u157 = document.getElementById('u157');
gv_vAlignTable['u157'] = 'top';
var u63 = document.getElementById('u63');
gv_vAlignTable['u63'] = 'top';
var u1277 = document.getElementById('u1277');
gv_vAlignTable['u1277'] = 'top';
var u1276 = document.getElementById('u1276');
gv_vAlignTable['u1276'] = 'top';
var u1275 = document.getElementById('u1275');
gv_vAlignTable['u1275'] = 'top';
var u1274 = document.getElementById('u1274');

u1274.style.cursor = 'pointer';
if (bIE) u1274.attachEvent("onclick", Clicku1274);
else u1274.addEventListener("click", Clicku1274, true);
function Clicku1274(e)
{
windowEvent = e;


if (true) {

	SetPanelState('u56', 'pd1u56','none','',500,'none','',500);

}

}
gv_vAlignTable['u1274'] = 'top';
var u1273 = document.getElementById('u1273');
gv_vAlignTable['u1273'] = 'top';
var u1272 = document.getElementById('u1272');
gv_vAlignTable['u1272'] = 'top';
var u1271 = document.getElementById('u1271');
gv_vAlignTable['u1271'] = 'top';
var u1270 = document.getElementById('u1270');

var u78 = document.getElementById('u78');
gv_vAlignTable['u78'] = 'top';
var u1279 = document.getElementById('u1279');
gv_vAlignTable['u1279'] = 'top';
var u1278 = document.getElementById('u1278');
gv_vAlignTable['u1278'] = 'top';
var u632 = document.getElementById('u632');
gv_vAlignTable['u632'] = 'top';
var u874 = document.getElementById('u874');
gv_vAlignTable['u874'] = 'top';
var u834 = document.getElementById('u834');
gv_vAlignTable['u834'] = 'top';
var u789 = document.getElementById('u789');
gv_vAlignTable['u789'] = 'top';
var u313 = document.getElementById('u313');
gv_vAlignTable['u313'] = 'top';
var u767 = document.getElementById('u767');

var u782 = document.getElementById('u782');
gv_vAlignTable['u782'] = 'center';
var u920 = document.getElementById('u920');
gv_vAlignTable['u920'] = 'top';
var u314 = document.getElementById('u314');
gv_vAlignTable['u314'] = 'top';
var u858 = document.getElementById('u858');

var u370 = document.getElementById('u370');
gv_vAlignTable['u370'] = 'top';
var u129 = document.getElementById('u129');

var u203 = document.getElementById('u203');
gv_vAlignTable['u203'] = 'top';
var u743 = document.getElementById('u743');
gv_vAlignTable['u743'] = 'top';
var u590 = document.getElementById('u590');
gv_vAlignTable['u590'] = 'top';
var u122 = document.getElementById('u122');
gv_vAlignTable['u122'] = 'top';
var u558 = document.getElementById('u558');

var u37 = document.getElementById('u37');

x = 0;
y = 0;
InsertAfterBegin(document.getElementById('u37ann'), "<div id='u37Note' class='annnoteimage' style='left:" + x + ";top:" + y + "'></div>");
$('#u37Note').click(function(e) { ToggleWorkflow(e, 'u37', 300, 150, false); return false; });
var u37Ann = 
{
"label":"?",
"Description":"当前窗口打开具体链接未定"};

u37.style.cursor = 'pointer';
if (bIE) u37.attachEvent("onclick", Clicku37);
else u37.addEventListener("click", Clicku37, true);
function Clicku37(e)
{
windowEvent = e;


if (true) {

	self.location.href="#" + GetQuerystring();

}

}
gv_vAlignTable['u37'] = 'top';
var u551 = document.getElementById('u551');
gv_vAlignTable['u551'] = 'top';
var u333 = document.getElementById('u333');
gv_vAlignTable['u333'] = 'top';
var u66 = document.getElementById('u66');

var u887 = document.getElementById('u887');
gv_vAlignTable['u887'] = 'top';
var u233 = document.getElementById('u233');
gv_vAlignTable['u233'] = 'top';
var u669 = document.getElementById('u669');
gv_vAlignTable['u669'] = 'top';
var u208 = document.getElementById('u208');
gv_vAlignTable['u208'] = 'top';
var u606 = document.getElementById('u606');
gv_vAlignTable['u606'] = 'top';
var u662 = document.getElementById('u662');
gv_vAlignTable['u662'] = 'top';
var u383 = document.getElementById('u383');
gv_vAlignTable['u383'] = 'top';
var u1337 = document.getElementById('u1337');
gv_vAlignTable['u1337'] = 'top';
var u1336 = document.getElementById('u1336');

var u1335 = document.getElementById('u1335');
gv_vAlignTable['u1335'] = 'top';
var u1334 = document.getElementById('u1334');
gv_vAlignTable['u1334'] = 'top';
var u1333 = document.getElementById('u1333');
gv_vAlignTable['u1333'] = 'top';
var u1332 = document.getElementById('u1332');
gv_vAlignTable['u1332'] = 'top';
var u1331 = document.getElementById('u1331');
gv_vAlignTable['u1331'] = 'top';
var u1330 = document.getElementById('u1330');
gv_vAlignTable['u1330'] = 'top';
var u950 = document.getElementById('u950');
gv_vAlignTable['u950'] = 'top';
var u1339 = document.getElementById('u1339');
gv_vAlignTable['u1339'] = 'top';
var u1338 = document.getElementById('u1338');
gv_vAlignTable['u1338'] = 'top';
var u191 = document.getElementById('u191');
gv_vAlignTable['u191'] = 'top';
var u717 = document.getElementById('u717');
gv_vAlignTable['u717'] = 'top';
var u773 = document.getElementById('u773');

var u494 = document.getElementById('u494');
gv_vAlignTable['u494'] = 'top';
var u36 = document.getElementById('u36');

u36.style.cursor = 'pointer';
if (bIE) u36.attachEvent("onclick", Clicku36);
else u36.addEventListener("click", Clicku36, true);
function Clicku36(e)
{
windowEvent = e;


if (true) {

	self.location.href="#" + GetQuerystring();

}

}
gv_vAlignTable['u36'] = 'top';
var u152 = document.getElementById('u152');
gv_vAlignTable['u152'] = 'top';
var u338 = document.getElementById('u338');
gv_vAlignTable['u338'] = 'top';
var u525 = document.getElementById('u525');
gv_vAlignTable['u525'] = 'top';
var u455 = document.getElementById('u455');
gv_vAlignTable['u455'] = 'top';
var u879 = document.getElementById('u879');
gv_vAlignTable['u879'] = 'top';
var u508 = document.getElementById('u508');
gv_vAlignTable['u508'] = 'top';
var u2 = document.getElementById('u2');
gv_vAlignTable['u2'] = 'top';
var u353 = document.getElementById('u353');
gv_vAlignTable['u353'] = 'top';
var u813 = document.getElementById('u813');
gv_vAlignTable['u813'] = 'top';
var u207 = document.getElementById('u207');
gv_vAlignTable['u207'] = 'top';
var u1419 = document.getElementById('u1419');
gv_vAlignTable['u1419'] = 'top';
var u263 = document.getElementById('u263');
gv_vAlignTable['u263'] = 'top';
var u636 = document.getElementById('u636');

var u817 = document.getElementById('u817');
gv_vAlignTable['u817'] = 'top';
var u1077 = document.getElementById('u1077');
gv_vAlignTable['u1077'] = 'top';
var u893 = document.getElementById('u893');
gv_vAlignTable['u893'] = 'top';
var u1075 = document.getElementById('u1075');
gv_vAlignTable['u1075'] = 'top';
var u1074 = document.getElementById('u1074');
gv_vAlignTable['u1074'] = 'top';
var u1073 = document.getElementById('u1073');

var u1072 = document.getElementById('u1072');
gv_vAlignTable['u1072'] = 'top';
var u1071 = document.getElementById('u1071');
gv_vAlignTable['u1071'] = 'top';
var u1070 = document.getElementById('u1070');
gv_vAlignTable['u1070'] = 'top';
var u786 = document.getElementById('u786');
gv_vAlignTable['u786'] = 'top';
var u468 = document.getElementById('u468');
gv_vAlignTable['u468'] = 'top';
var u924 = document.getElementById('u924');
gv_vAlignTable['u924'] = 'top';
var u1079 = document.getElementById('u1079');
gv_vAlignTable['u1079'] = 'top';
var u1078 = document.getElementById('u1078');
gv_vAlignTable['u1078'] = 'top';
var u374 = document.getElementById('u374');
gv_vAlignTable['u374'] = 'top';
var u533 = document.getElementById('u533');
gv_vAlignTable['u533'] = 'top';
var u747 = document.getElementById('u747');
gv_vAlignTable['u747'] = 'top';
var u126 = document.getElementById('u126');
gv_vAlignTable['u126'] = 'top';
var u10 = document.getElementById('u10');
gv_vAlignTable['u10'] = 'top';
var u420 = document.getElementById('u420');
gv_vAlignTable['u420'] = 'top';
var u109 = document.getElementById('u109');
gv_vAlignTable['u109'] = 'top';
var u295 = document.getElementById('u295');
gv_vAlignTable['u295'] = 'top';
var u102 = document.getElementById('u102');
gv_vAlignTable['u102'] = 'top';
var u538 = document.getElementById('u538');
gv_vAlignTable['u538'] = 'top';
var u277 = document.getElementById('u277');
gv_vAlignTable['u277'] = 'top';
var u237 = document.getElementById('u237');
gv_vAlignTable['u237'] = 'top';
var u531 = document.getElementById('u531');

var u688 = document.getElementById('u688');

var u666 = document.getElementById('u666');
gv_vAlignTable['u666'] = 'top';
var u64 = document.getElementById('u64');

var u387 = document.getElementById('u387');
gv_vAlignTable['u387'] = 'top';
var u681 = document.getElementById('u681');
gv_vAlignTable['u681'] = 'top';
var u1376 = document.getElementById('u1376');
gv_vAlignTable['u1376'] = 'center';
var u1375 = document.getElementById('u1375');

var u1374 = document.getElementById('u1374');
gv_vAlignTable['u1374'] = 'top';
var u1373 = document.getElementById('u1373');
gv_vAlignTable['u1373'] = 'top';
var u1372 = document.getElementById('u1372');
gv_vAlignTable['u1372'] = 'top';
var u649 = document.getElementById('u649');
gv_vAlignTable['u649'] = 'top';
var u1370 = document.getElementById('u1370');
gv_vAlignTable['u1370'] = 'top';
var u79 = document.getElementById('u79');
gv_vAlignTable['u79'] = 'top';
var u712 = document.getElementById('u712');

var u954 = document.getElementById('u954');
gv_vAlignTable['u954'] = 'top';
var u1379 = document.getElementById('u1379');

var u1378 = document.getElementById('u1378');
gv_vAlignTable['u1378'] = 'center';
var u642 = document.getElementById('u642');

var u799 = document.getElementById('u799');
gv_vAlignTable['u799'] = 'top';
var u777 = document.getElementById('u777');

var u792 = document.getElementById('u792');
gv_vAlignTable['u792'] = 'top';
var u13 = document.getElementById('u13');
gv_vAlignTable['u13'] = 'top';
var u450 = document.getElementById('u450');
gv_vAlignTable['u450'] = 'top';
var u139 = document.getElementById('u139');
gv_vAlignTable['u139'] = 'top';
var u28 = document.getElementById('u28');

var u132 = document.getElementById('u132');
gv_vAlignTable['u132'] = 'top';
var u568 = document.getElementById('u568');

var u1097 = document.getElementById('u1097');

var u1096 = document.getElementById('u1096');
gv_vAlignTable['u1096'] = 'top';
var u289 = document.getElementById('u289');
gv_vAlignTable['u289'] = 'top';
var u1094 = document.getElementById('u1094');
gv_vAlignTable['u1094'] = 'top';
var u1093 = document.getElementById('u1093');
gv_vAlignTable['u1093'] = 'top';
var u1092 = document.getElementById('u1092');
gv_vAlignTable['u1092'] = 'top';
var u1091 = document.getElementById('u1091');
gv_vAlignTable['u1091'] = 'top';
var u1090 = document.getElementById('u1090');
gv_vAlignTable['u1090'] = 'top';
var u561 = document.getElementById('u561');
gv_vAlignTable['u561'] = 'center';
var u1027 = document.getElementById('u1027');
gv_vAlignTable['u1027'] = 'top';
var u1026 = document.getElementById('u1026');
gv_vAlignTable['u1026'] = 'top';
var u1025 = document.getElementById('u1025');
gv_vAlignTable['u1025'] = 'top';
var u1024 = document.getElementById('u1024');
gv_vAlignTable['u1024'] = 'top';
var u1023 = document.getElementById('u1023');
gv_vAlignTable['u1023'] = 'top';
var u1022 = document.getElementById('u1022');
gv_vAlignTable['u1022'] = 'top';
var u1021 = document.getElementById('u1021');
gv_vAlignTable['u1021'] = 'top';
var u1020 = document.getElementById('u1020');
gv_vAlignTable['u1020'] = 'top';
var u67 = document.getElementById('u67');

var u897 = document.getElementById('u897');
gv_vAlignTable['u897'] = 'top';
var u1029 = document.getElementById('u1029');
gv_vAlignTable['u1029'] = 'top';
var u1028 = document.getElementById('u1028');
gv_vAlignTable['u1028'] = 'top';
var u243 = document.getElementById('u243');

var u679 = document.getElementById('u679');
gv_vAlignTable['u679'] = 'top';
var u885 = document.getElementById('u885');
gv_vAlignTable['u885'] = 'top';
var u616 = document.getElementById('u616');
gv_vAlignTable['u616'] = 'top';
var u672 = document.getElementById('u672');

var u1054 = document.getElementById('u1054');
gv_vAlignTable['u1054'] = 'top';
var u919 = document.getElementById('u919');
gv_vAlignTable['u919'] = 'top';
var u1059 = document.getElementById('u1059');
gv_vAlignTable['u1059'] = 'top';
var u424 = document.getElementById('u424');
gv_vAlignTable['u424'] = 'top';
var u803 = document.getElementById('u803');
gv_vAlignTable['u803'] = 'top';
var u16 = document.getElementById('u16');
gv_vAlignTable['u16'] = 'top';
var u960 = document.getElementById('u960');
gv_vAlignTable['u960'] = 'top';
var u727 = document.getElementById('u727');
gv_vAlignTable['u727'] = 'top';
var u106 = document.getElementById('u106');
gv_vAlignTable['u106'] = 'top';
var u162 = document.getElementById('u162');
gv_vAlignTable['u162'] = 'top';
var u535 = document.getElementById('u535');
gv_vAlignTable['u535'] = 'top';
var u1327 = document.getElementById('u1327');
gv_vAlignTable['u1327'] = 'top';
var u1326 = document.getElementById('u1326');
gv_vAlignTable['u1326'] = 'top';
var u1325 = document.getElementById('u1325');
gv_vAlignTable['u1325'] = 'top';
var u1324 = document.getElementById('u1324');
gv_vAlignTable['u1324'] = 'top';
var u1323 = document.getElementById('u1323');
gv_vAlignTable['u1323'] = 'top';
var u1322 = document.getElementById('u1322');
gv_vAlignTable['u1322'] = 'top';
var u1321 = document.getElementById('u1321');
gv_vAlignTable['u1321'] = 'top';
var u1320 = document.getElementById('u1320');

var u685 = document.getElementById('u685');
gv_vAlignTable['u685'] = 'top';
var u1329 = document.getElementById('u1329');
gv_vAlignTable['u1329'] = 'top';
var u1328 = document.getElementById('u1328');

var u273 = document.getElementById('u273');
gv_vAlignTable['u273'] = 'top';
var u646 = document.getElementById('u646');
gv_vAlignTable['u646'] = 'top';
var u62 = document.getElementById('u62');
gv_vAlignTable['u62'] = 'top';
var u1080 = document.getElementById('u1080');
gv_vAlignTable['u1080'] = 'top';
var u808 = document.getElementById('u808');
gv_vAlignTable['u808'] = 'top';
var u1089 = document.getElementById('u1089');

var u1088 = document.getElementById('u1088');
gv_vAlignTable['u1088'] = 'top';
var u796 = document.getElementById('u796');
gv_vAlignTable['u796'] = 'top';
var u454 = document.getElementById('u454');
gv_vAlignTable['u454'] = 'top';
var u638 = document.getElementById('u638');

var u757 = document.getElementById('u757');
gv_vAlignTable['u757'] = 'top';
var u500 = document.getElementById('u500');
gv_vAlignTable['u500'] = 'top';
var u846 = document.getElementById('u846');
gv_vAlignTable['u846'] = 'top';
var u136 = document.getElementById('u136');
gv_vAlignTable['u136'] = 'top';
var u11 = document.getElementById('u11');
gv_vAlignTable['u11'] = 'top';
var u430 = document.getElementById('u430');

x = 0;
y = 0;
InsertAfterBegin(document.getElementById('u430ann'), "<div id='u430Note' class='annnoteimage' style='left:" + x + ";top:" + y + "'></div>");
$('#u430Note').click(function(e) { ToggleWorkflow(e, 'u430', 300, 150, false); return false; });
var u430Ann = 
{
"label":"?",
"Description":"仅生产制造类 网店用户 有创建新产品的 功能按钮"};

u430.style.cursor = 'pointer';
if (bIE) u430.attachEvent("onclick", Clicku430);
else u430.addEventListener("click", Clicku430, true);
function Clicku430(e)
{
windowEvent = e;


if (true) {

	self.location.href="产品创建.html" + GetQuerystring();

}

}

var u1246 = document.getElementById('u1246');

var u619 = document.getElementById('u619');
gv_vAlignTable['u619'] = 'top';
var u1202 = document.getElementById('u1202');
gv_vAlignTable['u1202'] = 'top';
var u1243 = document.getElementById('u1243');

var u565 = document.getElementById('u565');
gv_vAlignTable['u565'] = 'center';
var u1240 = document.getElementById('u1240');
gv_vAlignTable['u1240'] = 'top';
var u286 = document.getElementById('u286');
gv_vAlignTable['u286'] = 'top';
var u580 = document.getElementById('u580');

var u938 = document.getElementById('u938');
gv_vAlignTable['u938'] = 'top';
var u1249 = document.getElementById('u1249');
gv_vAlignTable['u1249'] = 'top';
var u548 = document.getElementById('u548');
gv_vAlignTable['u548'] = 'top';
var u611 = document.getElementById('u611');
gv_vAlignTable['u611'] = 'top';
var u853 = document.getElementById('u853');
gv_vAlignTable['u853'] = 'top';
var u247 = document.getElementById('u247');
gv_vAlignTable['u247'] = 'top';
var u698 = document.getElementById('u698');
gv_vAlignTable['u698'] = 'top';
var u676 = document.getElementById('u676');
gv_vAlignTable['u676'] = 'top';
var u65 = document.getElementById('u65');
gv_vAlignTable['u65'] = 'top';
var u397 = document.getElementById('u397');
gv_vAlignTable['u397'] = 'top';
var u729 = document.getElementById('u729');
gv_vAlignTable['u729'] = 'top';
var u335 = document.getElementById('u335');
gv_vAlignTable['u335'] = 'top';
var u659 = document.getElementById('u659');
gv_vAlignTable['u659'] = 'top';
var u722 = document.getElementById('u722');
gv_vAlignTable['u722'] = 'top';
var u964 = document.getElementById('u964');
gv_vAlignTable['u964'] = 'top';
var u1389 = document.getElementById('u1389');

var u188 = document.getElementById('u188');
gv_vAlignTable['u188'] = 'top';
var u1294 = document.getElementById('u1294');
gv_vAlignTable['u1294'] = 'top';
var u404 = document.getElementById('u404');
gv_vAlignTable['u404'] = 'top';
var u166 = document.getElementById('u166');
gv_vAlignTable['u166'] = 'top';
var u14 = document.getElementById('u14');
gv_vAlignTable['u14'] = 'top';
var u460 = document.getElementById('u460');
gv_vAlignTable['u460'] = 'top';
var u181 = document.getElementById('u181');
gv_vAlignTable['u181'] = 'top';
var u1299 = document.getElementById('u1299');
gv_vAlignTable['u1299'] = 'top';
var u1298 = document.getElementById('u1298');
gv_vAlignTable['u1298'] = 'top';
var u149 = document.getElementById('u149');
gv_vAlignTable['u149'] = 'top';
var u29 = document.getElementById('u29');
gv_vAlignTable['u29'] = 'center';
var u212 = document.getElementById('u212');
gv_vAlignTable['u212'] = 'top';
var u465 = document.getElementById('u465');
gv_vAlignTable['u465'] = 'top';
var u142 = document.getElementById('u142');
gv_vAlignTable['u142'] = 'top';
var u578 = document.getElementById('u578');

var u1197 = document.getElementById('u1197');
gv_vAlignTable['u1197'] = 'top';
var u1196 = document.getElementById('u1196');
gv_vAlignTable['u1196'] = 'top';
var u1195 = document.getElementById('u1195');
gv_vAlignTable['u1195'] = 'top';
var u1194 = document.getElementById('u1194');
gv_vAlignTable['u1194'] = 'top';
var u1193 = document.getElementById('u1193');
gv_vAlignTable['u1193'] = 'top';
var u641 = document.getElementById('u641');
gv_vAlignTable['u641'] = 'top';
var u1191 = document.getElementById('u1191');
gv_vAlignTable['u1191'] = 'top';
var u1190 = document.getElementById('u1190');
gv_vAlignTable['u1190'] = 'top';
var u571 = document.getElementById('u571');
gv_vAlignTable['u571'] = 'center';
var u1127 = document.getElementById('u1127');
gv_vAlignTable['u1127'] = 'top';
var u1126 = document.getElementById('u1126');
gv_vAlignTable['u1126'] = 'top';
var u292 = document.getElementById('u292');
gv_vAlignTable['u292'] = 'top';
var u1177 = document.getElementById('u1177');
gv_vAlignTable['u1177'] = 'center';
var u1199 = document.getElementById('u1199');
gv_vAlignTable['u1199'] = 'top';
var u1198 = document.getElementById('u1198');
gv_vAlignTable['u1198'] = 'top';
var u1121 = document.getElementById('u1121');

var u1120 = document.getElementById('u1120');
gv_vAlignTable['u1120'] = 'top';
var u791 = document.getElementById('u791');
gv_vAlignTable['u791'] = 'top';
var u1129 = document.getElementById('u1129');

var u1128 = document.getElementById('u1128');
gv_vAlignTable['u1128'] = 'top';
var u959 = document.getElementById('u959');
gv_vAlignTable['u959'] = 'top';
var u752 = document.getElementById('u752');
gv_vAlignTable['u752'] = 'top';
var u1099 = document.getElementById('u1099');
gv_vAlignTable['u1099'] = 'top';
var u1439 = document.getElementById('u1439');
gv_vAlignTable['u1439'] = 'top';
var u592 = document.getElementById('u592');
gv_vAlignTable['u592'] = 'top';
var u914 = document.getElementById('u914');
gv_vAlignTable['u914'] = 'top';
var u17 = document.getElementById('u17');
gv_vAlignTable['u17'] = 'top';
var u970 = document.getElementById('u970');
gv_vAlignTable['u970'] = 'top';
var u179 = document.getElementById('u179');
gv_vAlignTable['u179'] = 'top';
var u584 = document.getElementById('u584');
gv_vAlignTable['u584'] = 'top';
var u116 = document.getElementById('u116');
gv_vAlignTable['u116'] = 'top';
var u172 = document.getElementById('u172');
gv_vAlignTable['u172'] = 'top';
var u892 = document.getElementById('u892');

var u545 = document.getElementById('u545');
gv_vAlignTable['u545'] = 'top';
var u1427 = document.getElementById('u1427');
gv_vAlignTable['u1427'] = 'top';
var u1426 = document.getElementById('u1426');
gv_vAlignTable['u1426'] = 'top';
var u1425 = document.getElementById('u1425');
gv_vAlignTable['u1425'] = 'top';
var u1424 = document.getElementById('u1424');
gv_vAlignTable['u1424'] = 'top';
var u1423 = document.getElementById('u1423');
gv_vAlignTable['u1423'] = 'top';
var u1422 = document.getElementById('u1422');
gv_vAlignTable['u1422'] = 'top';
var u1421 = document.getElementById('u1421');
gv_vAlignTable['u1421'] = 'top';
var u1420 = document.getElementById('u1420');
gv_vAlignTable['u1420'] = 'top';
var u695 = document.getElementById('u695');
gv_vAlignTable['u695'] = 'top';
var u848 = document.getElementById('u848');
gv_vAlignTable['u848'] = 'top';
var u1103 = document.getElementById('u1103');
gv_vAlignTable['u1103'] = 'top';
var u833 = document.getElementById('u833');
gv_vAlignTable['u833'] = 'top';
var u1428 = document.getElementById('u1428');
gv_vAlignTable['u1428'] = 'top';
var u726 = document.getElementById('u726');
gv_vAlignTable['u726'] = 'top';
var u70 = document.getElementById('u70');
gv_vAlignTable['u70'] = 'top';
var u656 = document.getElementById('u656');
gv_vAlignTable['u656'] = 'top';
var u983 = document.getElementById('u983');
gv_vAlignTable['u983'] = 'top';
var u709 = document.getElementById('u709');
gv_vAlignTable['u709'] = 'top';
var u702 = document.getElementById('u702');
gv_vAlignTable['u702'] = 'top';
var u464 = document.getElementById('u464');
gv_vAlignTable['u464'] = 'top';
var u185 = document.getElementById('u185');
gv_vAlignTable['u185'] = 'top';
var u321 = document.getElementById('u321');

var u510 = document.getElementById('u510');
gv_vAlignTable['u510'] = 'top';
var u146 = document.getElementById('u146');
gv_vAlignTable['u146'] = 'top';
var u12 = document.getElementById('u12');
gv_vAlignTable['u12'] = 'top';
var u575 = document.getElementById('u575');
gv_vAlignTable['u575'] = 'center';
var u1167 = document.getElementById('u1167');
gv_vAlignTable['u1167'] = 'center';
var u1166 = document.getElementById('u1166');

var u1165 = document.getElementById('u1165');
gv_vAlignTable['u1165'] = 'center';
var u1164 = document.getElementById('u1164');

var u1163 = document.getElementById('u1163');
gv_vAlignTable['u1163'] = 'center';
var u1162 = document.getElementById('u1162');

var u1161 = document.getElementById('u1161');
gv_vAlignTable['u1161'] = 'center';
var u1160 = document.getElementById('u1160');

var u8 = document.getElementById('u8');
gv_vAlignTable['u8'] = 'top';
var u1169 = document.getElementById('u1169');
gv_vAlignTable['u1169'] = 'center';
var u1168 = document.getElementById('u1168');

var u621 = document.getElementById('u621');
gv_vAlignTable['u621'] = 'top';
var u375 = document.getElementById('u375');
gv_vAlignTable['u375'] = 'top';
var u257 = document.getElementById('u257');
gv_vAlignTable['u257'] = 'top';
var u73 = document.getElementById('u73');
gv_vAlignTable['u73'] = 'top';
var u303 = document.getElementById('u303');

var u739 = document.getElementById('u739');
gv_vAlignTable['u739'] = 'top';
var u505 = document.getElementById('u505');
gv_vAlignTable['u505'] = 'top';
var u732 = document.getElementById('u732');
gv_vAlignTable['u732'] = 'top';
var u974 = document.getElementById('u974');
gv_vAlignTable['u974'] = 'top';
var u210 = document.getElementById('u210');
gv_vAlignTable['u210'] = 'top';
var u111 = document.getElementById('u111');

var u564 = document.getElementById('u564');

var u1076 = document.getElementById('u1076');
gv_vAlignTable['u1076'] = 'top';
var u540 = document.getElementById('u540');
gv_vAlignTable['u540'] = 'top';
var u414 = document.getElementById('u414');
gv_vAlignTable['u414'] = 'top';
var u176 = document.getElementById('u176');
gv_vAlignTable['u176'] = 'top';
var u15 = document.getElementById('u15');
gv_vAlignTable['u15'] = 'top';
var u470 = document.getElementById('u470');
gv_vAlignTable['u470'] = 'top';
var u229 = document.getElementById('u229');
gv_vAlignTable['u229'] = 'top';
var u159 = document.getElementById('u159');
gv_vAlignTable['u159'] = 'top';
var u690 = document.getElementById('u690');
gv_vAlignTable['u690'] = 'top';
var u916 = document.getElementById('u916');

var u658 = document.getElementById('u658');
gv_vAlignTable['u658'] = 'top';
var u299 = document.getElementById('u299');
gv_vAlignTable['u299'] = 'top';
var u1297 = document.getElementById('u1297');
gv_vAlignTable['u1297'] = 'top';
var u1296 = document.getElementById('u1296');

var u1295 = document.getElementById('u1295');
gv_vAlignTable['u1295'] = 'top';
var u837 = document.getElementById('u837');
gv_vAlignTable['u837'] = 'top';
var u1293 = document.getElementById('u1293');
gv_vAlignTable['u1293'] = 'top';
var u1292 = document.getElementById('u1292');
gv_vAlignTable['u1292'] = 'top';
var u1291 = document.getElementById('u1291');
gv_vAlignTable['u1291'] = 'top';
var u1290 = document.getElementById('u1290');
gv_vAlignTable['u1290'] = 'top';
var u340 = document.getElementById('u340');
gv_vAlignTable['u340'] = 'top';
var u1227 = document.getElementById('u1227');
gv_vAlignTable['u1227'] = 'top';
var u1226 = document.getElementById('u1226');
gv_vAlignTable['u1226'] = 'top';
var u1225 = document.getElementById('u1225');
gv_vAlignTable['u1225'] = 'top';
var u1224 = document.getElementById('u1224');
gv_vAlignTable['u1224'] = 'top';
var u1223 = document.getElementById('u1223');
gv_vAlignTable['u1223'] = 'top';
var u1222 = document.getElementById('u1222');
gv_vAlignTable['u1222'] = 'top';
var u1221 = document.getElementById('u1221');
gv_vAlignTable['u1221'] = 'top';
var u1220 = document.getElementById('u1220');
gv_vAlignTable['u1220'] = 'top';
var u1229 = document.getElementById('u1229');
gv_vAlignTable['u1229'] = 'top';
var u769 = document.getElementById('u769');

var u706 = document.getElementById('u706');
gv_vAlignTable['u706'] = 'top';
var u762 = document.getElementById('u762');
gv_vAlignTable['u762'] = 'center';
var u483 = document.getElementById('u483');

var u141 = document.getElementById('u141');

var u444 = document.getElementById('u444');
gv_vAlignTable['u444'] = 'top';
var u291 = document.getElementById('u291');
gv_vAlignTable['u291'] = 'top';
var u88 = document.getElementById('u88');
gv_vAlignTable['u88'] = 'top';
var u594 = document.getElementById('u594');
gv_vAlignTable['u594'] = 'top';
var u718 = document.getElementById('u718');
gv_vAlignTable['u718'] = 'top';
var u252 = document.getElementById('u252');
gv_vAlignTable['u252'] = 'top';
var u889 = document.getElementById('u889');
gv_vAlignTable['u889'] = 'top';
var u625 = document.getElementById('u625');
gv_vAlignTable['u625'] = 'top';
var u867 = document.getElementById('u867');
gv_vAlignTable['u867'] = 'top';
var u555 = document.getElementById('u555');
gv_vAlignTable['u555'] = 'center';
var u882 = document.getElementById('u882');
gv_vAlignTable['u882'] = 'top';
var u608 = document.getElementById('u608');
gv_vAlignTable['u608'] = 'top';
var u1262 = document.getElementById('u1262');
gv_vAlignTable['u1262'] = 'top';
var u3 = document.getElementById('u3');
gv_vAlignTable['u3'] = 'top';
var u913 = document.getElementById('u913');
gv_vAlignTable['u913'] = 'top';
var u307 = document.getElementById('u307');
gv_vAlignTable['u307'] = 'top';
var u601 = document.getElementById('u601');
gv_vAlignTable['u601'] = 'top';
var u843 = document.getElementById('u843');

var u1269 = document.getElementById('u1269');
gv_vAlignTable['u1269'] = 'top';
var u902 = document.getElementById('u902');
gv_vAlignTable['u902'] = 'top';
var u736 = document.getElementById('u736');

var u71 = document.getElementById('u71');
gv_vAlignTable['u71'] = 'top';
var u227 = document.getElementById('u227');
gv_vAlignTable['u227'] = 'top';
var u993 = document.getElementById('u993');
gv_vAlignTable['u993'] = 'top';
var u719 = document.getElementById('u719');
gv_vAlignTable['u719'] = 'top';
var u280 = document.getElementById('u280');
gv_vAlignTable['u280'] = 'top';
var u474 = document.getElementById('u474');
gv_vAlignTable['u474'] = 'top';
var u195 = document.getElementById('u195');
gv_vAlignTable['u195'] = 'top';
var u226 = document.getElementById('u226');
gv_vAlignTable['u226'] = 'top';
var u20 = document.getElementById('u20');

u20.style.cursor = 'pointer';
if (bIE) u20.attachEvent("onclick", Clicku20);
else u20.addEventListener("click", Clicku20, true);
function Clicku20(e)
{
windowEvent = e;


if (true) {

}

}

var u520 = document.getElementById('u520');
gv_vAlignTable['u520'] = 'top';
var u156 = document.getElementById('u156');
gv_vAlignTable['u156'] = 'top';
var u209 = document.getElementById('u209');
gv_vAlignTable['u209'] = 'top';
var u1267 = document.getElementById('u1267');
gv_vAlignTable['u1267'] = 'top';
var u1266 = document.getElementById('u1266');

u1266.style.cursor = 'pointer';
if (bIE) u1266.attachEvent("onclick", Clicku1266);
else u1266.addEventListener("click", Clicku1266, true);
function Clicku1266(e)
{
windowEvent = e;


if (true) {

	SetPanelState('u56', 'pd1u56','none','',500,'none','',500);

}

}
gv_vAlignTable['u1266'] = 'top';
var u1265 = document.getElementById('u1265');
gv_vAlignTable['u1265'] = 'top';
var u1264 = document.getElementById('u1264');
gv_vAlignTable['u1264'] = 'top';
var u1263 = document.getElementById('u1263');
gv_vAlignTable['u1263'] = 'top';
var u1098 = document.getElementById('u1098');
gv_vAlignTable['u1098'] = 'top';
var u1261 = document.getElementById('u1261');

var u1260 = document.getElementById('u1260');

var u337 = document.getElementById('u337');
gv_vAlignTable['u337'] = 'top';
var u1268 = document.getElementById('u1268');
gv_vAlignTable['u1268'] = 'top';
var u631 = document.getElementById('u631');
gv_vAlignTable['u631'] = 'top';
var u873 = document.getElementById('u873');

var u467 = document.getElementById('u467');

var u788 = document.getElementById('u788');
gv_vAlignTable['u788'] = 'top';
var u766 = document.getElementById('u766');
gv_vAlignTable['u766'] = 'center';
var u74 = document.getElementById('u74');

var u487 = document.getElementById('u487');
gv_vAlignTable['u487'] = 'top';
var u781 = document.getElementById('u781');

var u749 = document.getElementById('u749');
gv_vAlignTable['u749'] = 'top';
var u128 = document.getElementById('u128');
gv_vAlignTable['u128'] = 'top';
var u742 = document.getElementById('u742');
gv_vAlignTable['u742'] = 'top';
var u121 = document.getElementById('u121');
gv_vAlignTable['u121'] = 'top';
var u23 = document.getElementById('u23');

u23.style.cursor = 'pointer';
if (bIE) u23.attachEvent("onclick", Clicku23);
else u23.addEventListener("click", Clicku23, true);
function Clicku23(e)
{
windowEvent = e;


if (true) {

}

}

var u550 = document.getElementById('u550');

var u921 = document.getElementById('u921');
gv_vAlignTable['u921'] = 'top';
var u82 = document.getElementById('u82');
gv_vAlignTable['u82'] = 'top';
var u239 = document.getElementById('u239');
gv_vAlignTable['u239'] = 'top';
var u886 = document.getElementById('u886');

var u38 = document.getElementById('u38');

var u232 = document.getElementById('u232');
gv_vAlignTable['u232'] = 'top';
var u668 = document.getElementById('u668');
gv_vAlignTable['u668'] = 'top';
var u389 = document.getElementById('u389');
gv_vAlignTable['u389'] = 'top';
var u1397 = document.getElementById('u1397');

var u1396 = document.getElementById('u1396');
gv_vAlignTable['u1396'] = 'top';
var u605 = document.getElementById('u605');
gv_vAlignTable['u605'] = 'top';
var u847 = document.getElementById('u847');

var u434 = document.getElementById('u434');
gv_vAlignTable['u434'] = 'top';
var u661 = document.getElementById('u661');
gv_vAlignTable['u661'] = 'top';
var u1391 = document.getElementById('u1391');

var u1390 = document.getElementById('u1390');
gv_vAlignTable['u1390'] = 'center';
var u382 = document.getElementById('u382');
gv_vAlignTable['u382'] = 'top';
var u943 = document.getElementById('u943');
gv_vAlignTable['u943'] = 'top';
var u1399 = document.getElementById('u1399');

x = 0;
y = 0;
InsertAfterBegin(document.getElementById('u1399ann'), "<div id='u1399Note' class='annnoteimage' style='left:" + x + ";top:" + y + "'></div>");
$('#u1399Note').click(function(e) { ToggleWorkflow(e, 'u1399', 300, 150, false); return false; });
var u1399Ann = 
{
"label":"?",
"Description":"仅生产制造类 网店用户 有创建新产品的 功能按钮"};

u1399.style.cursor = 'pointer';
if (bIE) u1399.attachEvent("onclick", Clicku1399);
else u1399.addEventListener("click", Clicku1399, true);
function Clicku1399(e)
{
windowEvent = e;


if (true) {

	self.location.href="产品创建.html" + GetQuerystring();

}

}

var u77 = document.getElementById('u77');
gv_vAlignTable['u77'] = 'top';
var u997 = document.getElementById('u997');
gv_vAlignTable['u997'] = 'top';
var u413 = document.getElementById('u413');
gv_vAlignTable['u413'] = 'top';
var u343 = document.getElementById('u343');
gv_vAlignTable['u343'] = 'top';
var u779 = document.getElementById('u779');

var u190 = document.getElementById('u190');
gv_vAlignTable['u190'] = 'top';
var u158 = document.getElementById('u158');
gv_vAlignTable['u158'] = 'top';
var u1124 = document.getElementById('u1124');
gv_vAlignTable['u1124'] = 'top';
var u1123 = document.getElementById('u1123');
gv_vAlignTable['u1123'] = 'top';
var u772 = document.getElementById('u772');
gv_vAlignTable['u772'] = 'center';
var u493 = document.getElementById('u493');
gv_vAlignTable['u493'] = 'top';
var u151 = document.getElementById('u151');
gv_vAlignTable['u151'] = 'top';
var u524 = document.getElementById('u524');
gv_vAlignTable['u524'] = 'top';
var u26 = document.getElementById('u26');
gv_vAlignTable['u26'] = 'center';
var u269 = document.getElementById('u269');
gv_vAlignTable['u269'] = 'top';
var u89 = document.getElementById('u89');
gv_vAlignTable['u89'] = 'top';
var u812 = document.getElementById('u812');
gv_vAlignTable['u812'] = 'top';
var u206 = document.getElementById('u206');
gv_vAlignTable['u206'] = 'top';
var u262 = document.getElementById('u262');
gv_vAlignTable['u262'] = 'top';
var u323 = document.getElementById('u323');
gv_vAlignTable['u323'] = 'top';
var u899 = document.getElementById('u899');
gv_vAlignTable['u899'] = 'top';
var u635 = document.getElementById('u635');

var u877 = document.getElementById('u877');
gv_vAlignTable['u877'] = 'top';
var u1067 = document.getElementById('u1067');
gv_vAlignTable['u1067'] = 'top';
var u1066 = document.getElementById('u1066');
gv_vAlignTable['u1066'] = 'top';
var u1065 = document.getElementById('u1065');

var u942 = document.getElementById('u942');
gv_vAlignTable['u942'] = 'top';
var u1063 = document.getElementById('u1063');
gv_vAlignTable['u1063'] = 'top';
var u1062 = document.getElementById('u1062');
gv_vAlignTable['u1062'] = 'top';
var u1061 = document.getElementById('u1061');
gv_vAlignTable['u1061'] = 'top';
var u1060 = document.getElementById('u1060');
gv_vAlignTable['u1060'] = 'top';
var u785 = document.getElementById('u785');
gv_vAlignTable['u785'] = 'top';
var u923 = document.getElementById('u923');
gv_vAlignTable['u923'] = 'top';
var u1069 = document.getElementById('u1069');
gv_vAlignTable['u1069'] = 'top';
var u1068 = document.getElementById('u1068');
gv_vAlignTable['u1068'] = 'top';
var u373 = document.getElementById('u373');
gv_vAlignTable['u373'] = 'top';
var u746 = document.getElementById('u746');
gv_vAlignTable['u746'] = 'top';
var u72 = document.getElementById('u72');
gv_vAlignTable['u72'] = 'top';
var u296 = document.getElementById('u296');
gv_vAlignTable['u296'] = 'top';
var u125 = document.getElementById('u125');
gv_vAlignTable['u125'] = 'top';
var u453 = document.getElementById('u453');
gv_vAlignTable['u453'] = 'top';
var u554 = document.getElementById('u554');

var u101 = document.getElementById('u101');
gv_vAlignTable['u101'] = 'top';
var u600 = document.getElementById('u600');
gv_vAlignTable['u600'] = 'top';
var u236 = document.getElementById('u236');
gv_vAlignTable['u236'] = 'top';
var u21 = document.getElementById('u21');

u21.style.cursor = 'pointer';
if (bIE) u21.attachEvent("onclick", Clicku21);
else u21.addEventListener("click", Clicku21, true);
function Clicku21(e)
{
windowEvent = e;


if (true) {

}

}

var u530 = document.getElementById('u530');
gv_vAlignTable['u530'] = 'top';
var u1313 = document.getElementById('u1313');
gv_vAlignTable['u1313'] = 'top';
var u665 = document.getElementById('u665');
gv_vAlignTable['u665'] = 'top';
var u831 = document.getElementById('u831');
gv_vAlignTable['u831'] = 'top';
var u386 = document.getElementById('u386');
gv_vAlignTable['u386'] = 'top';
var u1319 = document.getElementById('u1319');
gv_vAlignTable['u1319'] = 'top';
var u680 = document.getElementById('u680');

var u1366 = document.getElementById('u1366');
gv_vAlignTable['u1366'] = 'top';
var u1365 = document.getElementById('u1365');
gv_vAlignTable['u1365'] = 'top';
var u1364 = document.getElementById('u1364');
gv_vAlignTable['u1364'] = 'top';
var u1363 = document.getElementById('u1363');
gv_vAlignTable['u1363'] = 'top';
var u1362 = document.getElementById('u1362');
gv_vAlignTable['u1362'] = 'top';
var u648 = document.getElementById('u648');
gv_vAlignTable['u648'] = 'top';
var u1360 = document.getElementById('u1360');

var u807 = document.getElementById('u807');
gv_vAlignTable['u807'] = 'top';
var u711 = document.getElementById('u711');
gv_vAlignTable['u711'] = 'top';
var u953 = document.getElementById('u953');
gv_vAlignTable['u953'] = 'top';
var u347 = document.getElementById('u347');
gv_vAlignTable['u347'] = 'top';
var u1368 = document.getElementById('u1368');
gv_vAlignTable['u1368'] = 'top';
var u798 = document.getElementById('u798');
gv_vAlignTable['u798'] = 'top';
var u344 = document.getElementById('u344');
gv_vAlignTable['u344'] = 'top';
var u776 = document.getElementById('u776');
gv_vAlignTable['u776'] = 'center';
var u75 = document.getElementById('u75');
gv_vAlignTable['u75'] = 'top';
var u497 = document.getElementById('u497');
gv_vAlignTable['u497'] = 'top';
var u759 = document.getElementById('u759');

var u425 = document.getElementById('u425');

var u219 = document.getElementById('u219');
gv_vAlignTable['u219'] = 'top';
var u138 = document.getElementById('u138');
gv_vAlignTable['u138'] = 'top';
var u1387 = document.getElementById('u1387');

var u1385 = document.getElementById('u1385');

var u1384 = document.getElementById('u1384');
gv_vAlignTable['u1384'] = 'center';
var u1383 = document.getElementById('u1383');

var u1382 = document.getElementById('u1382');
gv_vAlignTable['u1382'] = 'center';
var u131 = document.getElementById('u131');
gv_vAlignTable['u131'] = 'top';
var u1087 = document.getElementById('u1087');
gv_vAlignTable['u1087'] = 'top';
var u1086 = document.getElementById('u1086');
gv_vAlignTable['u1086'] = 'top';
var u1085 = document.getElementById('u1085');
gv_vAlignTable['u1085'] = 'top';
var u1084 = document.getElementById('u1084');
gv_vAlignTable['u1084'] = 'top';
var u1083 = document.getElementById('u1083');
gv_vAlignTable['u1083'] = 'top';
var u1082 = document.getElementById('u1082');
gv_vAlignTable['u1082'] = 'top';
var u1081 = document.getElementById('u1081');

var u266 = document.getElementById('u266');
gv_vAlignTable['u266'] = 'top';
var u24 = document.getElementById('u24');

u24.style.cursor = 'pointer';
if (bIE) u24.attachEvent("onclick", Clicku24);
else u24.addEventListener("click", Clicku24, true);
function Clicku24(e)
{
windowEvent = e;


if (true) {

}

}

var u560 = document.getElementById('u560');

var u1017 = document.getElementById('u1017');
gv_vAlignTable['u1017'] = 'top';
var u1016 = document.getElementById('u1016');
gv_vAlignTable['u1016'] = 'top';
var u281 = document.getElementById('u281');
gv_vAlignTable['u281'] = 'top';
var u1014 = document.getElementById('u1014');
gv_vAlignTable['u1014'] = 'top';
var u1013 = document.getElementById('u1013');
gv_vAlignTable['u1013'] = 'top';
var u1012 = document.getElementById('u1012');
gv_vAlignTable['u1012'] = 'top';
var u1011 = document.getElementById('u1011');
gv_vAlignTable['u1011'] = 'top';
var u1010 = document.getElementById('u1010');
gv_vAlignTable['u1010'] = 'top';
var u393 = document.getElementById('u393');
gv_vAlignTable['u393'] = 'top';
var u896 = document.getElementById('u896');
gv_vAlignTable['u896'] = 'top';
var u39 = document.getElementById('u39');
gv_vAlignTable['u39'] = 'center';
var u312 = document.getElementById('u312');

var u1018 = document.getElementById('u1018');
gv_vAlignTable['u1018'] = 'top';
var u242 = document.getElementById('u242');
gv_vAlignTable['u242'] = 'top';
var u678 = document.getElementById('u678');
gv_vAlignTable['u678'] = 'top';
var u399 = document.getElementById('u399');

var u741 = document.getElementById('u741');
gv_vAlignTable['u741'] = 'top';
var u615 = document.getElementById('u615');
gv_vAlignTable['u615'] = 'top';
var u377 = document.getElementById('u377');
gv_vAlignTable['u377'] = 'top';
var u671 = document.getElementById('u671');
gv_vAlignTable['u671'] = 'top';
var u392 = document.getElementById('u392');
gv_vAlignTable['u392'] = 'top';
var u986 = document.getElementById('u986');
gv_vAlignTable['u986'] = 'top';
var u696 = document.getElementById('u696');

var u423 = document.getElementById('u423');

var u108 = document.getElementById('u108');
gv_vAlignTable['u108'] = 'top';
var u1200 = document.getElementById('u1200');
gv_vAlignTable['u1200'] = 'top';
var u168 = document.getElementById('u168');

var u105 = document.getElementById('u105');

var u161 = document.getElementById('u161');
gv_vAlignTable['u161'] = 'top';
var u398 = document.getElementById('u398');
gv_vAlignTable['u398'] = 'top';
var u534 = document.getElementById('u534');
gv_vAlignTable['u534'] = 'top';
var u27 = document.getElementById('u27');

var u363 = document.getElementById('u363');
gv_vAlignTable['u363'] = 'top';
var u1317 = document.getElementById('u1317');
gv_vAlignTable['u1317'] = 'top';
var u1316 = document.getElementById('u1316');

u1316.style.cursor = 'pointer';
if (bIE) u1316.attachEvent("onclick", Clicku1316);
else u1316.addEventListener("click", Clicku1316, true);
function Clicku1316(e)
{
windowEvent = e;


if (true) {

	SetPanelState('u56', 'pd2u56','none','',500,'none','',500);

}

}
gv_vAlignTable['u1316'] = 'top';
var u1315 = document.getElementById('u1315');
gv_vAlignTable['u1315'] = 'top';
var u1314 = document.getElementById('u1314');
gv_vAlignTable['u1314'] = 'top';
var u829 = document.getElementById('u829');
gv_vAlignTable['u829'] = 'top';
var u1312 = document.getElementById('u1312');

var u1311 = document.getElementById('u1311');
gv_vAlignTable['u1311'] = 'top';
var u1310 = document.getElementById('u1310');
gv_vAlignTable['u1310'] = 'top';
var u279 = document.getElementById('u279');
gv_vAlignTable['u279'] = 'top';
var u684 = document.getElementById('u684');
gv_vAlignTable['u684'] = 'top';
var u822 = document.getElementById('u822');
gv_vAlignTable['u822'] = 'top';
var u1318 = document.getElementById('u1318');
gv_vAlignTable['u1318'] = 'top';
var u272 = document.getElementById('u272');
gv_vAlignTable['u272'] = 'top';
var u645 = document.getElementById('u645');

var u795 = document.getElementById('u795');
gv_vAlignTable['u795'] = 'top';
var u819 = document.getElementById('u819');
gv_vAlignTable['u819'] = 'top';
var u933 = document.getElementById('u933');
gv_vAlignTable['u933'] = 'top';
var u327 = document.getElementById('u327');
gv_vAlignTable['u327'] = 'top';
var u957 = document.getElementById('u957');
gv_vAlignTable['u957'] = 'top';
var u909 = document.getElementById('u909');
gv_vAlignTable['u909'] = 'top';
var u756 = document.getElementById('u756');
gv_vAlignTable['u756'] = 'top';
var u135 = document.getElementById('u135');

var u118 = document.getElementById('u118');
gv_vAlignTable['u118'] = 'top';
var u891 = document.getElementById('u891');
gv_vAlignTable['u891'] = 'top';
var u285 = document.getElementById('u285');

var u610 = document.getElementById('u610');
gv_vAlignTable['u610'] = 'top';
var u852 = document.getElementById('u852');

var u246 = document.getElementById('u246');

var u22 = document.getElementById('u22');

u22.style.cursor = 'pointer';
if (bIE) u22.attachEvent("onclick", Clicku22);
else u22.addEventListener("click", Clicku22, true);
function Clicku22(e)
{
windowEvent = e;


if (true) {

}

}

var u675 = document.getElementById('u675');
gv_vAlignTable['u675'] = 'top';
var u396 = document.getElementById('u396');
gv_vAlignTable['u396'] = 'top';
var u728 = document.getElementById('u728');

var u9 = document.getElementById('u9');
gv_vAlignTable['u9'] = 'top';
var u907 = document.getElementById('u907');
gv_vAlignTable['u907'] = 'top';
var u721 = document.getElementById('u721');
gv_vAlignTable['u721'] = 'top';
var u963 = document.getElementById('u963');
gv_vAlignTable['u963'] = 'top';
var u357 = document.getElementById('u357');

var u100 = document.getElementById('u100');
gv_vAlignTable['u100'] = 'top';
var u628 = document.getElementById('u628');
gv_vAlignTable['u628'] = 'top';
var u403 = document.getElementById('u403');
gv_vAlignTable['u403'] = 'top';
var u165 = document.getElementById('u165');
gv_vAlignTable['u165'] = 'top';
var u180 = document.getElementById('u180');
gv_vAlignTable['u180'] = 'top';
var u148 = document.getElementById('u148');
gv_vAlignTable['u148'] = 'top';
var u211 = document.getElementById('u211');
gv_vAlignTable['u211'] = 'top';
var u1146 = document.getElementById('u1146');
gv_vAlignTable['u1146'] = 'top';
var u1145 = document.getElementById('u1145');

var u1187 = document.getElementById('u1187');

u1187.style.cursor = 'pointer';
if (bIE) u1187.attachEvent("onclick", Clicku1187);
else u1187.addEventListener("click", Clicku1187, true);
function Clicku1187(e)
{
windowEvent = e;


if (true) {

	SetPanelState('u56', 'pd0u56','none','',500,'none','',500);

}

}

var u1186 = document.getElementById('u1186');

var u298 = document.getElementById('u298');
gv_vAlignTable['u298'] = 'top';
var u826 = document.getElementById('u826');
gv_vAlignTable['u826'] = 'top';
var u80 = document.getElementById('u80');
gv_vAlignTable['u80'] = 'top';
var u640 = document.getElementById('u640');
gv_vAlignTable['u640'] = 'top';
var u514 = document.getElementById('u514');
gv_vAlignTable['u514'] = 'top';
var u276 = document.getElementById('u276');

var u25 = document.getElementById('u25');

var u570 = document.getElementById('u570');

var u1117 = document.getElementById('u1117');
gv_vAlignTable['u1117'] = 'top';
var u1149 = document.getElementById('u1149');
gv_vAlignTable['u1149'] = 'top';
var u1115 = document.getElementById('u1115');
gv_vAlignTable['u1115'] = 'top';
var u1114 = document.getElementById('u1114');
gv_vAlignTable['u1114'] = 'top';
var u1113 = document.getElementById('u1113');

var u1188 = document.getElementById('u1188');
gv_vAlignTable['u1188'] = 'top';
var u1111 = document.getElementById('u1111');
gv_vAlignTable['u1111'] = 'top';
var u1110 = document.getElementById('u1110');
gv_vAlignTable['u1110'] = 'top';
var u259 = document.getElementById('u259');
gv_vAlignTable['u259'] = 'top';
var u790 = document.getElementById('u790');
gv_vAlignTable['u790'] = 'top';
var u758 = document.getElementById('u758');
gv_vAlignTable['u758'] = 'top';
var u322 = document.getElementById('u322');
gv_vAlignTable['u322'] = 'top';
var u1118 = document.getElementById('u1118');
gv_vAlignTable['u1118'] = 'top';
var u937 = document.getElementById('u937');
gv_vAlignTable['u937'] = 'top';
var u751 = document.getElementById('u751');
gv_vAlignTable['u751'] = 'top';
var u325 = document.getElementById('u325');
gv_vAlignTable['u325'] = 'top';
var u433 = document.getElementById('u433');

var u944 = document.getElementById('u944');
gv_vAlignTable['u944'] = 'top';
var u178 = document.getElementById('u178');
gv_vAlignTable['u178'] = 'top';
var u1192 = document.getElementById('u1192');
gv_vAlignTable['u1192'] = 'top';
var u583 = document.getElementById('u583');
gv_vAlignTable['u583'] = 'top';
var u241 = document.getElementById('u241');
gv_vAlignTable['u241'] = 'top';
var u115 = document.getElementById('u115');
gv_vAlignTable['u115'] = 'top';
var u691 = document.getElementById('u691');
gv_vAlignTable['u691'] = 'top';
var u171 = document.getElementById('u171');
gv_vAlignTable['u171'] = 'top';
var u83 = document.getElementById('u83');
gv_vAlignTable['u83'] = 'top';
var u544 = document.getElementById('u544');
gv_vAlignTable['u544'] = 'top';
var u391 = document.getElementById('u391');
gv_vAlignTable['u391'] = 'top';
var u1417 = document.getElementById('u1417');
gv_vAlignTable['u1417'] = 'top';
var u1416 = document.getElementById('u1416');
gv_vAlignTable['u1416'] = 'top';
var u1415 = document.getElementById('u1415');
gv_vAlignTable['u1415'] = 'top';
var u1414 = document.getElementById('u1414');
gv_vAlignTable['u1414'] = 'top';
var u1413 = document.getElementById('u1413');
gv_vAlignTable['u1413'] = 'top';
var u1412 = document.getElementById('u1412');
gv_vAlignTable['u1412'] = 'top';
var u1411 = document.getElementById('u1411');
gv_vAlignTable['u1411'] = 'top';
var u1410 = document.getElementById('u1410');
gv_vAlignTable['u1410'] = 'top';
var u98 = document.getElementById('u98');
gv_vAlignTable['u98'] = 'top';
var u694 = document.getElementById('u694');
gv_vAlignTable['u694'] = 'top';
var u43 = document.getElementById('u43');

var u352 = document.getElementById('u352');
gv_vAlignTable['u352'] = 'top';
var u1418 = document.getElementById('u1418');
gv_vAlignTable['u1418'] = 'top';
var u989 = document.getElementById('u989');
gv_vAlignTable['u989'] = 'top';
var u725 = document.getElementById('u725');
gv_vAlignTable['u725'] = 'top';
var u967 = document.getElementById('u967');

var u655 = document.getElementById('u655');
gv_vAlignTable['u655'] = 'top';
var u982 = document.getElementById('u982');
gv_vAlignTable['u982'] = 'top';
var u949 = document.getElementById('u949');

var u708 = document.getElementById('u708');
gv_vAlignTable['u708'] = 'top';
var u4 = document.getElementById('u4');
gv_vAlignTable['u4'] = 'top';
var u407 = document.getElementById('u407');
gv_vAlignTable['u407'] = 'top';
var u701 = document.getElementById('u701');
gv_vAlignTable['u701'] = 'top';
var u463 = document.getElementById('u463');
gv_vAlignTable['u463'] = 'top';
var u184 = document.getElementById('u184');
gv_vAlignTable['u184'] = 'top';
var u145 = document.getElementById('u145');
gv_vAlignTable['u145'] = 'top';
var u346 = document.getElementById('u346');
gv_vAlignTable['u346'] = 'top';
var u86 = document.getElementById('u86');
gv_vAlignTable['u86'] = 'top';
var u574 = document.getElementById('u574');

var u1157 = document.getElementById('u1157');
gv_vAlignTable['u1157'] = 'top';
var u1156 = document.getElementById('u1156');

var u1155 = document.getElementById('u1155');
gv_vAlignTable['u1155'] = 'top';
var u1154 = document.getElementById('u1154');
gv_vAlignTable['u1154'] = 'top';
var u1153 = document.getElementById('u1153');
gv_vAlignTable['u1153'] = 'top';
var u1152 = document.getElementById('u1152');
gv_vAlignTable['u1152'] = 'top';
var u1151 = document.getElementById('u1151');
gv_vAlignTable['u1151'] = 'top';
var u869 = document.getElementById('u869');
gv_vAlignTable['u869'] = 'top';
var u326 = document.getElementById('u326');
gv_vAlignTable['u326'] = 'top';
var u30 = document.getElementById('u30');

u30.style.cursor = 'pointer';
if (bIE) u30.attachEvent("onclick", Clicku30);
else u30.addEventListener("click", Clicku30, true);
function Clicku30(e)
{
windowEvent = e;


if (true) {

	self.location.href="#" + GetQuerystring();

}

}

var u620 = document.getElementById('u620');
gv_vAlignTable['u620'] = 'top';
var u862 = document.getElementById('u862');
gv_vAlignTable['u862'] = 'top';
var u256 = document.getElementById('u256');

var u309 = document.getElementById('u309');
gv_vAlignTable['u309'] = 'top';
var u838 = document.getElementById('u838');

var u302 = document.getElementById('u302');
gv_vAlignTable['u302'] = 'top';
var u738 = document.getElementById('u738');
gv_vAlignTable['u738'] = 'top';
var u1009 = document.getElementById('u1009');
gv_vAlignTable['u1009'] = 'top';
var u917 = document.getElementById('u917');
gv_vAlignTable['u917'] = 'top';
var u731 = document.getElementById('u731');
gv_vAlignTable['u731'] = 'top';
var u973 = document.getElementById('u973');
gv_vAlignTable['u973'] = 'top';
var u110 = document.getElementById('u110');
gv_vAlignTable['u110'] = 'top';
var u587 = document.getElementById('u587');
gv_vAlignTable['u587'] = 'top';
var u175 = document.getElementById('u175');
gv_vAlignTable['u175'] = 'top';
var u228 = document.getElementById('u228');
gv_vAlignTable['u228'] = 'top';
var u1456 = document.getElementById('u1456');

var u1455 = document.getElementById('u1455');

var u1454 = document.getElementById('u1454');

var u1453 = document.getElementById('u1453');

var u1452 = document.getElementById('u1452');
gv_vAlignTable['u1452'] = 'top';
var u1451 = document.getElementById('u1451');
gv_vAlignTable['u1451'] = 'top';
var u1450 = document.getElementById('u1450');
gv_vAlignTable['u1450'] = 'top';
var u1287 = document.getElementById('u1287');
gv_vAlignTable['u1287'] = 'top';
var u1286 = document.getElementById('u1286');
gv_vAlignTable['u1286'] = 'top';
var u1285 = document.getElementById('u1285');
gv_vAlignTable['u1285'] = 'top';
var u836 = document.getElementById('u836');
gv_vAlignTable['u836'] = 'top';
var u1283 = document.getElementById('u1283');
gv_vAlignTable['u1283'] = 'top';
var u650 = document.getElementById('u650');

u650.style.cursor = 'pointer';
if (bIE) u650.attachEvent("onclick", Clicku650);
else u650.addEventListener("click", Clicku650, true);
function Clicku650(e)
{
windowEvent = e;


if (true) {

	SetPanelState('u431', 'pd1u431','none','',500,'none','',500);

}

}
gv_vAlignTable['u650'] = 'top';
var u1281 = document.getElementById('u1281');
gv_vAlignTable['u1281'] = 'top';
var u1280 = document.getElementById('u1280');

var u906 = document.getElementById('u906');
gv_vAlignTable['u906'] = 'top';
var u1217 = document.getElementById('u1217');
gv_vAlignTable['u1217'] = 'top';
var u1216 = document.getElementById('u1216');
gv_vAlignTable['u1216'] = 'top';
var u1215 = document.getElementById('u1215');
gv_vAlignTable['u1215'] = 'top';
var u1214 = document.getElementById('u1214');
gv_vAlignTable['u1214'] = 'top';
var u1213 = document.getElementById('u1213');
gv_vAlignTable['u1213'] = 'top';
var u1212 = document.getElementById('u1212');
gv_vAlignTable['u1212'] = 'top';
var u1211 = document.getElementById('u1211');
gv_vAlignTable['u1211'] = 'top';
var u1210 = document.getElementById('u1210');
gv_vAlignTable['u1210'] = 'top';
var u48 = document.getElementById('u48');

u48.style.cursor = 'pointer';
if (bIE) u48.attachEvent("onclick", Clicku48);
else u48.addEventListener("click", Clicku48, true);
function Clicku48(e)
{
windowEvent = e;


if (true) {

	self.location.href="产品展示管理.html" + GetQuerystring();

}

}
gv_vAlignTable['u48'] = 'top';
var u365 = document.getElementById('u365');
gv_vAlignTable['u365'] = 'top';
var u1219 = document.getElementById('u1219');
gv_vAlignTable['u1219'] = 'top';
var u1218 = document.getElementById('u1218');
gv_vAlignTable['u1218'] = 'top';
var u489 = document.getElementById('u489');
gv_vAlignTable['u489'] = 'top';
var u705 = document.getElementById('u705');
gv_vAlignTable['u705'] = 'top';
var u947 = document.getElementById('u947');
gv_vAlignTable['u947'] = 'top';
var u761 = document.getElementById('u761');

var u482 = document.getElementById('u482');
gv_vAlignTable['u482'] = 'top';
var u140 = document.getElementById('u140');
gv_vAlignTable['u140'] = 'top';
var u202 = document.getElementById('u202');
gv_vAlignTable['u202'] = 'top';
var u513 = document.getElementById('u513');
gv_vAlignTable['u513'] = 'top';
var u859 = document.getElementById('u859');

var u443 = document.getElementById('u443');
gv_vAlignTable['u443'] = 'top';
var u290 = document.getElementById('u290');
gv_vAlignTable['u290'] = 'top';
var u258 = document.getElementById('u258');
gv_vAlignTable['u258'] = 'top';
var u593 = document.getElementById('u593');
gv_vAlignTable['u593'] = 'top';
var u251 = document.getElementById('u251');

u251.style.cursor = 'pointer';
if (bIE) u251.attachEvent("onclick", Clicku251);
else u251.addEventListener("click", Clicku251, true);
function Clicku251(e)
{
windowEvent = e;


if (true) {

	SetPanelState('u57', 'pd1u57','none','',500,'none','',500);

}

}
gv_vAlignTable['u251'] = 'top';
var u888 = document.getElementById('u888');
gv_vAlignTable['u888'] = 'top';
var u47 = document.getElementById('u47');

u47.style.cursor = 'pointer';
if (bIE) u47.attachEvent("onclick", Clicku47);
else u47.addEventListener("click", Clicku47, true);
function Clicku47(e)
{
windowEvent = e;


if (true) {

	self.location.href="resources/reload.html#" + encodeURI(PageUrl + GetQuerystring());

}

}
gv_vAlignTable['u47'] = 'top';
var u624 = document.getElementById('u624');
gv_vAlignTable['u624'] = 'top';
var u866 = document.getElementById('u866');

var u84 = document.getElementById('u84');
gv_vAlignTable['u84'] = 'top';
var u881 = document.getElementById('u881');
gv_vAlignTable['u881'] = 'top';
var u369 = document.getElementById('u369');

var u332 = document.getElementById('u332');
gv_vAlignTable['u332'] = 'top';
var u99 = document.getElementById('u99');

var u912 = document.getElementById('u912');
gv_vAlignTable['u912'] = 'top';
var u306 = document.getElementById('u306');
gv_vAlignTable['u306'] = 'top';
var u362 = document.getElementById('u362');
gv_vAlignTable['u362'] = 'top';
var u999 = document.getElementById('u999');
gv_vAlignTable['u999'] = 'top';
var u768 = document.getElementById('u768');
gv_vAlignTable['u768'] = 'center';
var u216 = document.getElementById('u216');
gv_vAlignTable['u216'] = 'top';
var u735 = document.getElementById('u735');
gv_vAlignTable['u735'] = 'top';
var u977 = document.getElementById('u977');
gv_vAlignTable['u977'] = 'top';
var u92 = document.getElementById('u92');
gv_vAlignTable['u92'] = 'top';
var u992 = document.getElementById('u992');
gv_vAlignTable['u992'] = 'top';
var u927 = document.getElementById('u927');
gv_vAlignTable['u927'] = 'top';
var u417 = document.getElementById('u417');

var u473 = document.getElementById('u473');
gv_vAlignTable['u473'] = 'top';
var u830 = document.getElementById('u830');
gv_vAlignTable['u830'] = 'top';
var u194 = document.getElementById('u194');
gv_vAlignTable['u194'] = 'top';
var u225 = document.getElementById('u225');
gv_vAlignTable['u225'] = 'top';
var u155 = document.getElementById('u155');
gv_vAlignTable['u155'] = 'top';
var u654 = document.getElementById('u654');

var u87 = document.getElementById('u87');

var u6 = document.getElementById('u6');
gv_vAlignTable['u6'] = 'top';
var u1257 = document.getElementById('u1257');
gv_vAlignTable['u1257'] = 'top';
var u1256 = document.getElementById('u1256');
gv_vAlignTable['u1256'] = 'top';
var u1255 = document.getElementById('u1255');
gv_vAlignTable['u1255'] = 'top';
var u1254 = document.getElementById('u1254');

var u1253 = document.getElementById('u1253');
gv_vAlignTable['u1253'] = 'top';
var u1252 = document.getElementById('u1252');

var u1251 = document.getElementById('u1251');
gv_vAlignTable['u1251'] = 'top';
var u1250 = document.getElementById('u1250');

var u700 = document.getElementById('u700');
gv_vAlignTable['u700'] = 'top';
var u336 = document.getElementById('u336');
gv_vAlignTable['u336'] = 'top';
var u31 = document.getElementById('u31');
gv_vAlignTable['u31'] = 'center';
var u630 = document.getElementById('u630');
gv_vAlignTable['u630'] = 'top';
var u872 = document.getElementById('u872');
gv_vAlignTable['u872'] = 'top';
var u1409 = document.getElementById('u1409');
gv_vAlignTable['u1409'] = 'top';
var u765 = document.getElementById('u765');

var u486 = document.getElementById('u486');
gv_vAlignTable['u486'] = 'top';
var u816 = document.getElementById('u816');
gv_vAlignTable['u816'] = 'top';
var u780 = document.getElementById('u780');
gv_vAlignTable['u780'] = 'center';
var u748 = document.getElementById('u748');
gv_vAlignTable['u748'] = 'top';
var u447 = document.getElementById('u447');
gv_vAlignTable['u447'] = 'top';
var u120 = document.getElementById('u120');
gv_vAlignTable['u120'] = 'top';
var u597 = document.getElementById('u597');
gv_vAlignTable['u597'] = 'top';
var u238 = document.getElementById('u238');

u238.style.cursor = 'pointer';
if (bIE) u238.attachEvent("onclick", Clicku238);
else u238.addEventListener("click", Clicku238, true);
function Clicku238(e)
{
windowEvent = e;


if (true) {

	SetPanelState('u57', 'pd0u57','none','',500,'none','',500);

}

}

var u946 = document.getElementById('u946');
gv_vAlignTable['u946'] = 'top';
var u231 = document.getElementById('u231');
gv_vAlignTable['u231'] = 'top';
var u388 = document.getElementById('u388');
gv_vAlignTable['u388'] = 'top';
var u856 = document.getElementById('u856');

x = 0;
y = 0;
InsertAfterBegin(document.getElementById('u856ann'), "<div id='u856Note' class='annnoteimage' style='left:" + x + ";top:" + y + "'></div>");
$('#u856Note').click(function(e) { ToggleWorkflow(e, 'u856', 300, 150, false); return false; });
var u856Ann = 
{
"label":"?",
"Description":"仅生产制造类 网店用户 有创建新产品的 功能按钮"};

u856.style.cursor = 'pointer';
if (bIE) u856.attachEvent("onclick", Clicku856);
else u856.addEventListener("click", Clicku856, true);
function Clicku856(e)
{
windowEvent = e;


if (true) {

	self.location.href="产品创建.html" + GetQuerystring();

}

}

var u1386 = document.getElementById('u1386');
gv_vAlignTable['u1386'] = 'center';
var u604 = document.getElementById('u604');
gv_vAlignTable['u604'] = 'top';
var u366 = document.getElementById('u366');
gv_vAlignTable['u366'] = 'top';
var u34 = document.getElementById('u34');

u34.style.cursor = 'pointer';
if (bIE) u34.attachEvent("onclick", Clicku34);
else u34.addEventListener("click", Clicku34, true);
function Clicku34(e)
{
windowEvent = e;


if (true) {

	self.location.href="采购首页.html" + GetQuerystring();

}

}
gv_vAlignTable['u34'] = 'top';
var u660 = document.getElementById('u660');
gv_vAlignTable['u660'] = 'top';
var u1381 = document.getElementById('u1381');

var u1380 = document.getElementById('u1380');
gv_vAlignTable['u1380'] = 'center';
var u381 = document.getElementById('u381');
gv_vAlignTable['u381'] = 'top';
var u349 = document.getElementById('u349');
gv_vAlignTable['u349'] = 'top';
var u1388 = document.getElementById('u1388');
gv_vAlignTable['u1388'] = 'center';
var u996 = document.getElementById('u996');
gv_vAlignTable['u996'] = 'top';
var u49 = document.getElementById('u49');

u49.style.cursor = 'pointer';
if (bIE) u49.attachEvent("onclick", Clicku49);
else u49.addEventListener("click", Clicku49, true);
function Clicku49(e)
{
windowEvent = e;


if (true) {

	self.location.href="#" + GetQuerystring();

}

}
gv_vAlignTable['u49'] = 'top';
var u412 = document.getElementById('u412');
gv_vAlignTable['u412'] = 'top';
var u342 = document.getElementById('u342');
gv_vAlignTable['u342'] = 'top';
var u778 = document.getElementById('u778');
gv_vAlignTable['u778'] = 'center';
var u499 = document.getElementById('u499');

var u715 = document.getElementById('u715');
gv_vAlignTable['u715'] = 'top';
var u477 = document.getElementById('u477');
gv_vAlignTable['u477'] = 'top';
var u771 = document.getElementById('u771');

var u492 = document.getElementById('u492');
gv_vAlignTable['u492'] = 'top';
var u1377 = document.getElementById('u1377');

var u150 = document.getElementById('u150');

var u1371 = document.getElementById('u1371');

var u523 = document.getElementById('u523');

var u835 = document.getElementById('u835');
gv_vAlignTable['u835'] = 'top';
var u268 = document.getElementById('u268');
gv_vAlignTable['u268'] = 'top';
var u811 = document.getElementById('u811');
gv_vAlignTable['u811'] = 'top';
var u205 = document.getElementById('u205');
gv_vAlignTable['u205'] = 'top';
var u81 = document.getElementById('u81');

var u261 = document.getElementById('u261');
gv_vAlignTable['u261'] = 'top';
var u898 = document.getElementById('u898');

var u319 = document.getElementById('u319');
gv_vAlignTable['u319'] = 'top';
var u634 = document.getElementById('u634');
gv_vAlignTable['u634'] = 'top';
var u876 = document.getElementById('u876');
gv_vAlignTable['u876'] = 'top';
var u85 = document.getElementById('u85');
gv_vAlignTable['u85'] = 'top';
var u221 = document.getElementById('u221');
gv_vAlignTable['u221'] = 'top';
var u1057 = document.getElementById('u1057');
gv_vAlignTable['u1057'] = 'top';
var u1056 = document.getElementById('u1056');
gv_vAlignTable['u1056'] = 'top';
var u1055 = document.getElementById('u1055');

var u929 = document.getElementById('u929');
gv_vAlignTable['u929'] = 'top';
var u1053 = document.getElementById('u1053');
gv_vAlignTable['u1053'] = 'top';
var u1052 = document.getElementById('u1052');
gv_vAlignTable['u1052'] = 'top';
var u1051 = document.getElementById('u1051');
gv_vAlignTable['u1051'] = 'top';
var u1050 = document.getElementById('u1050');
gv_vAlignTable['u1050'] = 'top';
var u784 = document.getElementById('u784');
gv_vAlignTable['u784'] = 'center';
var u922 = document.getElementById('u922');

var u316 = document.getElementById('u316');
gv_vAlignTable['u316'] = 'top';
var u1058 = document.getElementById('u1058');
gv_vAlignTable['u1058'] = 'top';
var u372 = document.getElementById('u372');
gv_vAlignTable['u372'] = 'top';
var u1125 = document.getElementById('u1125');
gv_vAlignTable['u1125'] = 'top';
var u1122 = document.getElementById('u1122');
gv_vAlignTable['u1122'] = 'top';
var u745 = document.getElementById('u745');
gv_vAlignTable['u745'] = 'top';
var u124 = document.getElementById('u124');
gv_vAlignTable['u124'] = 'top';
var u94 = document.getElementById('u94');
gv_vAlignTable['u94'] = 'top';
var u918 = document.getElementById('u918');
gv_vAlignTable['u918'] = 'top';
var u553 = document.getElementById('u553');
gv_vAlignTable['u553'] = 'top';
var u427 = document.getElementById('u427');
gv_vAlignTable['u427'] = 'top';
var u802 = document.getElementById('u802');
gv_vAlignTable['u802'] = 'top';
var u841 = document.getElementById('u841');

var u235 = document.getElementById('u235');
gv_vAlignTable['u235'] = 'top';
var u664 = document.getElementById('u664');

var u991 = document.getElementById('u991');
gv_vAlignTable['u991'] = 'top';
var u385 = document.getElementById('u385');
gv_vAlignTable['u385'] = 'top';
var u1357 = document.getElementById('u1357');
gv_vAlignTable['u1357'] = 'top';
var u1356 = document.getElementById('u1356');
gv_vAlignTable['u1356'] = 'top';
var u1355 = document.getElementById('u1355');
gv_vAlignTable['u1355'] = 'top';
var u1354 = document.getElementById('u1354');
gv_vAlignTable['u1354'] = 'top';
var u1353 = document.getElementById('u1353');
gv_vAlignTable['u1353'] = 'top';
var u1352 = document.getElementById('u1352');

var u1351 = document.getElementById('u1351');
gv_vAlignTable['u1351'] = 'top';
var u1350 = document.getElementById('u1350');
gv_vAlignTable['u1350'] = 'top';
var u710 = document.getElementById('u710');
gv_vAlignTable['u710'] = 'top';
var u952 = document.getElementById('u952');
gv_vAlignTable['u952'] = 'top';
var u1359 = document.getElementById('u1359');
gv_vAlignTable['u1359'] = 'top';
var u1358 = document.getElementById('u1358');
gv_vAlignTable['u1358'] = 'top';
var u932 = document.getElementById('u932');
gv_vAlignTable['u932'] = 'top';
var u775 = document.getElementById('u775');

var u496 = document.getElementById('u496');
gv_vAlignTable['u496'] = 'top';
var u154 = document.getElementById('u154');
gv_vAlignTable['u154'] = 'top';
var u367 = document.getElementById('u367');
gv_vAlignTable['u367'] = 'top';
var u457 = document.getElementById('u457');
gv_vAlignTable['u457'] = 'top';
var u200 = document.getElementById('u200');
gv_vAlignTable['u200'] = 'top';
var u130 = document.getElementById('u130');
gv_vAlignTable['u130'] = 'top';
var u839 = document.getElementById('u839');

var u503 = document.getElementById('u503');
gv_vAlignTable['u503'] = 'top';
var u265 = document.getElementById('u265');
gv_vAlignTable['u265'] = 'top';
var u1007 = document.getElementById('u1007');
gv_vAlignTable['u1007'] = 'top';
var u1006 = document.getElementById('u1006');
gv_vAlignTable['u1006'] = 'top';
var u1005 = document.getElementById('u1005');
gv_vAlignTable['u1005'] = 'top';
var u1004 = document.getElementById('u1004');
gv_vAlignTable['u1004'] = 'top';
var u1003 = document.getElementById('u1003');
gv_vAlignTable['u1003'] = 'top';
var u1002 = document.getElementById('u1002');
gv_vAlignTable['u1002'] = 'top';
var u1001 = document.getElementById('u1001');
gv_vAlignTable['u1001'] = 'top';
var u1000 = document.getElementById('u1000');
gv_vAlignTable['u1000'] = 'top';
var u248 = document.getElementById('u248');
gv_vAlignTable['u248'] = 'top';
var u895 = document.getElementById('u895');
gv_vAlignTable['u895'] = 'top';
var u311 = document.getElementById('u311');
gv_vAlignTable['u311'] = 'top';
var u1008 = document.getElementById('u1008');
gv_vAlignTable['u1008'] = 'top';
var u1239 = document.getElementById('u1239');
gv_vAlignTable['u1239'] = 'top';
var u821 = document.getElementById('u821');
gv_vAlignTable['u821'] = 'top';
var u926 = document.getElementById('u926');
gv_vAlignTable['u926'] = 'top';
var u90 = document.getElementById('u90');
gv_vAlignTable['u90'] = 'top';
var u740 = document.getElementById('u740');
gv_vAlignTable['u740'] = 'top';
var u614 = document.getElementById('u614');
gv_vAlignTable['u614'] = 'top';
var u376 = document.getElementById('u376');
gv_vAlignTable['u376'] = 'top';
var u35 = document.getElementById('u35');

u35.style.cursor = 'pointer';
if (bIE) u35.attachEvent("onclick", Clicku35);
else u35.addEventListener("click", Clicku35, true);
function Clicku35(e)
{
windowEvent = e;


if (true) {

}

}
gv_vAlignTable['u35'] = 'top';
var u670 = document.getElementById('u670');
gv_vAlignTable['u670'] = 'top';
var u429 = document.getElementById('u429');

x = 0;
y = 0;
InsertAfterBegin(document.getElementById('u429ann'), "<div id='u429Note' class='annnoteimage' style='left:" + x + ";top:" + y + "'></div>");
$('#u429Note').click(function(e) { ToggleWorkflow(e, 'u429', 300, 150, false); return false; });
var u429Ann = 
{
"label":"?",
"Description":"两种状态，可引用企标产品 或 引用通用产品"};

u429.style.cursor = 'pointer';
if (bIE) u429.attachEvent("onclick", Clicku429);
else u429.addEventListener("click", Clicku429, true);
function Clicku429(e)
{
windowEvent = e;


if (true) {

	self.location.href="产品引用.html" + GetQuerystring();

}

}

var u651 = document.getElementById('u651');
gv_vAlignTable['u651'] = 'top';
var u359 = document.getElementById('u359');
gv_vAlignTable['u359'] = 'top';
var u422 = document.getElementById('u422');
gv_vAlignTable['u422'] = 'top';
var u334 = document.getElementById('u334');
gv_vAlignTable['u334'] = 'top';
var u104 = document.getElementById('u104');
gv_vAlignTable['u104'] = 'top';
var u160 = document.getElementById('u160');
gv_vAlignTable['u160'] = 'top';
var u1284 = document.getElementById('u1284');

u1284.style.cursor = 'pointer';
if (bIE) u1284.attachEvent("onclick", Clicku1284);
else u1284.addEventListener("click", Clicku1284, true);
function Clicku1284(e)
{
windowEvent = e;


if (true) {

	SetPanelState('u56', 'pd2u56','none','',500,'none','',500);

}

}
gv_vAlignTable['u1284'] = 'top';
var u1282 = document.getElementById('u1282');
gv_vAlignTable['u1282'] = 'top';
var u1307 = document.getElementById('u1307');
gv_vAlignTable['u1307'] = 'top';
var u1306 = document.getElementById('u1306');
gv_vAlignTable['u1306'] = 'top';
var u1305 = document.getElementById('u1305');
gv_vAlignTable['u1305'] = 'top';
var u1304 = document.getElementById('u1304');

var u1303 = document.getElementById('u1303');
gv_vAlignTable['u1303'] = 'top';
var u1302 = document.getElementById('u1302');
gv_vAlignTable['u1302'] = 'top';
var u1301 = document.getElementById('u1301');
gv_vAlignTable['u1301'] = 'top';
var u1300 = document.getElementById('u1300');
gv_vAlignTable['u1300'] = 'top';
var u278 = document.getElementById('u278');
gv_vAlignTable['u278'] = 'top';
var u1288 = document.getElementById('u1288');

var u683 = document.getElementById('u683');
gv_vAlignTable['u683'] = 'top';
var u341 = document.getElementById('u341');
gv_vAlignTable['u341'] = 'top';
var u1308 = document.getElementById('u1308');
gv_vAlignTable['u1308'] = 'top';
var u271 = document.getElementById('u271');
gv_vAlignTable['u271'] = 'top';
var u93 = document.getElementById('u93');

var u644 = document.getElementById('u644');

var u491 = document.getElementById('u491');

var u939 = document.getElementById('u939');
gv_vAlignTable['u939'] = 'top';
var u339 = document.getElementById('u339');

var u794 = document.getElementById('u794');
gv_vAlignTable['u794'] = 'top';
var u452 = document.getElementById('u452');
gv_vAlignTable['u452'] = 'top';
var u755 = document.getElementById('u755');

var u842 = document.getElementById('u842');
gv_vAlignTable['u842'] = 'top';
var u1429 = document.getElementById('u1429');
gv_vAlignTable['u1429'] = 'top';
var u134 = document.getElementById('u134');
gv_vAlignTable['u134'] = 'top';
var u5 = document.getElementById('u5');
gv_vAlignTable['u5'] = 'top';
var u507 = document.getElementById('u507');

var u563 = document.getElementById('u563');
gv_vAlignTable['u563'] = 'center';
var u1047 = document.getElementById('u1047');
gv_vAlignTable['u1047'] = 'top';
var u1046 = document.getElementById('u1046');

var u284 = document.getElementById('u284');
gv_vAlignTable['u284'] = 'top';
var u1044 = document.getElementById('u1044');
gv_vAlignTable['u1044'] = 'top';
var u1043 = document.getElementById('u1043');

var u1042 = document.getElementById('u1042');
gv_vAlignTable['u1042'] = 'top';
var u1041 = document.getElementById('u1041');
gv_vAlignTable['u1041'] = 'top';
var u1040 = document.getElementById('u1040');
gv_vAlignTable['u1040'] = 'top';
var u1049 = document.getElementById('u1049');
gv_vAlignTable['u1049'] = 'top';
var u1048 = document.getElementById('u1048');
gv_vAlignTable['u1048'] = 'top';
var u851 = document.getElementById('u851');

var u245 = document.getElementById('u245');

var u96 = document.getElementById('u96');
gv_vAlignTable['u96'] = 'top';
var u674 = document.getElementById('u674');
gv_vAlignTable['u674'] = 'top';
var u395 = document.getElementById('u395');
gv_vAlignTable['u395'] = 'top';
var u969 = document.getElementById('u969');

var u426 = document.getElementById('u426');

var u40 = document.getElementById('u40');

x = 0;
y = 0;
InsertAfterBegin(document.getElementById('u40ann'), "<div id='u40Note' class='annnoteimage' style='left:" + x + ";top:" + y + "'></div>");
$('#u40Note').click(function(e) { ToggleWorkflow(e, 'u40', 300, 150, false); return false; });
var u40Ann = 
{
"label":"?",
"Description":"当前窗口打开具体链接未定"};

u40.style.cursor = 'pointer';
if (bIE) u40.attachEvent("onclick", Clicku40);
else u40.addEventListener("click", Clicku40, true);
function Clicku40(e)
{
windowEvent = e;


if (true) {

	self.location.href="账号管理.html" + GetQuerystring();

}

}
gv_vAlignTable['u40'] = 'top';
var u720 = document.getElementById('u720');

var u962 = document.getElementById('u962');
gv_vAlignTable['u962'] = 'top';
var u356 = document.getElementById('u356');
gv_vAlignTable['u356'] = 'top';
var u409 = document.getElementById('u409');
gv_vAlignTable['u409'] = 'top';
var u402 = document.getElementById('u402');

var u164 = document.getElementById('u164');
gv_vAlignTable['u164'] = 'top';
var u537 = document.getElementById('u537');
gv_vAlignTable['u537'] = 'top';
var u958 = document.getElementById('u958');
gv_vAlignTable['u958'] = 'top';
var u358 = document.getElementById('u358');
gv_vAlignTable['u358'] = 'top';
var u1361 = document.getElementById('u1361');
gv_vAlignTable['u1361'] = 'top';
var u687 = document.getElementById('u687');
gv_vAlignTable['u687'] = 'top';
var u1369 = document.getElementById('u1369');
gv_vAlignTable['u1369'] = 'top';
var u825 = document.getElementById('u825');
gv_vAlignTable['u825'] = 'top';
var u275 = document.getElementById('u275');
gv_vAlignTable['u275'] = 'top';
var u119 = document.getElementById('u119');
gv_vAlignTable['u119'] = 'top';
var u1107 = document.getElementById('u1107');
gv_vAlignTable['u1107'] = 'top';
var u1106 = document.getElementById('u1106');
gv_vAlignTable['u1106'] = 'top';
var u1105 = document.getElementById('u1105');

var u1104 = document.getElementById('u1104');
gv_vAlignTable['u1104'] = 'top';
var u328 = document.getElementById('u328');
gv_vAlignTable['u328'] = 'top';
var u1102 = document.getElementById('u1102');
gv_vAlignTable['u1102'] = 'top';
var u1101 = document.getElementById('u1101');
gv_vAlignTable['u1101'] = 'top';
var u1100 = document.getElementById('u1100');
gv_vAlignTable['u1100'] = 'top';
var u1109 = document.getElementById('u1109');
gv_vAlignTable['u1109'] = 'top';
var u1108 = document.getElementById('u1108');
gv_vAlignTable['u1108'] = 'top';
var u915 = document.getElementById('u915');
gv_vAlignTable['u915'] = 'top';
var u936 = document.getElementById('u936');
gv_vAlignTable['u936'] = 'top';
var u91 = document.getElementById('u91');
gv_vAlignTable['u91'] = 'top';
var u750 = document.getElementById('u750');
gv_vAlignTable['u750'] = 'top';
var u293 = document.getElementById('u293');
gv_vAlignTable['u293'] = 'top';
var u439 = document.getElementById('u439');

var u58 = document.getElementById('u58');
gv_vAlignTable['u58'] = 'top';
var u432 = document.getElementById('u432');
gv_vAlignTable['u432'] = 'top';
var u249 = document.getElementById('u249');
gv_vAlignTable['u249'] = 'top';
var u589 = document.getElementById('u589');
gv_vAlignTable['u589'] = 'top';
var u567 = document.getElementById('u567');
gv_vAlignTable['u567'] = 'center';
var u504 = document.getElementById('u504');
gv_vAlignTable['u504'] = 'top';
var u582 = document.getElementById('u582');
gv_vAlignTable['u582'] = 'top';
var u240 = document.getElementById('u240');
gv_vAlignTable['u240'] = 'top';
var u114 = document.getElementById('u114');
gv_vAlignTable['u114'] = 'top';
var u170 = document.getElementById('u170');

var u613 = document.getElementById('u613');
gv_vAlignTable['u613'] = 'top';
var u1015 = document.getElementById('u1015');
gv_vAlignTable['u1015'] = 'top';
var u543 = document.getElementById('u543');
gv_vAlignTable['u543'] = 'top';
var u1064 = document.getElementById('u1064');
gv_vAlignTable['u1064'] = 'top';
var u390 = document.getElementById('u390');
gv_vAlignTable['u390'] = 'top';
var u1407 = document.getElementById('u1407');
gv_vAlignTable['u1407'] = 'top';
var u1406 = document.getElementById('u1406');
gv_vAlignTable['u1406'] = 'top';
var u1405 = document.getElementById('u1405');
gv_vAlignTable['u1405'] = 'top';
var u1404 = document.getElementById('u1404');
gv_vAlignTable['u1404'] = 'top';
var u1403 = document.getElementById('u1403');
gv_vAlignTable['u1403'] = 'top';
var u1402 = document.getElementById('u1402');
gv_vAlignTable['u1402'] = 'top';
var u1401 = document.getElementById('u1401');
gv_vAlignTable['u1401'] = 'top';
var u1400 = document.getElementById('u1400');
gv_vAlignTable['u1400'] = 'top';
var u693 = document.getElementById('u693');
gv_vAlignTable['u693'] = 'top';
var u351 = document.getElementById('u351');
gv_vAlignTable['u351'] = 'top';
var u1408 = document.getElementById('u1408');
gv_vAlignTable['u1408'] = 'top';
var u379 = document.getElementById('u379');
gv_vAlignTable['u379'] = 'top';
var u988 = document.getElementById('u988');
gv_vAlignTable['u988'] = 'top';
var u857 = document.getElementById('u857');
gv_vAlignTable['u857'] = 'top';
var u724 = document.getElementById('u724');
gv_vAlignTable['u724'] = 'top';
var u966 = document.getElementById('u966');

var u46 = document.getElementById('u46');

u46.style.cursor = 'pointer';
if (bIE) u46.attachEvent("onclick", Clicku46);
else u46.addEventListener("click", Clicku46, true);
function Clicku46(e)
{
windowEvent = e;


if (true) {

	self.location.href="通用产品互动.html" + GetQuerystring();

}

}
gv_vAlignTable['u46'] = 'top';
var u981 = document.getElementById('u981');
gv_vAlignTable['u981'] = 'top';
var u469 = document.getElementById('u469');
gv_vAlignTable['u469'] = 'top';
var u317 = document.getElementById('u317');
gv_vAlignTable['u317'] = 'top';
var u406 = document.getElementById('u406');
gv_vAlignTable['u406'] = 'top';
var u462 = document.getElementById('u462');
gv_vAlignTable['u462'] = 'top';
var u183 = document.getElementById('u183');
gv_vAlignTable['u183'] = 'top';
var u934 = document.getElementById('u934');

var u144 = document.getElementById('u144');
gv_vAlignTable['u144'] = 'top';
var u1095 = document.getElementById('u1095');
gv_vAlignTable['u1095'] = 'top';
var u764 = document.getElementById('u764');
gv_vAlignTable['u764'] = 'center';
var u517 = document.getElementById('u517');
gv_vAlignTable['u517'] = 'top';
var u573 = document.getElementById('u573');
gv_vAlignTable['u573'] = 'center';
var u1147 = document.getElementById('u1147');
gv_vAlignTable['u1147'] = 'top';
var u809 = document.getElementById('u809');
gv_vAlignTable['u809'] = 'top';
var u294 = document.getElementById('u294');

var u1144 = document.getElementById('u1144');
gv_vAlignTable['u1144'] = 'top';
var u1143 = document.getElementById('u1143');
gv_vAlignTable['u1143'] = 'top';
var u1142 = document.getElementById('u1142');
gv_vAlignTable['u1142'] = 'top';
var u1141 = document.getElementById('u1141');
gv_vAlignTable['u1141'] = 'top';
var u1140 = document.getElementById('u1140');
gv_vAlignTable['u1140'] = 'top';
var u805 = document.getElementById('u805');
gv_vAlignTable['u805'] = 'top';
var u1148 = document.getElementById('u1148');
gv_vAlignTable['u1148'] = 'top';
var u861 = document.getElementById('u861');
gv_vAlignTable['u861'] = 'top';
var u255 = document.getElementById('u255');
gv_vAlignTable['u255'] = 'top';
var u754 = document.getElementById('u754');
gv_vAlignTable['u754'] = 'top';
var u97 = document.getElementById('u97');
gv_vAlignTable['u97'] = 'top';
var u0 = document.getElementById('u0');

var u301 = document.getElementById('u301');
gv_vAlignTable['u301'] = 'top';
var u979 = document.getElementById('u979');
gv_vAlignTable['u979'] = 'top';
var u436 = document.getElementById('u436');
gv_vAlignTable['u436'] = 'top';
var u41 = document.getElementById('u41');

x = 0;
y = 0;
InsertAfterBegin(document.getElementById('u41ann'), "<div id='u41Note' class='annnoteimage' style='left:" + x + ";top:" + y + "'></div>");
$('#u41Note').click(function(e) { ToggleWorkflow(e, 'u41', 300, 150, false); return false; });
var u41Ann = 
{
"label":"?",
"Description":"当前窗口打开具体链接未定"};

u41.style.cursor = 'pointer';
if (bIE) u41.attachEvent("onclick", Clicku41);
else u41.addEventListener("click", Clicku41, true);
function Clicku41(e)
{
windowEvent = e;


if (true) {

	self.location.href="#" + GetQuerystring();

}

}
gv_vAlignTable['u41'] = 'top';
var u730 = document.getElementById('u730');
gv_vAlignTable['u730'] = 'top';
var u972 = document.getElementById('u972');
gv_vAlignTable['u972'] = 'top';
var u1259 = document.getElementById('u1259');
gv_vAlignTable['u1259'] = 'top';
var u1258 = document.getElementById('u1258');

var u823 = document.getElementById('u823');
gv_vAlignTable['u823'] = 'top';
var u419 = document.getElementById('u419');

var u586 = document.getElementById('u586');
gv_vAlignTable['u586'] = 'top';
var u174 = document.getElementById('u174');
gv_vAlignTable['u174'] = 'top';
var u547 = document.getElementById('u547');
gv_vAlignTable['u547'] = 'top';
var u1447 = document.getElementById('u1447');
gv_vAlignTable['u1447'] = 'top';
var u1446 = document.getElementById('u1446');
gv_vAlignTable['u1446'] = 'top';
var u1445 = document.getElementById('u1445');
gv_vAlignTable['u1445'] = 'top';
var u1444 = document.getElementById('u1444');
gv_vAlignTable['u1444'] = 'top';
var u1443 = document.getElementById('u1443');
gv_vAlignTable['u1443'] = 'top';
var u1442 = document.getElementById('u1442');
gv_vAlignTable['u1442'] = 'top';
var u1441 = document.getElementById('u1441');
gv_vAlignTable['u1441'] = 'top';
var u1440 = document.getElementById('u1440');
gv_vAlignTable['u1440'] = 'top';
var u697 = document.getElementById('u697');
gv_vAlignTable['u697'] = 'top';
var u1449 = document.getElementById('u1449');
gv_vAlignTable['u1449'] = 'top';
var u1448 = document.getElementById('u1448');
gv_vAlignTable['u1448'] = 'top';
var u955 = document.getElementById('u955');
gv_vAlignTable['u955'] = 'top';
var u1207 = document.getElementById('u1207');
gv_vAlignTable['u1207'] = 'top';
var u1206 = document.getElementById('u1206');
gv_vAlignTable['u1206'] = 'top';
var u1205 = document.getElementById('u1205');
gv_vAlignTable['u1205'] = 'top';
var u1204 = document.getElementById('u1204');
gv_vAlignTable['u1204'] = 'top';
var u1203 = document.getElementById('u1203');
gv_vAlignTable['u1203'] = 'top';
var u1045 = document.getElementById('u1045');

var u1201 = document.getElementById('u1201');
gv_vAlignTable['u1201'] = 'top';
var u985 = document.getElementById('u985');
gv_vAlignTable['u985'] = 'top';
var u331 = document.getElementById('u331');
gv_vAlignTable['u331'] = 'top';
var u1208 = document.getElementById('u1208');
gv_vAlignTable['u1208'] = 'top';
var u488 = document.getElementById('u488');
gv_vAlignTable['u488'] = 'top';
var u61 = document.getElementById('u61');
gv_vAlignTable['u61'] = 'top';
var u704 = document.getElementById('u704');

var u466 = document.getElementById('u466');
gv_vAlignTable['u466'] = 'top';
var u44 = document.getElementById('u44');
gv_vAlignTable['u44'] = 'center';
var u760 = document.getElementById('u760');
gv_vAlignTable['u760'] = 'center';
var u187 = document.getElementById('u187');
gv_vAlignTable['u187'] = 'top';
var u481 = document.getElementById('u481');
gv_vAlignTable['u481'] = 'top';
var u449 = document.getElementById('u449');

var u59 = document.getElementById('u59');

var u512 = document.getElementById('u512');
gv_vAlignTable['u512'] = 'top';
var u442 = document.getElementById('u442');
gv_vAlignTable['u442'] = 'top';
var u599 = document.getElementById('u599');
gv_vAlignTable['u599'] = 'top';
var u577 = document.getElementById('u577');
gv_vAlignTable['u577'] = 'center';
var u800 = document.getElementById('u800');
gv_vAlignTable['u800'] = 'top';
var u250 = document.getElementById('u250');
gv_vAlignTable['u250'] = 'top';
var u844 = document.getElementById('u844');
gv_vAlignTable['u844'] = 'top';
var u623 = document.getElementById('u623');
gv_vAlignTable['u623'] = 'top';
var u865 = document.getElementById('u865');

var u880 = document.getElementById('u880');

var u368 = document.getElementById('u368');
gv_vAlignTable['u368'] = 'top';
var u911 = document.getElementById('u911');
gv_vAlignTable['u911'] = 'top';
var u305 = document.getElementById('u305');
gv_vAlignTable['u305'] = 'top';
var u361 = document.getElementById('u361');
gv_vAlignTable['u361'] = 'top';
var u998 = document.getElementById('u998');
gv_vAlignTable['u998'] = 'top';
var u734 = document.getElementById('u734');
gv_vAlignTable['u734'] = 'top';
var u976 = document.getElementById('u976');
gv_vAlignTable['u976'] = 'top';
var u95 = document.getElementById('u95');
gv_vAlignTable['u95'] = 'top';
var u113 = document.getElementById('u113');
gv_vAlignTable['u113'] = 'top';
var u479 = document.getElementById('u479');
gv_vAlignTable['u479'] = 'top';
var u515 = document.getElementById('u515');

var u33 = document.getElementById('u33');

u33.style.cursor = 'pointer';
if (bIE) u33.attachEvent("onclick", Clicku33);
else u33.addEventListener("click", Clicku33, true);
function Clicku33(e)
{
windowEvent = e;


if (true) {

	self.location.href="#" + GetQuerystring();

}

}
gv_vAlignTable['u33'] = 'top';
var u416 = document.getElementById('u416');
gv_vAlignTable['u416'] = 'top';
var u198 = document.getElementById('u198');
gv_vAlignTable['u198'] = 'top';
var u472 = document.getElementById('u472');
gv_vAlignTable['u472'] = 'top';
var u193 = document.getElementById('u193');
gv_vAlignTable['u193'] = 'top';
var u1116 = document.getElementById('u1116');
gv_vAlignTable['u1116'] = 'top';
var u849 = document.getElementById('u849');

var u1289 = document.getElementById('u1289');
gv_vAlignTable['u1289'] = 'top';
var u1112 = document.getElementById('u1112');
gv_vAlignTable['u1112'] = 'top';
var u224 = document.getElementById('u224');
gv_vAlignTable['u224'] = 'top';
var u1119 = document.getElementById('u1119');
gv_vAlignTable['u1119'] = 'top';
var u653 = document.getElementById('u653');
gv_vAlignTable['u653'] = 'top';
var u527 = document.getElementById('u527');
gv_vAlignTable['u527'] = 'top';
var u1247 = document.getElementById('u1247');
gv_vAlignTable['u1247'] = 'top';
var u956 = document.getElementById('u956');
gv_vAlignTable['u956'] = 'top';
var u1245 = document.getElementById('u1245');
gv_vAlignTable['u1245'] = 'top';
var u1244 = document.getElementById('u1244');

var u890 = document.getElementById('u890');
gv_vAlignTable['u890'] = 'top';
var u1242 = document.getElementById('u1242');

var u1241 = document.getElementById('u1241');

var u878 = document.getElementById('u878');
gv_vAlignTable['u878'] = 'top';
var u941 = document.getElementById('u941');
gv_vAlignTable['u941'] = 'top';
var u815 = document.getElementById('u815');
gv_vAlignTable['u815'] = 'top';
var u1248 = document.getElementById('u1248');

var u871 = document.getElementById('u871');
gv_vAlignTable['u871'] = 'top';
var u318 = document.getElementById('u318');
gv_vAlignTable['u318'] = 'top';
var u485 = document.getElementById('u485');
gv_vAlignTable['u485'] = 'top';
var u863 = document.getElementById('u863');

var u446 = document.getElementById('u446');
gv_vAlignTable['u446'] = 'top';
var u42 = document.getElementById('u42');

var u596 = document.getElementById('u596');
gv_vAlignTable['u596'] = 'top';
var u254 = document.getElementById('u254');
gv_vAlignTable['u254'] = 'top';
var u557 = document.getElementById('u557');
gv_vAlignTable['u557'] = 'center';
var u884 = document.getElementById('u884');
gv_vAlignTable['u884'] = 'top';
var u300 = document.getElementById('u300');
gv_vAlignTable['u300'] = 'top';
var u230 = document.getElementById('u230');
gv_vAlignTable['u230'] = 'top';
var u603 = document.getElementById('u603');
gv_vAlignTable['u603'] = 'top';
var u845 = document.getElementById('u845');

var u380 = document.getElementById('u380');
gv_vAlignTable['u380'] = 'top';
var u868 = document.getElementById('u868');
gv_vAlignTable['u868'] = 'top';
var u348 = document.getElementById('u348');

var u995 = document.getElementById('u995');
gv_vAlignTable['u995'] = 'top';
var u411 = document.getElementById('u411');
gv_vAlignTable['u411'] = 'top';
var u1309 = document.getElementById('u1309');
gv_vAlignTable['u1309'] = 'top';
var u498 = document.getElementById('u498');
gv_vAlignTable['u498'] = 'top';
var u806 = document.getElementById('u806');
gv_vAlignTable['u806'] = 'top';
var u714 = document.getElementById('u714');
gv_vAlignTable['u714'] = 'top';
var u476 = document.getElementById('u476');
gv_vAlignTable['u476'] = 'top';
var u45 = document.getElementById('u45');
gv_vAlignTable['u45'] = 'top';
var u770 = document.getElementById('u770');
gv_vAlignTable['u770'] = 'center';
var u197 = document.getElementById('u197');
gv_vAlignTable['u197'] = 'top';
var u529 = document.getElementById('u529');
gv_vAlignTable['u529'] = 'top';
var u459 = document.getElementById('u459');

var u522 = document.getElementById('u522');
gv_vAlignTable['u522'] = 'top';
var u218 = document.getElementById('u218');
gv_vAlignTable['u218'] = 'top';
var u810 = document.getElementById('u810');
gv_vAlignTable['u810'] = 'top';
var u204 = document.getElementById('u204');
gv_vAlignTable['u204'] = 'top';
var u260 = document.getElementById('u260');
gv_vAlignTable['u260'] = 'top';
var u308 = document.getElementById('u308');
gv_vAlignTable['u308'] = 'top';
var u633 = document.getElementById('u633');
gv_vAlignTable['u633'] = 'top';
var u875 = document.getElementById('u875');
gv_vAlignTable['u875'] = 'top';
var u1182 = document.getElementById('u1182');

var u1181 = document.getElementById('u1181');
gv_vAlignTable['u1181'] = 'center';
var u1180 = document.getElementById('u1180');

var u928 = document.getElementById('u928');

var u324 = document.getElementById('u324');
gv_vAlignTable['u324'] = 'top';
var u378 = document.getElementById('u378');
gv_vAlignTable['u378'] = 'top';
var u618 = document.getElementById('u618');
gv_vAlignTable['u618'] = 'top';
var u783 = document.getElementById('u783');

var u441 = document.getElementById('u441');
gv_vAlignTable['u441'] = 'top';
var u315 = document.getElementById('u315');
gv_vAlignTable['u315'] = 'top';
var u371 = document.getElementById('u371');
gv_vAlignTable['u371'] = 'top';
var u744 = document.getElementById('u744');

var u591 = document.getElementById('u591');
gv_vAlignTable['u591'] = 'top';
var u123 = document.getElementById('u123');

var u552 = document.getElementById('u552');
gv_vAlignTable['u552'] = 'top';
var u827 = document.getElementById('u827');
gv_vAlignTable['u827'] = 'top';
var u840 = document.getElementById('u840');

var u234 = document.getElementById('u234');
gv_vAlignTable['u234'] = 'top';
var u903 = document.getElementById('u903');
gv_vAlignTable['u903'] = 'top';
var u607 = document.getElementById('u607');
gv_vAlignTable['u607'] = 'top';
var u663 = document.getElementById('u663');
gv_vAlignTable['u663'] = 'top';
var u990 = document.getElementById('u990');
gv_vAlignTable['u990'] = 'top';
var u384 = document.getElementById('u384');
gv_vAlignTable['u384'] = 'top';
var u1347 = document.getElementById('u1347');
gv_vAlignTable['u1347'] = 'top';
var u1346 = document.getElementById('u1346');
gv_vAlignTable['u1346'] = 'top';
var u1345 = document.getElementById('u1345');
gv_vAlignTable['u1345'] = 'top';
var u1344 = document.getElementById('u1344');

var u1343 = document.getElementById('u1343');
gv_vAlignTable['u1343'] = 'top';
var u1342 = document.getElementById('u1342');
gv_vAlignTable['u1342'] = 'top';
var u1341 = document.getElementById('u1341');
gv_vAlignTable['u1341'] = 'top';
var u1340 = document.getElementById('u1340');
gv_vAlignTable['u1340'] = 'top';
var u951 = document.getElementById('u951');
gv_vAlignTable['u951'] = 'top';
var u1349 = document.getElementById('u1349');
gv_vAlignTable['u1349'] = 'top';
var u1348 = document.getElementById('u1348');
gv_vAlignTable['u1348'] = 'top';
var u774 = document.getElementById('u774');
gv_vAlignTable['u774'] = 'center';
var u495 = document.getElementById('u495');
gv_vAlignTable['u495'] = 'top';
var u153 = document.getElementById('u153');
gv_vAlignTable['u153'] = 'top';
var u526 = document.getElementById('u526');
gv_vAlignTable['u526'] = 'top';
var u50 = document.getElementById('u50');
gv_vAlignTable['u50'] = 'top';
var u456 = document.getElementById('u456');
gv_vAlignTable['u456'] = 'top';
var u509 = document.getElementById('u509');
gv_vAlignTable['u509'] = 'top';
var u908 = document.getElementById('u908');
gv_vAlignTable['u908'] = 'top';
var u76 = document.getElementById('u76');
gv_vAlignTable['u76'] = 'top';
var u502 = document.getElementById('u502');
gv_vAlignTable['u502'] = 'top';
var u264 = document.getElementById('u264');
gv_vAlignTable['u264'] = 'top';
var u637 = document.getElementById('u637');

var u894 = document.getElementById('u894');
gv_vAlignTable['u894'] = 'top';
var u310 = document.getElementById('u310');
gv_vAlignTable['u310'] = 'top';
var u787 = document.getElementById('u787');
gv_vAlignTable['u787'] = 'top';
var u925 = document.getElementById('u925');
gv_vAlignTable['u925'] = 'top';
var u855 = document.getElementById('u855');

x = 0;
y = 0;
InsertAfterBegin(document.getElementById('u855ann'), "<div id='u855Note' class='annnoteimage' style='left:" + x + ";top:" + y + "'></div>");
$('#u855Note').click(function(e) { ToggleWorkflow(e, 'u855', 300, 150, false); return false; });
var u855Ann = 
{
"label":"?",
"Description":"两种状态，可引用企标产品 或 引用通用产品"};

u855.style.cursor = 'pointer';
if (bIE) u855.attachEvent("onclick", Clicku855);
else u855.addEventListener("click", Clicku855, true);
function Clicku855(e)
{
windowEvent = e;


if (true) {

	self.location.href="产品引用.html" + GetQuerystring();

}

}

var u428 = document.getElementById('u428');

var u930 = document.getElementById('u930');
gv_vAlignTable['u930'] = 'top';
var u901 = document.getElementById('u901');
gv_vAlignTable['u901'] = 'top';
var u53 = document.getElementById('u53');
gv_vAlignTable['u53'] = 'top';
var u1228 = document.getElementById('u1228');
gv_vAlignTable['u1228'] = 'top';
var u103 = document.getElementById('u103');
gv_vAlignTable['u103'] = 'top';
var u539 = document.getElementById('u539');

var u68 = document.getElementById('u68');
gv_vAlignTable['u68'] = 'top';
var u532 = document.getElementById('u532');
gv_vAlignTable['u532'] = 'top';
var u689 = document.getElementById('u689');
gv_vAlignTable['u689'] = 'top';
var u667 = document.getElementById('u667');
gv_vAlignTable['u667'] = 'top';
var u682 = document.getElementById('u682');
gv_vAlignTable['u682'] = 'top';
var u820 = document.getElementById('u820');
gv_vAlignTable['u820'] = 'top';
var u214 = document.getElementById('u214');
gv_vAlignTable['u214'] = 'top';
var u270 = document.getElementById('u270');
gv_vAlignTable['u270'] = 'top';
var u713 = document.getElementById('u713');
gv_vAlignTable['u713'] = 'top';
var u643 = document.getElementById('u643');
gv_vAlignTable['u643'] = 'top';
var u490 = document.getElementById('u490');
gv_vAlignTable['u490'] = 'top';
var u904 = document.getElementById('u904');

var u458 = document.getElementById('u458');
gv_vAlignTable['u458'] = 'top';
var u793 = document.getElementById('u793');
gv_vAlignTable['u793'] = 'top';
var u451 = document.getElementById('u451');
gv_vAlignTable['u451'] = 'top';
var u56 = document.getElementById('u56');

var u518 = document.getElementById('u518');
gv_vAlignTable['u518'] = 'top';
var u133 = document.getElementById('u133');
gv_vAlignTable['u133'] = 'top';
var u569 = document.getElementById('u569');
gv_vAlignTable['u569'] = 'center';
var u506 = document.getElementById('u506');
gv_vAlignTable['u506'] = 'top';
var u562 = document.getElementById('u562');

var u1037 = document.getElementById('u1037');

u1037.style.cursor = 'pointer';
if (bIE) u1037.attachEvent("onclick", Clicku1037);
else u1037.addEventListener("click", Clicku1037, true);
function Clicku1037(e)
{
windowEvent = e;


if (true) {

	SetPanelState('u56', 'pd0u56','none','',500,'none','',500);

}

}

var u1036 = document.getElementById('u1036');
gv_vAlignTable['u1036'] = 'top';
var u1035 = document.getElementById('u1035');
gv_vAlignTable['u1035'] = 'top';
var u1034 = document.getElementById('u1034');
gv_vAlignTable['u1034'] = 'top';
var u1033 = document.getElementById('u1033');
gv_vAlignTable['u1033'] = 'top';
var u1032 = document.getElementById('u1032');
gv_vAlignTable['u1032'] = 'top';
var u1031 = document.getElementById('u1031');
gv_vAlignTable['u1031'] = 'top';
var u1030 = document.getElementById('u1030');
gv_vAlignTable['u1030'] = 'top';
var u1185 = document.getElementById('u1185');
gv_vAlignTable['u1185'] = 'center';
var u1184 = document.getElementById('u1184');

if (window.OnLoad) OnLoad();
