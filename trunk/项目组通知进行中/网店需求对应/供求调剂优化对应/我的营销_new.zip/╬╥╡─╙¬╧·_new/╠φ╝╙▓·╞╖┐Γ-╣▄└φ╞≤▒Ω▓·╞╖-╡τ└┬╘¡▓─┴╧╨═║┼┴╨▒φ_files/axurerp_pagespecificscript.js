﻿
var PageName = '添加产品库-管理企标产品-电缆原材料型号列表';
var PageId = 'c8bbe3c149014c25b42da98e81fd3431'
var PageUrl = '添加产品库-管理企标产品-电缆原材料型号列表.html'
document.title = '添加产品库-管理企标产品-电缆原材料型号列表';
var PageNotes = 
{
"pageName":"添加产品库-管理企标产品-电缆原材料型号列表",
"showNotesNames":"False"}
var $OnLoadVariable = '';

var $CSUM;

var hasQuery = false;
var query = window.location.hash.substring(1);
if (query.length > 0) hasQuery = true;
var vars = query.split("&");
for (var i = 0; i < vars.length; i++) {
    var pair = vars[i].split("=");
    if (pair[0].length > 0) eval("$" + pair[0] + " = decodeURIComponent(pair[1]);");
} 

if (hasQuery && $CSUM != 1) {
alert('Prototype Warning: The variable values were too long to pass to this page.\nIf you are using IE, using Firefox will support more data.');
}

function GetQuerystring() {
    return '#OnLoadVariable=' + encodeURIComponent($OnLoadVariable) + '&CSUM=1';
}

function PopulateVariables(value) {
    var d = new Date();
  value = value.replace(/\[\[OnLoadVariable\]\]/g, $OnLoadVariable);
  value = value.replace(/\[\[PageName\]\]/g, PageName);
  value = value.replace(/\[\[GenDay\]\]/g, '20');
  value = value.replace(/\[\[GenMonth\]\]/g, '7');
  value = value.replace(/\[\[GenMonthName\]\]/g, '七月');
  value = value.replace(/\[\[GenDayOfWeek\]\]/g, '星期五');
  value = value.replace(/\[\[GenYear\]\]/g, '2012');
  value = value.replace(/\[\[Day\]\]/g, d.getDate());
  value = value.replace(/\[\[Month\]\]/g, d.getMonth() + 1);
  value = value.replace(/\[\[MonthName\]\]/g, GetMonthString(d.getMonth()));
  value = value.replace(/\[\[DayOfWeek\]\]/g, GetDayString(d.getDay()));
  value = value.replace(/\[\[Year\]\]/g, d.getFullYear());
  return value;
}

function OnLoad(e) {

}

var u115 = document.getElementById('u115');

var u122 = document.getElementById('u122');
gv_vAlignTable['u122'] = 'center';
var u21 = document.getElementById('u21');

var u132 = document.getElementById('u132');
gv_vAlignTable['u132'] = 'top';
var u137 = document.getElementById('u137');

var u53 = document.getElementById('u53');

var u32 = document.getElementById('u32');
gv_vAlignTable['u32'] = 'center';
var u165 = document.getElementById('u165');

var u7 = document.getElementById('u7');

var u45 = document.getElementById('u45');

var u79 = document.getElementById('u79');
gv_vAlignTable['u79'] = 'center';
var u17 = document.getElementById('u17');

var u4 = document.getElementById('u4');
gv_vAlignTable['u4'] = 'center';
var u140 = document.getElementById('u140');

u140.style.cursor = 'pointer';
if (bIE) u140.attachEvent("onclick", Clicku140);
else u140.addEventListener("click", Clicku140, true);
function Clicku140(e)
{
windowEvent = e;


if (true) {

	self.location.href="添加产品库-企标产品-创建企标产品详细页.html" + GetQuerystring();

}

}

var u171 = document.getElementById('u171');

var u135 = document.getElementById('u135');

var u151 = document.getElementById('u151');

var u12 = document.getElementById('u12');
gv_vAlignTable['u12'] = 'center';
var u42 = document.getElementById('u42');

u42.style.cursor = 'pointer';
if (bIE) u42.attachEvent("onclick", Clicku42);
else u42.addEventListener("click", Clicku42, true);
function Clicku42(e)
{
windowEvent = e;


if (true) {

	SetPanelState('u2', 'pd0u2','none','',500,'none','',500);

}

}

var u159 = document.getElementById('u159');

var u55 = document.getElementById('u55');

var u186 = document.getElementById('u186');
gv_vAlignTable['u186'] = 'center';
var u150 = document.getElementById('u150');
gv_vAlignTable['u150'] = 'center';
var u5 = document.getElementById('u5');

var u105 = document.getElementById('u105');
gv_vAlignTable['u105'] = 'center';
var u27 = document.getElementById('u27');
gv_vAlignTable['u27'] = 'center';
var u138 = document.getElementById('u138');

var u15 = document.getElementById('u15');

var u85 = document.getElementById('u85');

u85.style.cursor = 'pointer';
if (bIE) u85.attachEvent("onclick", Clicku85);
else u85.addEventListener("click", Clicku85, true);
function Clicku85(e)
{
windowEvent = e;


if (true) {

	self.location.href="添加产品库-企标产品-创建企标产品详细页.html" + GetQuerystring();

}

}

var u20 = document.getElementById('u20');
gv_vAlignTable['u20'] = 'center';
var u120 = document.getElementById('u120');
gv_vAlignTable['u120'] = 'center';
var u189 = document.getElementById('u189');

u189.style.cursor = 'pointer';
if (bIE) u189.attachEvent("onclick", Clicku189);
else u189.addEventListener("click", Clicku189, true);
function Clicku189(e)
{
windowEvent = e;


if (true) {

	SetPanelState('u2', 'pd2u2','none','',500,'none','',500);

}

}

var u24 = document.getElementById('u24');
gv_vAlignTable['u24'] = 'center';
var u163 = document.getElementById('u163');

var u48 = document.getElementById('u48');
gv_vAlignTable['u48'] = 'center';
var u108 = document.getElementById('u108');

u108.style.cursor = 'pointer';
if (bIE) u108.attachEvent("onclick", Clicku108);
else u108.addEventListener("click", Clicku108, true);
function Clicku108(e)
{
windowEvent = e;


if (true) {

	SetPanelState('u2', 'pd2u2','none','',500,'none','',500);

}

}

var u16 = document.getElementById('u16');
gv_vAlignTable['u16'] = 'center';
var u37 = document.getElementById('u37');
gv_vAlignTable['u37'] = 'center';
var u62 = document.getElementById('u62');
gv_vAlignTable['u62'] = 'center';
var u11 = document.getElementById('u11');

var u43 = document.getElementById('u43');

u43.style.cursor = 'pointer';
if (bIE) u43.attachEvent("onclick", Clicku43);
else u43.addEventListener("click", Clicku43, true);
function Clicku43(e)
{
windowEvent = e;


if (true) {

	SetPanelState('u2', 'pd1u2','none','',500,'none','',500);

}

}

var u75 = document.getElementById('u75');

var u133 = document.getElementById('u133');

var u34 = document.getElementById('u34');

var u68 = document.getElementById('u68');
gv_vAlignTable['u68'] = 'center';
var u176 = document.getElementById('u176');
gv_vAlignTable['u176'] = 'center';
var u39 = document.getElementById('u39');
gv_vAlignTable['u39'] = 'center';
var u157 = document.getElementById('u157');

var u47 = document.getElementById('u47');

var u184 = document.getElementById('u184');
gv_vAlignTable['u184'] = 'center';
var u89 = document.getElementById('u89');
gv_vAlignTable['u89'] = 'center';
var u88 = document.getElementById('u88');

var u103 = document.getElementById('u103');
gv_vAlignTable['u103'] = 'center';
var u10 = document.getElementById('u10');
gv_vAlignTable['u10'] = 'center';
var u149 = document.getElementById('u149');

var u99 = document.getElementById('u99');
gv_vAlignTable['u99'] = 'center';
var u146 = document.getElementById('u146');
gv_vAlignTable['u146'] = 'center';
var u112 = document.getElementById('u112');
gv_vAlignTable['u112'] = 'center';
var u110 = document.getElementById('u110');
gv_vAlignTable['u110'] = 'center';
var u78 = document.getElementById('u78');

var u179 = document.getElementById('u179');
gv_vAlignTable['u179'] = 'top';
var u57 = document.getElementById('u57');

var u191 = document.getElementById('u191');
gv_vAlignTable['u191'] = 'center';
var u161 = document.getElementById('u161');

var u125 = document.getElementById('u125');

u125.style.cursor = 'pointer';
if (bIE) u125.attachEvent("onclick", Clicku125);
else u125.addEventListener("click", Clicku125, true);
function Clicku125(e)
{
windowEvent = e;


if (true) {

	self.location.href="#" + GetQuerystring();

}

}

var u6 = document.getElementById('u6');
gv_vAlignTable['u6'] = 'center';
var u168 = document.getElementById('u168');

var u172 = document.getElementById('u172');
gv_vAlignTable['u172'] = 'center';
var u25 = document.getElementById('u25');
gv_vAlignTable['u25'] = 'top';
var u158 = document.getElementById('u158');
gv_vAlignTable['u158'] = 'center';
var u54 = document.getElementById('u54');
gv_vAlignTable['u54'] = 'center';
var u67 = document.getElementById('u67');

var u38 = document.getElementById('u38');

var u52 = document.getElementById('u52');
gv_vAlignTable['u52'] = 'center';
var u26 = document.getElementById('u26');

var u174 = document.getElementById('u174');
gv_vAlignTable['u174'] = 'center';
var u119 = document.getElementById('u119');

var u145 = document.getElementById('u145');

var u51 = document.getElementById('u51');

var u182 = document.getElementById('u182');
gv_vAlignTable['u182'] = 'center';
var u101 = document.getElementById('u101');
gv_vAlignTable['u101'] = 'center';
var u100 = document.getElementById('u100');

var u77 = document.getElementById('u77');
gv_vAlignTable['u77'] = 'top';
var u153 = document.getElementById('u153');

var u31 = document.getElementById('u31');

var u82 = document.getElementById('u82');

var u36 = document.getElementById('u36');

var u95 = document.getElementById('u95');
gv_vAlignTable['u95'] = 'center';
var u61 = document.getElementById('u61');

var u116 = document.getElementById('u116');
gv_vAlignTable['u116'] = 'center';
var u74 = document.getElementById('u74');
gv_vAlignTable['u74'] = 'center';
var u123 = document.getElementById('u123');

var u114 = document.getElementById('u114');
gv_vAlignTable['u114'] = 'center';
var u33 = document.getElementById('u33');

u33.style.cursor = 'pointer';
if (bIE) u33.attachEvent("onclick", Clicku33);
else u33.addEventListener("click", Clicku33, true);
function Clicku33(e)
{
windowEvent = e;


if (true) {

	self.location.href="添加产品库-企标产品-创建企标产品详细页.html" + GetQuerystring();

}

}

var u166 = document.getElementById('u166');
gv_vAlignTable['u166'] = 'center';
var u92 = document.getElementById('u92');

var u19 = document.getElementById('u19');

var u183 = document.getElementById('u183');

var u126 = document.getElementById('u126');

var u71 = document.getElementById('u71');

var u181 = document.getElementById('u181');

var u98 = document.getElementById('u98');

var u136 = document.getElementById('u136');
gv_vAlignTable['u136'] = 'center';
var u180 = document.getElementById('u180');

var u169 = document.getElementById('u169');

var u56 = document.getElementById('u56');
gv_vAlignTable['u56'] = 'center';
var u28 = document.getElementById('u28');

var u187 = document.getElementById('u187');

u187.style.cursor = 'pointer';
if (bIE) u187.attachEvent("onclick", Clicku187);
else u187.addEventListener("click", Clicku187, true);
function Clicku187(e)
{
windowEvent = e;


if (true) {

	SetPanelState('u2', 'pd0u2','none','',500,'none','',500);

}

}

var u142 = document.getElementById('u142');
gv_vAlignTable['u142'] = 'center';
var u106 = document.getElementById('u106');

u106.style.cursor = 'pointer';
if (bIE) u106.attachEvent("onclick", Clicku106);
else u106.addEventListener("click", Clicku106, true);
function Clicku106(e)
{
windowEvent = e;


if (true) {

	SetPanelState('u2', 'pd0u2','none','',500,'none','',500);

}

}

var u40 = document.getElementById('u40');

var u139 = document.getElementById('u139');
gv_vAlignTable['u139'] = 'center';
var u87 = document.getElementById('u87');
gv_vAlignTable['u87'] = 'center';
var u23 = document.getElementById('u23');

var u104 = document.getElementById('u104');

var u192 = document.getElementById('u192');

u192.style.cursor = 'pointer';
if (bIE) u192.attachEvent("onclick", Clicku192);
else u192.addEventListener("click", Clicku192, true);
function Clicku192(e)
{
windowEvent = e;


if (true) {

	self.location.href="产品管理.html" + GetQuerystring();

}

}

var u121 = document.getElementById('u121');

var u102 = document.getElementById('u102');

var u65 = document.getElementById('u65');

var u164 = document.getElementById('u164');
gv_vAlignTable['u164'] = 'center';
var u109 = document.getElementById('u109');

var u84 = document.getElementById('u84');
gv_vAlignTable['u84'] = 'center';
var u50 = document.getElementById('u50');
gv_vAlignTable['u50'] = 'center';
var u97 = document.getElementById('u97');
gv_vAlignTable['u97'] = 'center';
var u63 = document.getElementById('u63');

var u14 = document.getElementById('u14');
gv_vAlignTable['u14'] = 'center';
var u46 = document.getElementById('u46');
gv_vAlignTable['u46'] = 'center';
var u170 = document.getElementById('u170');
gv_vAlignTable['u170'] = 'center';
var u76 = document.getElementById('u76');
gv_vAlignTable['u76'] = 'center';
var u134 = document.getElementById('u134');
gv_vAlignTable['u134'] = 'center';
var u81 = document.getElementById('u81');
gv_vAlignTable['u81'] = 'center';
var u41 = document.getElementById('u41');
gv_vAlignTable['u41'] = 'center';
var u177 = document.getElementById('u177');

var u128 = document.getElementById('u128');

var u94 = document.getElementById('u94');

var u60 = document.getElementById('u60');
gv_vAlignTable['u60'] = 'center';
var u190 = document.getElementById('u190');

var u185 = document.getElementById('u185');

var u9 = document.getElementById('u9');

var u73 = document.getElementById('u73');

var u113 = document.getElementById('u113');

var u44 = document.getElementById('u44');

u44.style.cursor = 'pointer';
if (bIE) u44.attachEvent("onclick", Clicku44);
else u44.addEventListener("click", Clicku44, true);
function Clicku44(e)
{
windowEvent = e;


if (true) {

	SetPanelState('u2', 'pd2u2','none','',500,'none','',500);

}

}

var u147 = document.getElementById('u147');

var u91 = document.getElementById('u91');
gv_vAlignTable['u91'] = 'center';
var u131 = document.getElementById('u131');
gv_vAlignTable['u131'] = 'center';
var u18 = document.getElementById('u18');
gv_vAlignTable['u18'] = 'center';
var u64 = document.getElementById('u64');
gv_vAlignTable['u64'] = 'center';
var u70 = document.getElementById('u70');
gv_vAlignTable['u70'] = 'center';
var u188 = document.getElementById('u188');

u188.style.cursor = 'pointer';
if (bIE) u188.attachEvent("onclick", Clicku188);
else u188.addEventListener("click", Clicku188, true);
function Clicku188(e)
{
windowEvent = e;


if (true) {

	SetPanelState('u2', 'pd1u2','none','',500,'none','',500);

}

}

var u162 = document.getElementById('u162');
gv_vAlignTable['u162'] = 'center';
var u156 = document.getElementById('u156');
gv_vAlignTable['u156'] = 'center';
var u13 = document.getElementById('u13');

var u29 = document.getElementById('u29');
gv_vAlignTable['u29'] = 'center';
var u148 = document.getElementById('u148');
gv_vAlignTable['u148'] = 'center';
var u141 = document.getElementById('u141');

var u175 = document.getElementById('u175');

var u129 = document.getElementById('u129');
gv_vAlignTable['u129'] = 'center';
var u143 = document.getElementById('u143');

var u58 = document.getElementById('u58');
gv_vAlignTable['u58'] = 'center';
var u127 = document.getElementById('u127');
gv_vAlignTable['u127'] = 'center';
var u86 = document.getElementById('u86');

var u173 = document.getElementById('u173');

var u111 = document.getElementById('u111');

var u0 = document.getElementById('u0');

var u154 = document.getElementById('u154');
gv_vAlignTable['u154'] = 'center';
var u83 = document.getElementById('u83');

var u178 = document.getElementById('u178');
gv_vAlignTable['u178'] = 'center';
var u8 = document.getElementById('u8');
gv_vAlignTable['u8'] = 'center';
var u96 = document.getElementById('u96');

var u160 = document.getElementById('u160');
gv_vAlignTable['u160'] = 'center';
var u49 = document.getElementById('u49');

var u124 = document.getElementById('u124');
gv_vAlignTable['u124'] = 'center';
var u144 = document.getElementById('u144');
gv_vAlignTable['u144'] = 'center';
var u80 = document.getElementById('u80');

var u1 = document.getElementById('u1');
gv_vAlignTable['u1'] = 'center';
var u167 = document.getElementById('u167');
gv_vAlignTable['u167'] = 'top';
var u155 = document.getElementById('u155');

var u93 = document.getElementById('u93');
gv_vAlignTable['u93'] = 'center';
var u130 = document.getElementById('u130');

var u117 = document.getElementById('u117');

var u59 = document.getElementById('u59');

var u118 = document.getElementById('u118');
gv_vAlignTable['u118'] = 'center';
var u90 = document.getElementById('u90');

var u2 = document.getElementById('u2');

var u66 = document.getElementById('u66');
gv_vAlignTable['u66'] = 'center';
var u30 = document.getElementById('u30');

var u22 = document.getElementById('u22');
gv_vAlignTable['u22'] = 'center';
var u152 = document.getElementById('u152');
gv_vAlignTable['u152'] = 'center';
var u107 = document.getElementById('u107');

u107.style.cursor = 'pointer';
if (bIE) u107.attachEvent("onclick", Clicku107);
else u107.addEventListener("click", Clicku107, true);
function Clicku107(e)
{
windowEvent = e;


if (true) {

	SetPanelState('u2', 'pd1u2','none','',500,'none','',500);

}

}

var u35 = document.getElementById('u35');
gv_vAlignTable['u35'] = 'center';
var u69 = document.getElementById('u69');

var u72 = document.getElementById('u72');
gv_vAlignTable['u72'] = 'center';
var u3 = document.getElementById('u3');

if (window.OnLoad) OnLoad();
