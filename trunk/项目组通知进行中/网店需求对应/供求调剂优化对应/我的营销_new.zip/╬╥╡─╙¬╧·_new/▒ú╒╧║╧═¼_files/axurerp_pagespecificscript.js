﻿
var PageName = '保障合同';
var PageId = '7abd9f7518754b61bb06ee371343c504'
var PageUrl = '保障合同.html'
document.title = '保障合同';
var PageNotes = {};

if (window.OnLoad) OnLoad();
