// JavaScript Document
$(function(){
	$(".tab_change").hide();
	$(".tab_change").eq(0).show();
	$(".js_tabchange").hide();
	$(".js_tabchange").eq(0).show();
	$(".tab_menu > li").each(function(i){
		$(this).click(function(){
			$(this).addClass("current_menu").siblings().removeClass("current_menu");
			$(".tab_change").hide();
			$(".tab_change").eq(i).show();
			$(".js_tabchange").hide();
			$(".js_tabchange").eq(i).show();
		});
		
	});
});

$(function(){
	//$('input:checkbox').css('margin-top','-3px');
	$(".huanse > tbody > tr:odd").addClass("odd");
	$(".hs > tbody").find('tr:odd').addClass("bcf3f7ff");
});
/*menu
$(function(){
	$(".Level_2").hide();
	$(".close").each(function(i){
			$(this).toggle(function(){
				$(this).attr("class","open");
				$(".Level_2").eq(i).show();
			},function(){
				$(this).attr("class","close");
				$(".Level_2").eq(i).hide();
			});
		});
});*/
 $(function(){
	$(".t_k").hide();
	$(".lay").click(function(){
		$(".t_k").hide();
		$(this).siblings(".t_k").show();	
	});	
	$(".lay_h").click(function(){
		$(".t_k").hide();
	});
});

$(function(){
	$(".setPhoto").hide();
	$(".upload_p .addInfo").click(function(){
		$(".setPhoto").show();
	});
	$(".sure > input").click(function(){
		$(".setPhoto").hide();
	});
});
/*未开通店铺 单选按钮选择切换*/
$(function(){
	$(".change_MC").hide();
	$(".type3").hide();
	$(".change_MC").eq(0).show();
	$("input[name='property']").change(function(){
		var $val = $(this).val();
		//alert($val);
		if($val == '2'){
				$(".type3").hide();
				$(".change_MC").hide();
				$(".change_MC").eq(1).show();	
			}else if($val == '3'){
				$(".type3").hide();
				$(".change_MC").hide();
				$(".change_MC").eq(2).show();	
			}else if($val == '4'){
				$(".type3").hide();
				$(".change_MC").hide();
				$(".change_MC").eq(3).show();	
			}else if($val == '5'){
				$(".type3").show();
				$(".change_MC").hide();
				$(".change_MC").eq(4).show();	
			}else if($val == '6'){
				$(".change_MC").hide();
				$(".change_MC").eq(4).show();
			}else if($val == '7'){
				$(".change_MC").hide();
				$(".change_MC").eq(5).show();
			}
			else{
				$(".type3").hide();
				$(".change_MC").hide();
				$(".change_MC").eq(0).show();	
			}
	});
});

$(function(){
	$(".type1").show();
	$(".type2").hide();
	$("#select_type").change(function(){
			var $selectTxt = $('#select_type option:selected').text();
			if($selectTxt == '企业直销人员'){
					$(".type1").show();
					$(".type2").hide();
				}else{
					$(".type1").hide();
					$(".type2").show();
				}
		});
});/*下拉列表选择类型*/
$(function(){
	$("#select_page").change(function(){
		var $selectTxt = $('#select_page option:selected').text();
			//alert($selectTxt);
			if($selectTxt == '生产制造'){
					window.location='我的店铺-生产制造.html';
				}else if($selectTxt == '代理经销'){
					window.location='我的店铺-代理经销.html';
				}else{
					window.location='我的店铺-其他.html';
				}
	});
});
/*创建企标产品*/
$(function(){
	$(".tog > tbody").hide();
	$(".zk span").click(function(){
		if($(".tog > tbody").is(":visible")){
			$(".tog > tbody").hide();
			$(".zk span").css("background","url(../../images/bg.gif) no-repeat 0px -318px")
			.text("展开填写详细参数信息");
		}else{
			$(".tog > tbody").show();
			$(".zk span").css("background","url(../../images/bg.gif) no-repeat 0px -359px")
			.text("收起填写详细参数信息");
		}
		return false;
	});
});

//添加自定义属性
$(function(){
	
	$('#addAttr').click(function(){
			var $parTr = $(this).parent().parent();
			var num = $parTr.index()+1;
			$parTr.before('<tr><td class="leftTt2"><input type="text" value="其他"  class="input w130" /></td><td><input type="text" value="其他"  class="input w120" /> <input type="text" value=""  class="input w60" /></td></tr>');
			
			if(num%2 == 0){
					$parTr.removeClass("bcf3f7ff");
					$(".hs > tbody").find('tr:odd').addClass("bcf3f7ff");
				}else{
					$(".hs > tbody").find('tr:odd').addClass("bcf3f7ff");
					}
	});
	$(".gengduo_con").hide();
	$("#ckgd").click(function(){
		$(".gengduo_con").show();
	});
	
});
$(function(){
	$(".nohs tr").removeClass("bcf3f7ff");
	$('#addPic').click(function(){
			var $parTr = $(this).parent().parent();
			var num = $parTr.index()+1;
			$parTr.before('<tr><td><input type="text" value="请输入图片名称 "  class="input w100" /></td><td><div class="wait wait_1">等待上传...</div><div class="upload upload_1"><table cellspacing="0" cellpadding="0"><tbody><tr><td width="40">文件：</td><td><input type="text" class="input w130"><input type="button" value="&nbsp;&nbsp;浏览&nbsp;&nbsp;"></td></tr><tr><td>说明：</td><td><input type="text" class="input w130"><input type="button" value="&nbsp;&nbsp;上传&nbsp;&nbsp;"></td></tr></tbody></table></td></tr>');
			
			if(num%2 == 0){
					$parTr.removeClass("bcf3f7ff");
					$(".hs1 > tbody").children('tr:odd').addClass("bcf3f7ff");
					//$(".nohs tr").removeClass("bcf3f7ff");
				}else{
					$(".hs1 > tbody").children('tr:odd').addClass("bcf3f7ff");
					//$(".nohs tr").removeClass("bcf3f7ff");
					}
	});
	
});
$(function(){
	$("#addAttr1").click(function(){
		var $parTr = $(this).parent().parent();
		$parTr.before('<tr><td class="bcf3f7ff"><input type="text" value=""  class="input w130" /></td><td><input type="text" value=""  class="input w130" /></td><td><input type="text" value=""  class="input w130" /></td><td><input type="text" value=""  class="input w130" /></td><td><input type="text" value=""  class="input w130" /></td></tr>');
	});
	$("#addAttr2").click(function(){
		var $parTr = $(this).parent().parent();
		$parTr.before('<tr><td class="bcf3f7ff"><input type="text" value=""  class="input w130" /></td><td><input type="text" value=""  class="input w130" /></td><td><input type="text" value=""  class="input w130" /></td><td><input type="text" value=""  class="input w130" /></td><td><input type="text" value=""  class="input w130" /></td></tr>');
	});
	$("#add1").click(function(){
		$(this).before('<br /><input type="text" class="w130 mb10" value=""  /><br /><textarea class="textarea mb10" style="height:120px;"></textarea>');
	});
});
$(function(){
	$('.delete').click(function(){//alert(0);
		var $parTr = $(this).parent().parent();
		var $parTbody = $parTr.parent();
		var $parPrev = $parTr.prev();
		var num = $parTr.index()+1;
		$parPrev.remove(); 
		if(num%2 == 0){
			$parTr.removeClass("bcf3f7ff");
			$(".hs1 > tbody").children('tr:odd').addClass("bcf3f7ff");
			//$(".nohs tr").removeClass("bcf3f7ff");
		}else{
			$(".hs1 > tbody").children('tr:odd').addClass("bcf3f7ff");
			//$(".nohs tr").removeClass("bcf3f7ff");
			}
	});
});
$(function(){
	$("#GG2").hide();
	$('#selectGG').change(function(){
		var $val = $('#selectGG option:selected').val();
		//alert($val );
		if ($val == 2){
			$("#GG1").hide();
			$("#GG2").show();
		}else{
			$("#GG1").show();
			$("#GG2").hide();
		}
	});
});

$(function(){
	$(".tck").hide();
	$(".ctck").click(function(){
		$(".tck").show();
	});	
	$(".tbut .btn").click(function(){
		$(".tck").hide();
	});	
});

/**个人中心**/
$(function(){
	$(".submit_s").hide();
	$(".newadd_row").hide();
	$(".submit").click(function(){
		$(this).parents(".tab_change").find(".newadd_row").show();
		$(this).parents(".newadd_tab").hide().next(".newadd").show();
		$(".submit_s").css("opacity","1").show().animate({opacity: '0'}, 3000 );
	});
});
$(function(){
	$(".newadd_tab").hide();
	$(".newadd").click(function(){
		$(this).hide().prev(".newadd_tab").show();
	});
});

//弹出层
/*$(function(){
	//$(".resume_part > .map").hide();
	var showContent = '<div class="layer"></div>';
	//var $w = $(window).width();
	//var $h = $(window).height();
	var $w = document.body.clientWidth;
	var $h = document.body.clientHeight;
	$(document.body).append(showContent);
	//$("#showDome").hide();
	$(".layer").width($w);
	$(".layer").height($h);
	$(".layer").hide();
	$(".audit").click(function(){
		$(".hugeViewMapPanel").show();
		$(".layer").show();	
	});
	$(".shop_open").click(function(){
		$(".hugeViewMapPanel").show();
		$(".layer").show();	
	});
	$(".hugeViewMapPanel .close").click(function(){
		$(".hugeViewMapPanel").hide();
		$(".layer").hide();	
	});
	$(".panel-map-info .btn").click(function(){
		$(".hugeViewMapPanel").hide();
		$(".layer").hide();	
	});
	
});*/

//询盘回复2011-11-01
$(function(){
	$(".dh_hf").hide();
	$(".hf").click(function(){
		  $(this).hide();
		  $(".dh_hf").show();
		})
     $(".fb").click(function(){
		 $(".dh_hf").hide();
		 })
	})
//我的指导价2011-11-02
//$(function(){
//	$(".his_tab").hide();
//	$(".history_pro").click(function(){
//		  $(this).children("span").addClass("jj");
//		  $(".his_tab").slideToggle();
	//	})
//	})
$(function () {
            $(".history_pro").click(function () {
				if($(".his_tab").is(":visible")){
					$(".his_tab").hide();
					$(".history_pro span").css("background","url(../../images/jiajian.gif) no-repeat 0px 0px");
				}else{
					$(".his_tab").show();
					$(".history_pro span").css("background","url(../../images/jiajian.gif) no-repeat -20px 0px");
				}
            });
        });
		
/*2011-11-15 订货单*/

/*订货单tab选项卡*/
$(function(){
	$(".zfbsm_con").hide();
	$(".zfbsm_con").eq(0).show();
	$(".zfbsm > li").each(function(i){
		$(this).click(function(){
			$(".zfbsm_con").hide();
			$(".zfbsm_con").eq(i).show();
		});
		
	});
});

$(function(){
	$(".makea").hide();
	$("input.ahyu").click(function(){
		$(".layer").show();	
		$(".zffs").show();	
	});
	
	$(".layer_close").click(function(){
		$(".layer").hide();	
		$(".zffs").hide();	
	});
});

/*遮罩层js*/
$(function(){
	var $w = document.body.clientWidth;
	var $h = document.body.clientHeight;
	//$(document.body).append(showContent);
	$(".layer").width($w);
	$(".layer").height($h);
	$(".layer").hide();
});
/*关闭、确认、取消按钮遮罩层弹出层隐藏*/
$(function(){	
	$(".close").click(function(){
		$(".layer").hide();	
		$(".sureSendFreight").hide();
		$(".sureOrder").hide();
		$(".panel_t2").hide();
		$(".TD_Box").hide();
		$(".DD_reason").hide();	
		$(".hugeViewMapPanel").hide();
		$(".boxNode").hide();
		$(".paymentOrder").hide();
		$(".paymentOrder_yj");hide();
		$(".sureSend_SK").hide();
		$(".NopaymentOrder_yj").hide();
		$(".sureSend_SH").hide();
		$(".sendPersonDiv").hide();	
	});
	$(".sureBtn").click(function(){
		$(".layer").hide();	
		$(".TD_Box").hide();
		$(".sureSendFreight").hide();
		$(".sureOrder").hide();	
		$(".panel_t2").hide();
		$(".TD_Box").hide();
		$(".DD_reason").hide();	
		$(".hugeViewMapPanel").hide();	
		$(".boxNode").hide();
		$(".paymentOrder").hide();
		$(".paymentOrder_yj");hide();
		$(".sureSend_SK").hide();
		$(".NopaymentOrder_yj").hide();
		$(".sureSend_SH").hide();
	});
	$(".canelBtn").click(function(){
		$(".layer").hide();	
		$(".TD_Box").hide();
		$(".sureSendFreight").hide();	
		$(".panel_t2").hide();
		$(".TD_Box").hide();
		$(".DD_reason").hide();	
		$(".hugeViewMapPanel").hide();
		$(".boxNode").hide();
		$(".paymentOrder").hide();
		$(".paymentOrder_yj");hide();
		$(".sureSend_SK").hide();
		$(".NopaymentOrder_yj").hide();
		$(".sureSend_SH").hide();
	});
	$(".butn3").click(function(){
		$("#div_positionName").hide();
	});
	$("#btnPositionOk").click(function(){
		$("#div_positionName").hide();
	});
});

/*订货单弹出层*/
$(function(){
	/*确认发货的弹出层*/
	$(".sureSendFreight").hide();
	$(".sureSend > span").click(function(){
		$(".layer").show();	
		$(".sureSendFreight").show();	
	});

	/*添加备注弹出层*/
	$(".boxNode").hide();
	$(".bzbut1 > a").click(function(){
		$(".layer").show();	
		$(".boxNode").show();	
	});

	/*取消订单弹出层*/
	$(".hugeViewMapPanel").hide();
	$(".Canel > span").click(function(){
		$(".layer").show();	
		$(".hugeViewMapPanel").show();	
	});

	/*取消原因的弹出层*/
	$(".DD_reason").hide();
	$("#DD_Canelreason > span").click(function(){
		$(".layer").show();	
		$(".DD_reason").show();	
	});
	/*调整费用的弹出层*/
	$(".TZ_money").hide();
	$("#TZ_money > span").click(function(){
		$(".layer").show();	
		$(".TD_Box").show();	
	});
	/*确认订单的弹出层*/
	$(".sureOrder").hide();
	$(".sureOrderClick > span").click(function(){
		$(".layer").show();	
		$(".sureOrder").show();	
	});

	/*删除订单的弹出层*/
	$(".deleteOrder").hide();
	$("span.deleteorder").click(function(){
		$(".layer").show();	
		$(".deleteOrder").show();	
	});
	/*付款订单的弹出层*/
	$(".paymentOrder").hide();
	$("span.paymentOrderOnClick").click(function(){
		$(".layer").show();	
		$(".paymentOrder").show();	
	});
	/*付款订单的弹出层*/
	$(".paymentOrder_yj").hide();
	$("span.paymentOrder_yjOnClick").click(function(){
		$(".layer").show();	
		$(".paymentOrder_yj").show();	
	});
	/*确认收款的弹出层*/
	$(".sureSend_SK").hide();
	$("span.sureSend_SKOnclick").click(function(){
		$(".layer").show();	
		$(".sureSend_SK").show();	
	});
	/*拒绝订单弹出层*/
	$(".JJ_reason").hide();
	$(".JJ_reasonOnclick").click(function(){
	    $(".sureOrder").hide();	
		$(".layer").show();	
		$(".JJ_reason").show();	
	});
	/*未收到货款弹出层*/
	$(".NopaymentOrder_yj").hide();
	$(".NopaymentOrder_yjOnclick").click(function(){
		$(".layer").show();	
		$(".NopaymentOrder_yj").show();	
	});
	/*未收到货款弹出层*/
	$(".sureSend_SH").hide();
	$(".sureSend_SHOnclick").click(function(){
		$(".layer").show();	
		$(".sureSend_SH").show();	
	});
	/*发送人弹出层*/
	$(".sendPersonDiv").hide();
	$(".sendPersonDivOnclick").click(function(){
		$(".layer").show();	
		$(".sendPersonDiv").show();	
	});
	$(".release").click(function(){
		$(".layer").hide();	
		$(".sendPersonDiv").hide();	
		});
		/*主营行业弹出层*/
	$("#div_positionName").hide();
	$(".js_positionName").click(function(){
		$("#div_positionName").show();
		$("#subItems").hide();
		$("#allItems1 li").each(function(i){
			$(this).mouseover(function(){
			$("#subItems").eq(i).show();
			$('input:checkbox').css('margin-top','3px');
		});
		$(this).mouseout(function(){
			$("#subItems").eq(i).hide();
			$('input:checkbox').css('margin-top','3px');
			});
	});
	});
});

/*-2012-01-06 gzd 切换------------------------*/
$(function(){
	$(".tab_change").hide();
	$(".tab_change").eq(0).show();
	$(".xitong_link > li").each(function(i){
		$(this).click(function(){
			$(this).addClass("shoujianxiangUl").siblings().removeClass("shoujianxiangUl");
			$(".tab_change").hide();
			$(".tab_change").eq(i).show();
		});
	});
});
/*2012-07-09 gzd 帐号管理的二级切换签 页面布局已修改可以删掉*/
$(function(){
	$(".tab_changeson").hide();
	$(".tab_changeson").eq(0).show();
	$(".tab_menu_son > li").each(function(i){
		$(this).click(function(){
			$(this).addClass("current_menuson").siblings().removeClass("current_menuson");
			$(".tab_changeson").hide();
			$(".tab_changeson").eq(i).show();
		});
		
	});
});
/*-----------------------------*/
/*2012-02-23---------确认订单支付方式切换*/
$(function(){
	$(".zffs_msg").hide().eq(0).show();;
	$(".zffs_menu > li").each(function(i){
		$(this).click(function(){
			$(this).addClass("zffs_libg").siblings().removeClass("zffs_libg");
			$(".zffs_msg").hide().eq(i).show();
		});
	});
});

$(function(){
	$(".radmoney").click(function(){
		$(".money_down").attr("disabled","disabled");
		});
	$(".radmoney1").click(function(){
		$(".money_down").css("disabled","");
		});
	$(".radage").click(function(){
		$(".age_down").attr("disabled","disabled");
		});
	$(".radage1").click(function(){
		$(".age_down").css("disabled","");
		});
	$(".radsum").click(function(){
		$(".inp_sum").attr("disabled","disabled");
		});
	$(".radsum1").click(function(){
		$(".inp_sum").css("disabled","");
		});  
})


/*企业资料 分类选择 2012年3月27日 wxh*/
$(function(){
	$(".menu_iframe").hide();
	$(".menu_con").hide();
	$(".menu_con_sj").hide();
	$(".menucla a").each(function(i){
		$(this).hover(function(){
			$(".menucra .menu_con_sj").hide();
			$(".menucra .menu_con_sj").eq(i).show();
		});
	});
	
	$(".menuclb a").each(function(i){
		$(this).mouseover(function(){
			$(".menucrb .menu_con_sj ").hide();
			$(".menucrb .menu_con_sj ").eq(i).show();
		});
	});
	
	
	$(".menu_con").mouseleave(function(){
		$(".menu_con").hide();
		$(".menu_iframe").hide();
	})

		
	$(".menu_tit").each(function(i){
		$(this).click(function(){
			$(".menu_con").hide();
			$(".menu_con").eq(i).show();
			$(".menu_iframe").eq(i).show();
		});
	});
	
});

//弹出层

function letDivCenter(divName){  
	var top = ($(window).height() - $(divName).height())/2; 
	var left = ($(window).width() - $(divName).width())/2;    
	var scrollTop = $(document).scrollTop();    
	var scrollLeft = $(document).scrollLeft();    
	$(divName).css( {top : top, left : left + scrollLeft } ).show();   
	//$(divName).css( {top : top + scrollTop, left : left + scrollLeft } ).show();   
}

//显示遮罩层   
function showMask(){   
	$(".maskdiv").css("height",$(document).height());   
	$(".maskdiv").css("width",$(document).width());   
	$(".maskdiv").show();   
} 
   

//弹出层和遮罩层同时显示  
function showAll(conName,divName){
 
	showMask();   
	letDivCenter(divName);   
} 
//弹出层和遮罩层同时隐藏
function hideAll(divName){   
	$(".maskdiv").hide();  
	$(divName).hide();   
}
//二级搜索 zhx
$(function(){
	var $moreSch=$('.js_sch_more');
	$moreSch.hide();
	$(".js_Btn").click(function(){
		if($moreSch.is(":hidden")){
			$(this).addClass("topBtn").removeClass("bottomBtn");
			$moreSch.show();
			$(".js_search").hide();
		}else{
			$(this).addClass("bottomBtn").removeClass("topBtn");
			$moreSch.hide();
			$(".js_search").show();
			}
		})
	})
/*简历管理*/
$(function(){
	$(".js_rck").click(function(){
		window.confirm('确认将当前人才加入到人才库吗?')
		})
	$(".js_jlsc").click(function(){
		window.confirm('确认删除吗?')
		})
		
})

$(function(){
	$(".js_sj_layer").hide();
$(".shouji").hover(function(){$(".js_sj_layer").show();},function(){ $(".js_sj_layer").hide();});
})

$(function(){
	$(".jlck_con").hide().eq(0).show();;
	$(".jl_jlck > li").each(function(i){
		$(this).click(function(){
			$(this).addClass("jl_jlckbg").siblings().removeClass("jl_jlckbg");
			$(".jlck_con").hide().eq(i).show();
		});
	});
	/*2012-07-02 gzd 去边框*/
	$('.lj_table tr').find('th:first').css('border-left', '0');
	$('.lj_table tr').find('td:first').css('border-left', '0');
});


/*首页 搜索 查询*/
$(function(){
	$(".CRselectBox").hover(function(){
		$(this).addClass("CRselectBoxHover");
	},function(){
		$(this).removeClass("CRselectBoxHover");
	});
	$(".CRselectValue").click(function(){
		$(this).blur();
		$(".CRselectBoxOptions").show();
		return false;
	});
	$(".CRselectBoxItem a").click(function(){
		$(this).blur();
		var value = $(this).attr("rel");
		var txt = $(this).text();
		$("#abc").val(value);
		$("#abc_CRtext").val(txt);
		$(".CRselectValue").text(txt);
		$(".CRselectBoxItem a").removeClass("selected");
		$(this).addClass("selected");
		$(".CRselectBoxOptions").hide();
		return false;
	});
	/*点击任何地方关闭层*/
	$(document).click(function(event){
		if( $(event.target).attr("class") != "CRselectBox" ){
			$(".CRselectBoxOptions").hide();
		}
	});

	/*===================Test========================*/
	$("#test").click(function(){
		var value = $("#abc").val();
		var txt = $("#abc_CRtext").val();
		alert( "你本次选择的值和文本分别是：" + value +"  , "+txt );
	});
})

	$(function(){
		$(".wblist .wbcon:last").css("border-bottom","0 none");
	});  
	
/*0702 王晓红*/
$(function(){
	$(".js_bgdiv").each(function(i){
		$(this).hover(function(){
			$(this).addClass("js_bgdiv1").siblings().removeClass("js_bgdiv1");
		});
	});
});

$( function(){
	$(".js_tipbox").hide();
	$(".js_infos").mouseover(function(){
		$(".js_tipbox").show();
	}).mouseout(function(){
		$(".js_tipbox").hide();	
	})	
})

/*07-12 隔行换行*/
$(function(){
	$(".ghcolor tr:odd").addClass("odd");
	$(".ghcolor tr:even").addClass("even");
	$(".ghcolor tr").mouseover(function(){
		$(this).addClass("ghcolor_cur");
	}).mouseout(function(){
		$(this).removeClass("ghcolor_cur");	
	})
})

/*2012-07-12 gzd 隔行换色*/
$(function(){
	$(".js_list_tab tr:odd").addClass("odd");
	$(".js_list_tab tr:even").addClass("even");
	$(".js_list_tab tr").mouseover(function(){
		$(this).addClass("over");
	}).mouseout(function(){
		$(this).removeClass("over");	
	})
})

$(function(){
	$(".zltjcon").hide().eq(0).hide();
	$(".zltj").each(function(i){
		$(this).click(function(){
			$(".zltjcon").hide().eq(i).show();
		});
	});
})

/*2012-07-02 gzd 最新弹出层*/
//弹出层
function letDivCenter(divName){  
	var top = ($(window).height() - $(divName).height())/2; 
	var left = ($(window).width() - $(divName).width())/2;    
	var scrollTop = $(document).scrollTop();    
	var scrollLeft = $(document).scrollLeft();    
	$(divName).css( {top : top, left : left + scrollLeft } ).show();   
	if ($.browser.msie && ($.browser.version == "6.0") && !$.support.style) {
		$(divName).css( {top : top + scrollTop, left : left + scrollLeft } ).show();  
	}
}

//显示遮罩层   
function showMask(){   
	$(".maskdiv").css("height",$(document).height());   
	$(".maskdiv").css("width",$(document).width());   
	$(".maskdiv").show();   
} 
   

//弹出层和遮罩层同时显示  
function showAll(conName,divName){
	var $layerHeight = $(conName).parents(".layerBox").show().end().height();
	var $layerWidth = $(conName).parents(".layerBox").width();
	$(".poph").height($layerHeight);
	$(".layerBox").height($layerHeight+45)
	$(".layer_shadow").height($layerHeight+45);
	$(".layer_con").width($layerWidth-30);
	$(".layerBot_cenBG").width($layerWidth-20);
	$(".layerBox").hide();
	showMask();   
	letDivCenter(divName);   
	if ($.browser.msie && ($.browser.version == "6.0") && !$.support.style) {
		$("html").css("overflow-y","hidden")
	}
	
} 
//弹出层和遮罩层同时隐藏
function hideAll(divName){   
	$(".maskdiv").hide();  
	$(divName).hide();   
	if ($.browser.msie && ($.browser.version == "6.0") && !$.support.style) {
		$("html").css("overflow-y","auto")
	}
}
//===========弹出层结束=======================
$(function(){
	$(".js_tab2").hide();
	$(".js_update").click(function(){
		$(".js_tab2").show();
		$(".js_tab1").hide();	
		$(".js_update").hide();	
	})	
	$(".js_sure").click(function(){
		$(".js_tab1").show();
		$(".js_tab2").hide();	
		$(".js_update").show();	
		$(".js_tab3").show();
		$(".js_tab4").hide();
	})
	$(".js_tab4").hide();
	$(".js_update1").click(function(){
		$(".js_tab4").show();
		$(".js_tab3").hide();	
		$(".js_update1").hide();	
	})
	$(".js_tab").hide();	
	$(".js_edit").click(function(){
		$(".js_tab").show();	
	})
	$(".js_sure").click(function(){
		$(".js_tab").hide();	
	})
	$(".js_inp").hide();
	$(".js_qt").click(function(){
		$(".js_inp").toggle();
	})		
})

/*行业红本价隔行换色*/
$(function(){
	//$('input:checkbox').css('margin-top','-3px');
	$(".hbj_hs > tbody > tr:odd").addClass("odd");
	$(".hs > tbody").find('tr:odd').addClass("bcf3f7ff");
});

$(function(){
	var hbjw = ($(window).width());
	$(".hbj_rtab").width( hbjw - 571);
	if ($.browser.msie && ($.browser.version == "6.0") && !$.support.style) {
		$(".hbj_rtab").width( hbjw - 573); 
	}
});
