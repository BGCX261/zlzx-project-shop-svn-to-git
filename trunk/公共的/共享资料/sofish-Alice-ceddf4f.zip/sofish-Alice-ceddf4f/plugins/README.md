## Alice Solutions 插件

这些编辑器插件一般都是输入 `sl-[SOlUTION NAME]` 这样的形式出现，具体使用方式见目录下在 `README.md`：

快捷键参考：[https://github.com/sofish/Alice/tree/master/solutions#readme]()

<pre>
.
├── Coda            自动完成插件          作者: [62mm](http://xinxin.li)          
├── Eclipse         自动完成插件          作者: [62mm](http://xinxin.li)
├── VIM             自动完成插件          作者: [62mm](http://xinxin.li) 
├── IntelliJ_IDEA   自动完成插件          作者: [三桂](http://www.cnblogs.com/aNd1coder)
├── AntBuild        合并+压缩插件         作者: [iamued](http://www.iamued.com)
└── Sublime_Text_2  自动完成插件          作者: [yun77op](http://devilalbum.com/)
</pre>

    
欢迎为 Alice Solutions 开发插件，同样的，可能 `fork` 我们给我们 `pull request`。或者直接 Email 你的插件到 [admin@aliceui.com](mailto:admin@aliceui.com)。