### 使用方法：

`注：` 这里是 mac 下的设置，windows 下的 `Preferences` 在 `window` 这个选项卡下

1. Eclipse > Preferences

 ![alt 补全提示](https://github.com/sofish/Alice/raw/master/plugins/Eclipse/preview/1.png?raw=true)

2. 筛选 HTML，选择 HTML > Templates

 ![alt 补全提示](https://github.com/sofish/Alice/raw/master/plugins/Eclipse/preview/2.png?raw=true)

3. 导入 alicesolution.xml

4. 设置触发键

 ![alt 补全提示](https://github.com/sofish/Alice/raw/master/plugins/Eclipse/preview/3.png?raw=true)

5. 选择 General > Keys  设置自己习惯内容提示快捷键(该设置为全局设置)

 ![alt 补全提示](https://github.com/sofish/Alice/raw/master/plugins/Eclipse/preview/4.png?raw=true)

6. 如，按上图设置为control+tab。输入sl后，使用control+tab可以得到提示，选中相应solution后，回车补全内容。

 ![alt 补全提示](https://github.com/sofish/Alice/raw/master/plugins/Eclipse/preview/5.png?raw=true)


> 快捷键参考：[https://github.com/sofish/Alice/tree/master/solutions#readme]()

