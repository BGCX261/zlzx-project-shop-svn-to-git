### 使用方法：

- 解压 alice-solution-for-Coda.zip，含 AliceSolution.clipes 和 AliceSolution.mode。

- 将 `AliceSolution.mode` 拷贝至 Coda 编辑器的 Modes 目录下。
 <pre>
cp -rf AliceSolution.mode ~/Library/Application\ Support/Coda/Modes/
 </pre>

- 双击 `AliceSolution.clipes`, 将Solution导入coda clips。

- 如需 Alice Solution 自动完成，选择 `Text > Syntax Mode > AliceSolution` 即`文本 > 语法模式 > AliceSolution`。

- 在文档中输入sl，如下图，选择需要的代码片段，按tab键完成补全。<br/>
 ![alt 补全提示](https://github.com/sofish/Alice/raw/master/plugins/Coda/preview.png?raw=true "补全提示")

> 快捷键参考：[https://github.com/sofish/Alice/tree/master/solutions#readme]()
