插件作者：
 
- EMail: [aNd1coder@gmail.com](mailto:aNd1coder@gmail.com)
- Website: [http://www.cnblogs.com/aNd1coder]()

## 使用方法(这里以WIN7为例)：

- 将目录下的alice.xml拷贝到C:\Users\%username%\.IntelliJIdea11\config\templates。

- 然后重启 IntelliJ IDEA，按组合键 Ctrl+Alt+S 调出设置面版并在右侧找到 Live Templates 一栏，发现 alice 模板组已经出现在属性菜单里了,可以根据需求进行再制定。

 ![alt Live Templates设置](https://github.com/sofish/Alice/raw/master/plugins/IntelliJ_IDEA/preview/preview1.png?raw=true "Live Templates设置")

- 在文档中输入sl，如下图，选择需要的代码片段，按tab键完成补全。

  ![alt 补全提示](https://github.com/sofish/Alice/raw/master/plugins/IntelliJ_IDEA/preview/preview2.png?raw=true "补全提示")
  

