### 作者信息：

个人网站：[http://devilalbum.com/]()<br>
Github 项目: [https://github.com/yun77op]()


### 使用方法：

1. 选择 Preferences > Browse Packages 进入Sublime的包目录
2. 把 Alice 文件夹复制到 User 下
3. 重启 Sublime Text 2，在css或html文件中输入快捷键，按tab键完成补全

在 Tools > Snippets > Alice 下可以选择所有的snippet
 ![alt 补全提示](https://github.com/yun77op/Alice/raw/master/plugins/Sublime_Text_2/preview.png?raw=true)

> 快捷键参考：[https://github.com/sofish/Alice/tree/master/solutions#readme]()