## TODO & Feedbacks

这个文件将持续更新反馈，希望有兴趣的同学也可以 pull request 解决里面的问题：

- 页面太长，可以加回到顶部按钮（form @子推）
- 添加代码搭建演示 (@huacnlee)
- 添加 sass 支持 (@diamondtin )
- 搭建类似于 bootstrap 一样的演示直观站点 (@davidx_me)
- #3 issue 垂直居中里增加"单元素里包含未知宽高图片"的解决方案
- 优化官网与 Github 同步问题
- 各种编辑器插件
- 兼容主流浏览器的 ajax 上传插件
- colorcode.js 在 IE 的兼容性修复（@pizn)
- 搭建 alice blog, 发布 alice 的相关讯息 (@pizn)
- 测试：建议去测试 base.css 重设中的div，它在浏览器也是默认没有 padding 的（@为之）
- 增加 Grid solution (@sofish)
- 自动化与notepad++插件（@zjhiphop）

 http://aliceui.com/getting-start/#comment-393971227
