### 强制非中文输入法

- HTML:

 <pre>&lt;input type=&quot;text&quot; value=&quot;&quot; class=&quot;sl-ime-disabled&quot; /&gt;</pre>
    
- 优点: 有密码框（等只输入非中文的地方）使用，让用户不需要切换输入法，提升体验，等

注：`在 chrome 和 safari 浏览器下， 该解决方案失效。`
