# 自定义 input[type=file] 样式

HTML 结构:

    <span class="sl-file">
        <input type="button" value="点击选择图片" />
        <input type="file" exts="png|jpg|bmp" class="sl-file-input" />
    </span>