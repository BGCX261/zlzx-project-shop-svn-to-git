### 强制换行

- 用法: 
 一般块级元素用：.sl-wrap <br />
 table标签中需添加：.sl-wrap-table

- 例子: 
<pre>
    /* 一般块状元素 */
    &lt;p class="sl-wrap"&gt;…&lt;/p&gt;      
     
    /* table 换行 */
    &lt;table class="sl-wrap sl-wrap-table"&gt;&lt;/table&gt;
</pre>