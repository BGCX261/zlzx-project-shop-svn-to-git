### float:center

- 外框加上 `.sl-floatcenter` , 子元素加上 `.sl-floatcenter-item` ，元素就可以自动根据父元素的宽度水平居中
- 结构:
 <pre>
    &lt;ul class="sl-floatcenter clearfix"&gt;
      &lt;li class="sl-floatcenter-item"&gt;item1&lt;/li&gt;
      &lt;li class="sl-floatcenter-item"&gt;item2&lt;/li&gt;
      &lt;li class="sl-floatcenter-item"&gt;item3&lt;/li&gt;
    &lt;/ul&gt;
 </pre>