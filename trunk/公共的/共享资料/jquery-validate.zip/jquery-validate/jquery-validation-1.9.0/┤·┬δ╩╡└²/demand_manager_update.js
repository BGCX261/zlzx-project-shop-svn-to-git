function submitForm(){
	$("#sspecify").val(editor.getContent());
	$("#form").submit();
}
$().ready(function() {
    //jquery validate插件校验
    $("#form").validate({
	    rules: {
    		'inDto.entity.unit' : {
    			required: true
    		},
	        'inDto.entity.demandNum': {
	            required: true,
	            number: true,
	            min:0
	        },'inDto.entity.limitedPrice': {
	        	required: true,
	            number: true,
	            min:0
	        },'inDto.entity.deliveryCityId': {
	            required: true
	        },'inDto.dayCount': {
	            required: true
	        },'inDto.entity.submitTime': {
	            required: true,
	            digits: true
	        }
        },
        messages: {
        	'inDto.entity.unit' : {
        		required: "请选择求购单位"
        	},
            'inDto.entity.demandNum': {
	            required: "请输入需求量",
	            number: "只能输入数字",
	            min:"输入数字不能为负数"
	        },
            'inDto.entity.limitedPrice': {
                required: "请输入需求量",
	            number: "只能输入数字",
	            min:"输入数字不能为负数"
            },
            'inDto.entity.deliveryCityId': {
                required: "请输入城市"
            },
            'inDto.dayCount': {
                required: "请输入有效期"
            },'inDto.entity.submitTime': {
	            required: '请输入交货期限',
	            digits:'交货期限只能是整数'
	        }
        },
        errorPlacement: function(error, element) {
            var last = element.next();
            if(element.attr('name') == 'inDto.dayCount'){
        		var last = element.parent();
        	}
            error.css('color','red');
            error.appendTo(last);
		}
    });
});
var editor;
$(function(){
	editor = new baidu.editor.ui.Editor();
	editor.render("specify");
});